

const titolo = document.getElementById('Titolo');
const btn = document.getElementById('btn');
const nome_serie = document.getElementById('nome_serie');
const foto = document.getElementById('foto');
const URL = 'https://www.tvmaze.com/search?q=';
btn.onclick = function(){
	
     fetch(URL + titolo.value, { mode: 'no-cors'})
    .then(res => res.json())
    .then(serie => {foto.src = serie.image.medium; nome_serie.textContent = serie.rating.average; })

}