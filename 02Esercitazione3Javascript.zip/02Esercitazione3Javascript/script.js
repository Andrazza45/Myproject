const titoli =
[
 //...
];

titoli.push('io, robot');

let altriLibri = ['I Malavoglia','I promessi Sposi',''];
let tutti = [titoli,altriLibri];
console.log(tutti);
for(let index  = 0; index < tutti.length; index++)
{
	for(let j =0; j < tutti[index].length; j ++)
	{
	console.log(tutti[index][j]);	
	}
    
}
for (const titolo of titoli) {
    console.log(titolo);
}


tutti[1]
.filter(t => console.log(t.startsWith("I")))
.forEach(t => console.log(t));


const auto =
{
    marca: 'fiat',
    modello: 'punto',

    stampa: function()
    {
        return  this.modello + ' '+this.marca;
    }
    

}
function Auto(_marca, _modello)
{
    return {//boH

        marca: _marca,
        modello: _modello,
    }

    function Stampa()
    {
        return  this.modello + ' '+this.marca;
    }
}
function Auto(marca, modello)
{
    this.marca = marca;
    this.modello = modello;
    this.stampa = function ()
    {
        return `marca: ${this.marca}, modello: ${this.modello}`; 
    }
class Auto
{
    constructor(modello, classe)
    {
        this.modello = modello;
        this.classe = classe ;
    }
}

}
// auto.cilindrata = 1100;


const a = new Auto('Honda','Civic');
const b = new Auto('Toyota','IBRIS');
//stampa le costanti
console.info(auto.stampa());