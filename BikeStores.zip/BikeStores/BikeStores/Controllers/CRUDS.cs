﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BikeStores.Models;

using System.Reflection;
using BikeStores.Models.Services;
using System.Text.Json;
using Newtonsoft.Json;

namespace BikeStores.Controllers
{
    public class CRUDS : Controller
    {
        private string[][] toArray(dynamic modelList)
        {
            string[][] array = new string[modelList.Count][];
            string tipo = modelList[0].GetType().Name;
            dynamic obj;
            int ncol = 0;
            string[] row = null;
            for (int i = 0; i < modelList.Count; i++)
            {
                switch (tipo)
                {
                    case"Dipendente":
                        obj = modelList[i] as Dipendente;
                        ncol = obj.GetType().GetFields().Length - 1;
                        row = new string[ncol];
                        row[0] = obj.Id.ToString()+" pattern = ^[0-9]+$"; 
                        row[1] = obj.FirstName+" pattern = ^[a-zA-Z]+[0-9]*$";
                        row[2] = obj.LastName+" pattern = ^[a-zA-Z]+[0-9]*$";
                        row[3] = obj.Email + " pattern = ^[a-zA-Z0-9_.+-]+@+[a-zA-Z0-9-]+\\.[a-zA-Z-.]+$";
                        row[4] = obj.Phone + " pattern = ^[0-9]{10}$";
                        row[5] = obj.Active.ToString() +" pattern = ^[0-1]{1}$";
                        row[6] = obj.Store_id.ToString() +" pattern = ^[0-9]+$";
                        row[7] = obj.Manager_id.ToString() +" pattern = ^[0-9]+$";
                        row[8] = obj.Admin.ToString() +" pattern = ^[0-1]{1}$";
                        row[9] = obj.hashedInput +" pattern = ^[a-zA-Z!?-_]+[0-9]*$";
                        break;
                    case"Cliente":
                        obj = modelList[i] as Cliente;
                        ncol = obj.GetType().GetFields().Length - 1;
                        row = new string[ncol];
                        row[0] = obj.Customer_id.ToString() +" pattern = ^[0-9]+$";
                        row[1] = obj.FirstName +" pattern = ^[a-zA-Z]+[0-9]*$";
                        row[2] = obj.LastName +" pattern = ^[a-zA-Z]+[0-9]*$";
                        row[3] = obj.Phone + " pattern = ^[0-9]{10}$";
                        row[4] = obj.Email+ " pattern = ^[a-zA-Z0-9_.+-]+@+[a-zA-Z0-9-]+\\.[a-zA-Z-.]+$";
                        row[5] = obj.Street +" pattern = ^[0-9]+$";
                        row[6] = obj.City +" pattern = ^[a-zA-Z]+$";
                        row[7] = obj.State + " pattern = ^[a-zA-Z]{2}$";
                        row[8] = obj.Zip_code +" pattern = ^[0-9]{5}$";
                        row[9] = obj.hashedInput +" pattern = ^[a-zA-Z!?_-]+[0-9]*$";
                        break;
                    case"Prodotto":
                        obj = modelList[i] as Prodotto;
                        ncol = obj.GetType().GetFields().Length - 1;
                        row = new string[ncol];
                        row[0] = obj.Product_id.ToString() +" pattern = ^[0-9]+$";
                        row[1] = obj.Product_name +" pattern = ^[a-zA-Z]+[0-9]*$";
                        row[2] = obj.Brand_id.ToString() +" pattern = ^[0-9]+$";
                        row[3] = obj.Category_id.ToString() +" pattern = ^[0-9]+$";
                        row[4] = obj.Model_year.ToString() +" pattern = ^[0-9]+$";
                        row[5] = (obj.List_price.ToString()).Replace(',','.') + " pattern = ^[0-9]+\\.[0-9]{2}$";
                        break;
                    case"Marca":
                        obj = modelList[i] as Marca;
                        ncol = obj.GetType().GetFields().Length - 1;
                        row = new string[ncol];
                        row[0] = obj.Id.ToString() +" pattern = ^[0-9]+$";
                        row[1] = obj.Brand_name +" pattern = ^[a-zA-Z]+[0-9]*$";
                        break;
                    case"Categoria":
                        obj = modelList[i] as Categoria;
                        ncol = obj.GetType().GetFields().Length - 1;
                        row = new string[ncol];
                        row[0] = obj.Category_id.ToString() +" pattern = ^[0-9]+$";
                        row[1] = obj.Category_name +" pattern = ^[a-zA-Z]+[0-9]*$";
                        break;
                    case"Ordine":
                        obj = modelList[i] as Ordine;
                        ncol = obj.GetType().GetFields().Length-1;
                        row = new string[ncol];
                        row[0] = obj.Order_id.ToString() +" pattern = ^[0-9]+$";
                        row[1] = obj.Customer_id.ToString() +" pattern = ^[0-9]+$";
                        row[2] = obj.Order_status.ToString() +" pattern = ^[0-4]{1}$";
                        row[3] = obj.Order_date.ToString()+ " pattern = ^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/[0-9]{4}$";
                        row[4] = obj.Required_date.ToString() + " pattern = ^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/[0-9]{4}$";
                        row[5] = obj.Shipped_date.ToString() + " pattern = ^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/[0-9]{4}$";
                        row[6] = obj.Store_id.ToString() +" pattern = ^[0-9]+$ onload=getProducts("+obj.Store_id.ToString()+")";
                        row[7] = obj.Staff_id.ToString() +" pattern = ^[0-9]+$";
                        break;
                    case"Negozio":
                        obj = modelList[i] as Negozio;
                        ncol = obj.GetType().GetFields().Length -1;
                        row = new string[ncol];
                        row[0] = obj.Store_id.ToString() +" pattern = ^[0-9]+$";
                        row[1] = obj.Store_name +" pattern = ^[a-zA-Z]+[0-9]*$";
                        row[2] = obj.Phone + " pattern = ^[0-9]{10}$";
                        row[3] = obj.Email + " pattern = ^[a-zA-Z0-9_.+-]+@+[a-zA-Z0-9-]+\\.[a-zA-Z-.]+$";
                        row[4] = obj.Street + " pattern = ^[0-9]+$";
                        row[5] = obj.City +" pattern = ^[a-zA-Z]+$";
                        row[6] = obj.State +" pattern = ^[a-zA-Z]{2}$";
                        row[7] = obj.Zip_code +" pattern = ^[0-9]{5}$";
                        break;
                }
                array[i] = row;
            }
            return array;
        }
        private FieldInfo[] getFieldsInfo(string tipo)
        {
            FieldInfo[] array = new FieldInfo[10];
            switch (tipo)
            {
                case"Dipendente":
                    array = typeof(Dipendente).GetFields();
                    break;
                case"Cliente":
                    array = typeof(Cliente).GetFields();
                    break;
                case"Negozio":
                    array = typeof(Negozio).GetFields();
                    break;
                case"Prodotto":
                    array = typeof(Prodotto).GetFields();
                    break;
                case"Marca":
                    array = typeof(Marca).GetFields();
                    break;
                case"Categoria":
                    array = typeof(Categoria).GetFields();
                    break;
                case"Ordine":
                    array = typeof(Ordine).GetFields();
                    break;

            }
            return array;
        }
        public IActionResult Details(int id, string tipo)
        {
            Fetch f = new Fetch(id, tipo);
            return View(f);
        }
        public IActionResult Crud(string tipo, string option, string[] values, int id,string email)
        {
            string[] filters = new string[11];
            if(tipo == "Cliente" || tipo =="Dipendente")
            {
                values[values.Length - 1] = Crypto._MD5(values[values.Length - 1]); 
            }

            Cruds c = new Cruds(option, tipo, values, filters, id);
            ViewBag.errore = c.getResponse();
            Traduzione translater = new Traduzione();
            string dbmodel = translater.Translate(tipo);
            string controller=c.getSchemaName(dbmodel);
            
            if (controller =="sales")
            {
                controller ="Utenti";
            }
            else {
                controller ="Prodotti";
            }
            string action = "Cruds";

            object diz = new{};
            if (email != null)
            {
                action = "MyOrders";
                diz = new { email = email };
            }
            else { diz = new { tipo = tipo };}
            return RedirectToAction(action, controller,diz);
        }
        public IActionResult Create(string tipo,int admin, int UI,string email,int store_id)
        {
            if (tipo =="Dipendente" || tipo =="Cliente")
            {
                return RedirectToAction("Register","Utenti", new { value = tipo });
            }
            else
            {
                Fetch f = new Fetch(0, "Negozio");
                List<Negozio> negozi = f.negozi;
                string[] idsN = new string[negozi.Count];
                for (int i = 0; i < negozi.Count; i++)
                {
                    idsN[i] = negozi[i].Store_id+"-"+negozi[i].Store_name;  
                }
                ViewBag.array = this.getFieldsInfo(tipo);
                ViewBag.tipo = tipo;
                ViewBag.Id = UI;
                ViewBag.store_id = store_id;
                ViewBag.admin = admin;
                ViewBag.email = email;
                ViewBag.negozi = idsN;
                if (tipo == "Ordine")
                {
                    List<Prodotto> prodotti = Negozio.getProducts(store_id);
                    return View(prodotti);
                }
                return View();
            }
        }
        public IActionResult Update(string tipo, int id,int admin, int UI,string email)
        {
            ViewBag.array = this.getFieldsInfo(tipo);
            Fetch f = new Fetch(id, tipo);
            List<Dipendente> dipendenti = f.dipendenti;
            List<Cliente> clienti = f.clienti;
            List<Negozio> negozi = f.negozi;
            List<Prodotto> prodotti = f.prodotti;
            List<Marca> marche = f.marche;
            List<Categoria> categorie = f.categorie;
            List<Ordine> ordini = f.ordini;
            ViewBag.tipo = tipo;
            ViewBag.Id = id;
            ViewBag.UI = UI;
            ViewBag.admin = admin;
            ViewBag.email = email;
            switch (tipo)
            {
                case"Dipendente": ViewBag.values = this.toArray(dipendenti); break;
                case"Cliente": ViewBag.values = this.toArray(clienti); break;
                case"Prodotto": ViewBag.values = this.toArray(prodotti); break;
                case"Marca": ViewBag.values = this.toArray(marche); break;
                case"Categoria": ViewBag.values = this.toArray(categorie); break;
                case"Ordine": ViewBag.values = this.toArray(ordini); break;
                case"Negozio": ViewBag.values = this.toArray(negozi); break;

            }
            if (tipo == "Ordine")
            {
                prodotti = Negozio.getProducts(ordini[0].Store_id);
                return View(prodotti);   
            }
            return View();
        }
        [HttpPost]
        public IActionResult MakeOrder(int ID,string email, int store_id, int idC, string OQ)
        {
            List<Scontrino> objs = new List<Scontrino>();
            List<Dictionary<string, object>> dataList = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(OQ);
            foreach (var data in dataList)
            {
                string[] arr = new string[3];
                int i = 0;
                foreach (var kvp in data)
                {
                    arr[i] = kvp.Value.ToString();
                    i++;
                }
                Scontrino obj = new Scontrino(0, 0, int.Parse(arr[0]), int.Parse(arr[2]), decimal.Parse(arr[1]), 0); 
                objs.Add(obj);
            }
            Ordine.MakeOrder(ID, store_id, idC, objs);
            return RedirectToAction("MyOrders","Utenti",new {email = email});
        }

    }
}