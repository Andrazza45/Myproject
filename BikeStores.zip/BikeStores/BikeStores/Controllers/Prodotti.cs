﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BikeStores.Models;

namespace BikeStores.Controllers
{
    public class Prodotti : Controller
    {
        public IActionResult Details(int id,string tipo)
        {
            Fetch f = new Fetch(id,tipo);
            
            return View(f);
        }
        public IActionResult Cruds(string tipo)
        {
            Fetch f = new Fetch(0, tipo);

            return View(f);
        }
    }
}
