﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using BikeStores.Models;
using PrestitiVideoteca.Models;
using System.Data.SqlClient;
using Core_PrestitiVideoteca.Service;
using System.Reflection;

namespace BikeStores.Controllers
{
    public class Utenti : Controller
    {
        private SqlConnection sqlconnection;
        private List<object> list;

        public Utenti(){
        this.sqlconnection = new Connection().Open(0);
        this.list = new List<object>();
        }
        private int getAdmin(List<Dipendente> employes,string email)
        {
            foreach (Dipendente emp in employes)
            {
                if (emp.Email == email)
                {
                    return emp.Admin;
                }
            }
            return -1;
        }

        public IActionResult DashboardE(string firstname, string lastname, string email, string phone, int active, int store_id,int admin, int manager_id,string pwd, string tipo)
        {
            if (ViewBag.email == null)
            {
                ViewBag.email = email;
                ViewBag.password = pwd;
            }

            if (tipo == "Register")
            {
                Dipendente s = new Dipendente(0,firstname,lastname,email,phone, 1, store_id, manager_id, admin, pwd);

                var type = typeof(Dipendente);
                var properties = type.GetFields();
                ViewBag.Array = properties;

                Gestionale g = new Gestionale(s,type);
                if (g.AddUtente(s) == 0)
                {
                    ViewBag.Nominativo = email;
                    Fetch f = new Fetch(0, null);
                    List<Dipendente> employes = f.dipendenti;

                    ViewBag.admin = this.getAdmin(employes,email);

                    this.list.Add(f);
                    List<string[][]> mat = Prodotto.PopulateListProduct(this.sqlconnection);
                    this.list.Add(mat);
                    ViewBag.password = "Y";
                    return View(this.list);
                }
                else { ViewBag.errore = "Utente già esistente, e-mail non valida!!"; return View(); }
            }
            else
            {
                Dipendente s = new Dipendente(0,null ,null, ViewBag.email, null,0,0,0,0, ViewBag.password);
                var type = typeof(Dipendente);
                Gestionale g = new Gestionale(s,type);
                if (g.Login(s) == 0)
                {
                    ViewBag.Nominativo = email;
                    Fetch f = new Fetch(0, null);
                    List<Dipendente> employes = f.dipendenti;

                    ViewBag.admin = this.getAdmin(employes, email);

                    this.list.Add(f);
                    List<string[][]> mat =Prodotto.PopulateListProduct(this.sqlconnection);
                    this.list.Add(mat);
                    ViewBag.password = "Y";
                    return View(this.list);
                }
                else { ViewBag.errore = "Errore di accesso!!"; return View(); }


            }
        }

        public IActionResult DashboardC(string firstName, string lastName, string phone, string email, string street, string city, string state, string zip_code, string pwd, string tipo)
        {
            if (ViewBag.email == null)
            {
                ViewBag.email = email;
                ViewBag.password = pwd;
            }

            if (tipo == "Register")
            {
                Cliente s = new Cliente(0,firstName,lastName,phone,email,street,city,state,zip_code,pwd);
                var type = typeof(Cliente);
                var properties = type.GetFields();
                ViewBag.Array = properties;
                Gestionale g = new Gestionale(s,type);
                if (g.AddUtente(s) == 0)
                {
                    ViewBag.Nominativo = email;
                    Fetch f = new Fetch(0, null);
                    this.list.Add(f);
                    List<string[][]> mat = Prodotto.PopulateListProduct(this.sqlconnection);
                    this.list.Add(mat);
                    ViewBag.password = "Y";
                    return View(this.list);
                }
                else { ViewBag.errore = "Utente già esistente, e-mail non valida!!"; return View(); }
            }
            else
            {
                Cliente s = new Cliente(0, null, null, null, ViewBag.email, null, null, null,null, ViewBag.password);
                var type = typeof(Cliente);
                Gestionale g = new Gestionale(s, type);
                if (g.Login(s) == 0)
                {
                    ViewBag.Nominativo = email;
                    Fetch f = new Fetch(0, null);
                    list.Add(f);
                    List<string[][]> mat = Prodotto.PopulateListProduct(this.sqlconnection);
                    this.list.Add(mat);
                    ViewBag.password = "Y";
                    return View(this.list);
                }
                else { ViewBag.errore = "Errore di accesso!!"; return View();}


            }
        }
        public IActionResult Register(string value)//Value combo
        {
           
            switch (value)
            {
                case "Dipendente": ViewBag.tipo = "Dipendente"; ViewBag.admin = 0; ViewBag.array = typeof(Dipendente).GetFields();break;
                case "Cliente": ViewBag.tipo = "Cliente"; ViewBag.admin = 0; ViewBag.array = typeof(Cliente).GetFields(); break;
                case "Admin": ViewBag.tipo = "Dipendente"; ViewBag.admin = 1; ViewBag.array = typeof(Dipendente).GetFields(); break;
            }
            return View();
        }
        public IActionResult Login(string value)
        {
            switch (value)
            {
                case "Dipendente": ViewBag.tipo = "Dipendente"; ViewBag.admin = 0; ViewBag.array = typeof(Dipendente).GetProperties(); break;
                case "Cliente": ViewBag.tipo = "Cliente"; ViewBag.admin = 0; ViewBag.array = typeof(Cliente).GetProperties(); break;
            }
            return View();
        }

        public IActionResult Cruds(string tipo,int admin,bool profilo,string email)
        {
            int id = 0;
            if (tipo == "Cliente" || tipo == "Dipendente")
            {
                if (tipo == "Cliente")
                {
                    id = Cliente.getIdAssociated(email);
                }
                else
                {
                    id = Dipendente.getIdAssociated(email);
                }
            }
            if (id == -1)
            {
                id = 0;
            }
            Fetch f = new Fetch(id, tipo);
            ViewBag.admin = admin;
            ViewBag.mask = profilo;
            return View(f);
        }
        public IActionResult MyOrders(string email)
        {
            List<Ordine> orders = Cliente.getMyOrders(email);
            if (orders.Count > 0)
            {
                ViewBag.fields = orders[0].arr;
            }
            else { ViewBag.fields = null; }
            ViewBag.email = email;
            ViewBag.UI = Cliente.getIdAssociated(email);
            return View(orders);
        }

        public IActionResult Nuovo(string op)
        {
            if (op == "Register")
            {
                ViewBag.message = "Con quale ruolo vuoi registrarti?";
            }
            else
            {
                ViewBag.message = "Con quale ruolo vuoi entrare?";
            }
            ViewBag.type = op;
            return View();
        }
        public IActionResult StoreDetails(int id, string tipo)
        {
            Fetch f = new Fetch(id, tipo);

            return View(f);
        }

    }
}
