﻿using System.Security.Cryptography;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Reflection;
using System.Collections.Generic;
using Core_PrestitiVideoteca.Service;

namespace BikeStores.Models
{
    public class Cliente
    {
        public FieldInfo[] arr;
        public int Customer_id;
        public string FirstName;
        public string LastName;
        public string Phone;
        public string Email;
        public string Street;
        public string City;
        public string State;
        public string Zip_code;
        public string hashedInput;
        public Cliente(int customer_id, string firstName, string lastName, string phone, string email, string street, string city, string state, string zip_code, string pwd)
        {
            this.Customer_id = customer_id;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Phone = phone;
            this.Email = email;
            this.Street = street;
            this.City = city;
            this.State = state;
            this.Zip_code = zip_code;
            string input = pwd;
            this.hashedInput = pwd;
            if (input != null && this.FirstName != null)
            {
                // Creazione del provider di crittografia MD5
                using (MD5 md5 = MD5.Create())
                {
                    // Calcola l'hash MD5 del testo di input
                    byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                    byte[] hashBytes = md5.ComputeHash(inputBytes);

                    // Converti il risultato in una stringa esadecimale
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < hashBytes.Length; i++)
                    {
                        builder.Append(hashBytes[i].ToString("x2"));
                    }

                    this.hashedInput = builder.ToString();
                }
            }
            

        }
        public static int getIdAssociated(string email)
        {
            SqlConnection sqlconnection;
            SqlDataReader sdr;
            sqlconnection = new Connection().Open(0);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            List<Ordine> orders = new List<Ordine>();
            string sql = "select c.customer_id from sales.customers c " +
                         "WHERE c.email = '" + email + "'";
            cmd.CommandText = sql;
            sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                return !sdr.IsDBNull(0) ? sdr.GetInt32(0) : -1;
            }
            return -1;
        }
        public static List<Ordine> getMyOrders(string email)
        {
            SqlConnection sqlconnection;
            SqlDataReader sdr;
            sqlconnection = new Connection().Open(0);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            List<Ordine> orders = new List<Ordine>();
            string sql = "select * from sales.orders o " +
                         "INNER JOIN sales.customers c ON o.customer_id = c.customer_id " +
                         "WHERE c.email = '" + email+"'";
            cmd.CommandText = sql;
            sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                (orders).Add(
                new Ordine(
                !sdr.IsDBNull(0) ? sdr.GetInt32(0) : 0,
                !sdr.IsDBNull(1) ? sdr.GetInt32(1) : 0,
                !sdr.IsDBNull(2) ? sdr.GetByte(2) : 0,
                !sdr.IsDBNull(3) ? sdr.GetDateTime(3) : System.DateTime.MinValue,
                !sdr.IsDBNull(4) ? sdr.GetDateTime(4) : System.DateTime.MinValue,
                !sdr.IsDBNull(5) ? sdr.GetDateTime(5) : System.DateTime.MinValue,
                !sdr.IsDBNull(6) ? sdr.GetInt32(6) : 0,
                !sdr.IsDBNull(7) ? sdr.GetInt32(7) : 0
                ));
            }
            sdr.Close();
            return orders;

        }
    }
}
