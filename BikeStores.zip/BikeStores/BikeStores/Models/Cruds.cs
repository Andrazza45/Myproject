﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using BikeStores.Models.Services;
using Core_PrestitiVideoteca.Service;

namespace BikeStores.Models
{
    public class Cruds
    {
        private string tipo;
        private string modello;
        private string[] parameters = new string[100];
        private string[] filters = new string[10];

        private SqlConnection sqlconnection;
        SqlCommand cmd = new SqlCommand();
        SqlDataReader sdr = null;

        private string response;
        public string getResponse() { return this.response; }
        public Cruds(string tipo, string modello, string[] values, string[] filters,int id)
        {
            this.tipo = tipo;
            Traduzione translater = new Traduzione();
            string[] sales = { "Dipendente", "Cliente", "Ordine", "Negozio" };

            if (!Array.Exists(sales, element => element == modello))
            {
                this.modello = "production.";
            }
            else
            {
                this.modello = "sales.";
            }
            modello = translater.Translate(modello);
            this.modello += modello;
            this.filters = filters;
            this.sqlconnection = new Connection().Open(0);
            this.cmd.Connection = sqlconnection;

            string [] fields = getColumnsNames(modello,0,false);
            this.sdr.Close();
            for (int i = 0; i < values.Length; i++)
            {
                if (fields[i + 1].IndexOf("date", StringComparison.CurrentCultureIgnoreCase) >= 0)
                {
                    if (fields[i + 1].IndexOf("order", StringComparison.CurrentCultureIgnoreCase) >= 0)
                    {
                        values[i] = DateTime.Now.ToString();
                    }
                    else { values[i] = DateTime.Now.AddDays(5).ToString(); }
                }
            }

            switch (this.tipo)
            {
                case "Create":this.create(values); break;
            
                case "Update":
                this.bindParameters(fields, values);
                this.update(id,fields[0]);
                break;
                    
                case "Delete": this.delete(id,fields[0]); break;
            }
        }
        private int getTotalRows()
        {
            int c = 0;
            while (this.sdr.Read())
            {
                c++;
            }
            return c;
        }
        public string getSchemaName(string model)
        {
            string sql = "SELECT TABLE_SCHEMA " +
                    "FROM INFORMATION_SCHEMA.TABLES " +
                    "WHERE TABLE_CATALOG = 'BikeStores' " +
                    "AND TABLE_NAME = '" + model + "'";
            this.sdr.Close();
            this.cmd.CommandText = sql;
            this.cmd.CommandType = CommandType.Text;
            this.sdr = this.cmd.ExecuteReader();
            while (this.sdr.Read())
            {
             return this.sdr.GetSqlString(0).Value;
            }
            return "";
        }
        private string[] getColumnsNames(string modello,int nColumns, bool onlyOne = false)
        {
            string[] names;
            string sql="";
            string limit = onlyOne == true ? " TOP 1 ":" ";

            sql += "SELECT"+limit+"column_name "+
                  "FROM information_schema.columns " +
                  "WHERE table_catalog = 'BikeStores' " +
                  "AND table_name = '"+modello+"'";
            
            this.cmd.CommandText = sql;
            this.cmd.CommandType = CommandType.Text;
            this.sdr = this.cmd.ExecuteReader();
            if (nColumns == 0)
            {
                nColumns = this.getTotalRows();
                this.sdr.Close();
                names = this.getColumnsNames(modello, nColumns,onlyOne);
            }
            else
            {
                names = new string[nColumns];
                int i = 0;
                while (this.sdr.Read())
                {
                    names[i] = this.sdr.GetSqlString(0).Value;
                    i++;
                }
                return names;
            }
            return names;
        }
        private void bindParameters(string[] fields,string[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
              this.parameters[i] = fields[i + 1] + "='" + values[i] + "'";
            }
        }
        private void update(int id,string name)
        {
            string sql = "update "+this.modello+" set ";
            for (int i = 0; this.parameters[i] != null; i++)
            {
                if (this.parameters[i+1] != null)
                {
                    sql += parameters[i] + ", ";
                }
                //filters, orders
                else { sql += parameters[i] + " where "+name+"="+id; }
            }
            this.cmd.CommandText = sql;
            this.cmd.CommandType = CommandType.Text;
            this.sdr = this.cmd.ExecuteReader();
            this.response = "Riga modificata con successo!";
        }
        private void create(string[] values)
        {
            string sql = "insert into " + this.modello + " values(";
            for (int i = 0;i < values.Length; i++)
            {
                if (i != values.Length-1)
                {
                    sql +="'"+values[i] + "', ";
                }
                else { sql += "'" +values[i] + "')"; }
            }
            this.cmd.CommandText = sql;
            this.cmd.CommandType = CommandType.Text;
            this.sdr = this.cmd.ExecuteReader();
            this.response = "Riga aggiunta con successo!";
        }
        private void delete(int id, string name)
        {
            string sql = "Delete FROM " + this.modello + " where "+name +"=" +id;
            this.cmd.CommandText = sql;
            this.cmd.CommandType = CommandType.Text;
            this.sdr = this.cmd.ExecuteReader();
            this.response = "Riga eliminata con successo!";
        }


    }
}
