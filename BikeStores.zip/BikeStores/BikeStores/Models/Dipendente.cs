﻿using System.Security.Cryptography;
using System.Text;
using System.Reflection;
using System.Data.SqlClient;
using System.Collections.Generic;
using Core_PrestitiVideoteca.Service;

namespace BikeStores.Models
{
    public class Dipendente
    {
        public FieldInfo[] arr;
        public int Id;
        public string FirstName;
        public string LastName;
        public string Email;
        public string Phone;
        public int Active;
        public int Store_id;
        public int Manager_id;
        public int Admin;
        public string hashedInput;

        public Dipendente(int id, string firstname, string lastname, string email, string phone, int active, int store_id, int manager_id, int admin, string pwd)
        {
            this.Id = id;
            this.FirstName = firstname;
            this.LastName = lastname;
            this.Email = email;
            this.Phone = phone;
            this.Active = active;
            this.Store_id = store_id;
            this.Manager_id = manager_id;
            this.Admin = admin;
            string input = pwd;
            this.hashedInput = pwd;
            if (input != null && this.FirstName != null)
            {
                // Creazione del provider di crittografia MD5
                using (MD5 md5 = MD5.Create())
                {
                    // Calcola l'hash MD5 del testo di input
                    byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                    byte[] hashBytes = md5.ComputeHash(inputBytes);

                    // Converti il risultato in una stringa esadecimale
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < hashBytes.Length; i++)
                    {
                        builder.Append(hashBytes[i].ToString("x2"));
                    }

                    this.hashedInput = builder.ToString();
                }
            }

        }
        public static int getIdAssociated(string email)
        {
            SqlConnection sqlconnection;
            SqlDataReader sdr;
            sqlconnection = new Connection().Open(0);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            List<Ordine> orders = new List<Ordine>();
            string sql = "select s.staff_id from sales.staffs s " +
                         "WHERE s.email = '" + email + "'";
            cmd.CommandText = sql;
            sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                return !sdr.IsDBNull(0) ? sdr.GetInt32(0) : -1;
            }
            return -1;
        }
    }
}
