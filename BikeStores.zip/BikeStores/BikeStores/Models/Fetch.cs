﻿using Core_PrestitiVideoteca.Service;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace BikeStores.Models
{
    public class Fetch
    {
        public string Tipo;
        public int Id = 0;

        public FieldInfo[][] allProperties = new FieldInfo[9][];
        public List<Dipendente> dipendenti = new List<Dipendente>();
        public List<Cliente> clienti = new List<Cliente>();
        public List<Negozio> negozi = new List<Negozio>();
        public List<Prodotto> prodotti = new List<Prodotto>();
        public List<Scontrino> scontrino= new List<Scontrino>();
        public List<Marca> marche = new List<Marca>();
        public List<Categoria> categorie = new List<Categoria>();
        public List<Ordine> ordini= new List<Ordine>();
        public string[] array = new string[9];//??

        private SqlConnection sqlconnection;
        SqlDataReader sdr;
        public Fetch(int id, string tipo )
        {
            this.Tipo = tipo;
            this.Id = id;
            this.sqlconnection = new Connection().Open(0);
            this.caricadati();
        }

        public int getTableIndex(string tipo)
        {
            int index = 0;
            foreach (FieldInfo[] field in this.allProperties)
            {
                if (field[0].DeclaringType.Name == tipo)
                {
                 return index;
                }
                index++;
            }
            return -1;
        }
        public void caricadati()
        {
            
            string sql = "select * from production.products p ";
            if (this.Id != 0)
            {
                sql += "where p.product_id = " + this.Id;
            }
            string sql1 = "select * from sales.stores s ";
            if (this.Id != 0)
            {
                sql1 += "where s.store_id = " + this.Id;
            }
            string sql2 = "select * from production.brands";
            string sql3 = "select * from production.categories";

            string sql4 = "select * from sales.staffs s ";
            if (this.Id != 0)
            {
                sql4 += "where s.staff_id = " + this.Id;
            }
            string sql5 = "select * from sales.customers s ";
            if (this.Id != 0)
            {
                sql5 += "where s.customer_id = " + this.Id;
            }
            string sql6 = "select * from sales.orders o";
            if (this.Id != 0)
            {
             sql6 += " where o.order_id = " + this.Id;
            }
            string sql7 = "select * from sales.order_items oi";
            if (this.Id != 0)
            {
                sql7 += " where oi.order_id = " + this.Id;
            }

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandType = CommandType.Text;
            int index = 0;
            if (this.Tipo == null || this.Tipo == "OrdineProdotto")
            {
                cmd.CommandText = sql7;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {

                    (this.scontrino).Add(
                    new Scontrino(

                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetInt32(1) : 0,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetInt32(2) : 0,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetInt32(3) : 0,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetDecimal(4) : 0,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetDecimal(5) : 0
                 ));

                }
                this.sdr.Close();

                var properties = typeof(Scontrino).GetFields();

                this.allProperties[index] = properties;
                index++;

            }
            if (this.Tipo == null || this.Tipo == "Prodotto")
            {
                cmd.CommandText = sql;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {

                    (this.prodotti).Add(
                    new Prodotto(

                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetInt32(2) : 0,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetInt32(3) : 0,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetInt16(4) : 0,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetDecimal(5) : 0
                 ));

                }
                this.sdr.Close();

                var properties = typeof(Prodotto).GetFields();
                
                this.allProperties[index] =properties;
                index++;

            }
            if (this.Tipo == null || this.Tipo == "Negozio")
            {
                cmd.CommandText = sql1;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {

                    (this.negozi).Add(
                    new Negozio(

                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetString(2) : null,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetString(3) : null,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetString(4) : null,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetString(5) : null,
                    !this.sdr.IsDBNull(6) ? this.sdr.GetString(6) : null,
                    !this.sdr.IsDBNull(7) ? this.sdr.GetString(7) : null
                ));

                }
                this.sdr.Close();

                var properties = typeof(Negozio).GetFields();
                
                this.allProperties[index] = properties;
                index++;

            }
            if (this.Tipo == null || this.Tipo == "Marca")
            {
                cmd.CommandText = sql2;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {

                    (this.marche).Add(
                    new Marca(
                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null
                ));

                }

                this.sdr.Close();

                var properties = typeof(Marca).GetFields();
                
                this.allProperties[index] = properties;
                index++;

            }
            if (this.Tipo == null || this.Tipo == "Categoria")
            {
                cmd.CommandText = sql3;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {

                    (this.categorie).Add(
                    new Categoria(


                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null
                    ));

                }
                this.sdr.Close();
                var properties = typeof(Categoria).GetFields();
                
                this.allProperties[index] = properties;
                index++;

            }

            if (this.Tipo == null || this.Tipo == "Dipendente")
            {
                cmd.CommandText = sql4;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {
                    (this.dipendenti).Add(
                    new Dipendente(
                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetString(2) : null,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetString(3) : null,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetString(4) : null,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetByte(5) : 0,
                    !this.sdr.IsDBNull(6) ? this.sdr.GetInt32(6) : 0,
                    !this.sdr.IsDBNull(7) ? this.sdr.GetInt32(7) : 0,
                    !this.sdr.IsDBNull(8) ? this.sdr.GetByte(8) : 0,
                    !this.sdr.IsDBNull(9) ? this.sdr.GetString(9) : null
                    ));

                }
                this.sdr.Close();
                var properties = typeof(Dipendente).GetFields();
                
                this.allProperties[index] = properties;
                index++;

            }

            if (this.Tipo == null || this.Tipo == "Cliente")
            {
                cmd.CommandText = sql5;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {
                    (this.clienti).Add(
                    new Cliente(
                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetString(2) : null,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetString(3) : null,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetString(4) : null,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetString(5) : null,
                    !this.sdr.IsDBNull(6) ? this.sdr.GetString(6) : null,
                    !this.sdr.IsDBNull(7) ? this.sdr.GetString(7) : null,
                    !this.sdr.IsDBNull(8) ? this.sdr.GetString(8) : null,
                    !this.sdr.IsDBNull(9) ? this.sdr.GetString(9) : null
                    ));

                }
                this.sdr.Close();

                var properties = typeof(Cliente).GetFields();

                this.allProperties[index] = properties;
                index++;

            }
            if (this.Tipo == null || this.Tipo == "Ordine")
            {
                cmd.CommandText = sql6;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {
                    (this.ordini).Add(
                    new Ordine(
                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetInt32(1) : 0,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetByte(2) : 0,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetDateTime(3) : System.DateTime.MinValue,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetDateTime(4) : System.DateTime.MinValue,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetDateTime(5) : System.DateTime.MinValue,
                    !this.sdr.IsDBNull(6) ? this.sdr.GetInt32(6) : 0,
                    !this.sdr.IsDBNull(7) ? this.sdr.GetInt32(7) : 0

                    ));

                }
                this.sdr.Close();

                var properties = typeof(Ordine).GetFields();

                this.allProperties[index] = properties;
                index++;

            }
        }

    }
}

