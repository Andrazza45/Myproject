﻿using BikeStores.Models;
using BikeStores.Models.Services;
using Core_PrestitiVideoteca.Service;
using System;

using System.Data;
using System.Data.SqlClient;


using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
namespace PrestitiVideoteca.Models
{
    public class Gestionale
    {
        private dynamic S = null;
        private string[][] utenti;
        private string Ty = null;
        private SqlConnection sqlconnection;
        SqlDataReader sdr;
        public Gestionale(dynamic s, Type type)//obj stesso e tipo
        {
            this.S = s;
            this.Ty = type.Name.ToString();
            this.sqlconnection = new Connection().Open(0);
            Traduzione translater = new Traduzione();
            this.Ty = translater.Translate(this.Ty);
        }
        private int getLastId(SqlCommand cmd)
        {
            int id = 0;
            string x = this.Ty == "staffs" ? "staff_id" : "customer_id";
            string sql = "SELECT MAX(x."+x+") from sales." +this.Ty+" x";
            cmd.CommandText = sql;
            this.sdr = cmd.ExecuteReader();
            while (this.sdr.Read())
            {
              return !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0;
            }
            return id;
        }
        public int AddUtente(dynamic S)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandType = CommandType.Text;

            string sql = "select * from sales."+this.Ty;
            int id = this.getLastId(cmd);
            string sql1 ="insert into sales." + this.Ty + " values('";
            string str = "";
            switch (this.Ty)
            {
                case "staffs":
                str += /*(id+1) + "','"*/
                S.FirstName + "','" +
                S.LastName+ "','" +
                S.Email + "','" +
                S.Phone + "','" +
                "1" + "','" +
                S.Store_id + "','" +
                S.Manager_id + "','" +
                S.Admin + "','" +
                S.hashedInput + "')";
                break;
                case "customers":
                str += /*(id + 1) + "','"*/
                S.FirstName + "','" +
                S.LastName + "','" +
                S.Phone + "','" +
                S.Email + "','" +
                S.Street + "','" +
                S.City + "','" +
                S.State + "','" +
                S.Zip_code + "','" +
                S.hashedInput + "')";
                break;
            }
            sql1 += str;
            this.sdr.Close();
            cmd.CommandText = sql;
            this.sdr = cmd.ExecuteReader();

            getListByUserType(this.Ty,cmd);

                bool trovato = false;
                for (int i = 0; i < this.utenti.Length; i++)
                {
                //dynamic objcasted;
                //if (this.Ty == "staffs")
                //{
                // objcasted = (Dipendente)this.utenti[i];
                //}
                //else {objcasted = (Cliente)this.utenti[i];}

                if (this.utenti[i][0] == S.Email)
                    {
                        trovato = true;
                        i = this.utenti.Length;
                    }
                }
                if (trovato == true)
                {
                    return -1;
                }
                else {
                
                cmd.CommandText = sql1;
                try
                {
                    this.sdr = cmd.ExecuteReader();
                    return 0;
                }
                catch (Exception SqlException)
                {
                    return -1;
                }

            }

        }
        public int Login(dynamic S)
        {
            string sql = "select * from sales." + this.Ty;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            this.sdr = cmd.ExecuteReader();

            getListByUserType(this.Ty, cmd);
            for (int i = 0; i <this.utenti.Length; i++)
            {
                //dynamic objcasted;
                //if (this.Ty == "staffs")
                //{
                // objcasted = (Dipendente)this.utenti[i];
                //}
                //else {objcasted = (Cliente)this.utenti[i];}

                if (this.utenti[i][0]== S.Email)
                {
                    
                    if (this.utenti[i][1] == Crypto._MD5(S.hashedInput) || S.hashedInput == "Y")
                    {
                        return 0;

                    }
                }
            }
            return -1;
        }
        private int getTotalRows()
        {
            int c = 0;
            while (this.sdr.Read())
            {
                c++;
            }
            return c; 
        }

        private void getListByUserType(string type, SqlCommand cmd)
        {
           
            int rows = this.getTotalRows();
            this.utenti = new string[rows][];

            for (int j = 0; j < this.utenti.Length; j++)
            {
                this.utenti[j] = new string[2];
            }

            this.sdr.Close();
            this.sdr = cmd.ExecuteReader();
            int i = 0;
            switch (this.Ty)
            {
                case "staffs":
                    while (this.sdr.Read())
                    {
                        this.utenti[i][0] = !this.sdr.IsDBNull(3) ? this.sdr.GetString(3) : "";
                        this.utenti[i][1] = !this.sdr.IsDBNull(9) ? this.sdr.GetString(9) : "";
                        i++;
                    }
                    break;
                case "customers":
                    while (this.sdr.Read())
                    {
                        this.utenti[i][0] = !this.sdr.IsDBNull(4) ? this.sdr.GetString(4) : null;
                        this.utenti[i][1] = !this.sdr.IsDBNull(9) ? this.sdr.GetString(9) : null;
                        i++;
                    }
                    break;

            }
            this.sdr.Close();
        }
    }
}
