﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Reflection;

namespace BikeStores.Models
{
    public class Magazzino
    {
        public FieldInfo[] arr;

        public int Store_id;
        public string Product_id;
        public int Quantity;
        public Magazzino(int store_id, string product_id, int quantity)
        {
            this.Store_id = store_id;
            this.Product_id = product_id;
            this.Quantity = quantity;
        }
    }
}
