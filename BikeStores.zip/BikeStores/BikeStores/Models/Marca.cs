﻿using System.Reflection;
namespace BikeStores.Models
{
    public class Marca
    {
        public FieldInfo[] arr;

        private int Id;
        public string Brand_name;
        public Marca(int id, string brand_name)
        {
            this.Id = id;
            this.Brand_name = brand_name;
        }
    }
}
