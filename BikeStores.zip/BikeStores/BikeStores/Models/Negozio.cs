﻿using Core_PrestitiVideoteca.Service;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Reflection;
namespace BikeStores.Models
{
    public class Negozio
    {
        public FieldInfo[] arr;

        public int Store_id;
        public string Store_name;
        public string Phone;
        public string Email;
        public string Street;
        public string City;
        public string State;
        public string Zip_code;

        public Negozio(int store_id, string store_name,string phone, string email,string street, string city, string state, string zip_code) {
        this.Store_id = store_id;
            this.Store_name = store_name;
            this.Phone = phone;
            this.Email = email;
            this.Street = street;
            this.City = city;
            this.State = state;
            this.Zip_code = zip_code;
        
        }
        public static List<Prodotto> getProducts(int idM)
        {
            List<Prodotto> prodotti = new List<Prodotto>();
            SqlConnection sqlconnection;
            SqlDataReader sdr;
            sqlconnection = new Connection().Open(0);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            string sql = "select p.* from production.stocks s " +
                         "INNER JOIN production.products p ON p.product_id = s.product_id " +
                         "WHERE s.store_id = '" + idM + "'";
            cmd.CommandText = sql;
            sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                prodotti.Add(
                    new Prodotto(
                    !sdr.IsDBNull(0) ? sdr.GetInt32(0) : 0,
                    !sdr.IsDBNull(1) ? sdr.GetString(1) : null,
                    !sdr.IsDBNull(2) ? sdr.GetInt32(2) : 0,
                    !sdr.IsDBNull(3) ? sdr.GetInt32(3) : 0,
                    !sdr.IsDBNull(4) ? sdr.GetInt16(4) : 0,
                    !sdr.IsDBNull(5) ? sdr.GetDecimal(5) : 0
                 ));
            }
            return prodotti;
        }
    }
}
