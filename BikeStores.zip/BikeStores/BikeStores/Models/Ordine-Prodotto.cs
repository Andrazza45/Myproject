﻿using System.Reflection;
namespace BikeStores.Models
{
    public class Scontrino
    {
        public FieldInfo[] arr;

        public int Order_Id;
        public int Item_Id;
        public int Product_Id;
        public int Quantity;
        public decimal Price;
        public decimal Discount;


        public Scontrino(int order_id,int item_id, int product_id, int quantity, decimal price, decimal discount) 
        {
            this.Order_Id = order_id;
            this.Item_Id = item_id;
            this.Product_Id = product_id;
            this.Quantity = quantity;
            this.Price = price;
            this.Discount = discount;
        }
    }
}
