﻿using Core_PrestitiVideoteca.Service;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
namespace BikeStores.Models
{
    public class Ordine
    {
        public FieldInfo[] arr;

        public int Order_id;
        public int Customer_id;
        public int Order_status;
        public DateTime Order_date;
        public DateTime Required_date;
        public DateTime Shipped_date;
        public int Store_id;
        public int Staff_id;

        public Ordine(int order_id, int customer_id, int order_status, DateTime order_date, DateTime required_date, DateTime shipped_date,int store_id, int staff_id)
        {
            this.Order_id = order_id;
            this.Customer_id = customer_id;
            this.Order_status = order_status;
            this.Order_date = order_date;
            this.Required_date = required_date;
            this.Shipped_date = shipped_date;
            this.Store_id = store_id;
            this.Staff_id = staff_id;
            this.arr = typeof(Ordine).GetFields();
            
        }
        public static void MakeOrder(int id,int store_id, int idC, List<Scontrino>OQ)
        {
        SqlConnection sqlconnection = new Connection().Open(0);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = sqlconnection;
        SqlDataReader sdr = null;
        string sql="";
            if (id == 0)
            {
                sql += "insert into sales.orders values(" +
                        idC + ",1,'" + DateTime.Now + "','" + DateTime.Now.AddDays(5) + "','" + DateTime.Now.AddDays(5) +
                        "'," + store_id +","+ "1" + ")";

                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;
                sdr = cmd.ExecuteReader();
                sdr.Close();
                sql = "SELECT TOP 1 o.order_id FROM sales.orders o ORDER BY o.order_id DESC";
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;
                sdr = cmd.ExecuteReader();
                int maxid = 0;
                while (sdr.Read())
                {
                    maxid = !sdr.IsDBNull(0) ? sdr.GetInt32(0) : 0;
                }
                sdr.Close();

                sql = "insert into sales.order_items values ";
                for (int i = 0; i < OQ.Count; i++)
                {
                    if (i != OQ.Count - 1)
                    {
                        sql += "("+ maxid +",'"+(i + 1)+"',"+ OQ[i].Product_Id + "," + OQ[i].Quantity+ ","+ OQ[i].Price +",0),";
                    }
                    else {
                        sql += "(" + maxid +",'"+(i+1)+"',"+OQ[i].Product_Id+ "," + OQ[i].Quantity + "," + OQ[i].Price + ",0)";
                    }
                    string sqlst = "UPDATE production.stocks set quantity = quantity -" + OQ[i].Quantity;
                    cmd.CommandText = sqlst;
                    cmd.CommandType = CommandType.Text;
                    sdr = cmd.ExecuteReader();
                    sdr.Close();
                }
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;
                sdr = cmd.ExecuteReader();
                sdr.Close();

            }
            else {
                for (int i = 0; i < OQ.Count; i++)
                {
                    sql = "UPDATE sales.order_items set quantity =" + OQ[i].Quantity +
                          " WHERE(SELECT op.q FROM sales.order_items op" +
                          " WHERE order_id =" + id + "AND product_id=" + OQ[i].Product_Id + ")<" + OQ[i].Quantity +
                          " AND order_id =" + id + "AND product_id=" + OQ[i].Product_Id;
                    cmd.CommandText = sql;
                    cmd.CommandType = CommandType.Text;
                    sdr = cmd.ExecuteReader();
                    if (sdr.RecordsAffected > 0)
                    {
                        sdr.Close();
                        sql = "UPDATE production.stocks set quantity = quantity-" + OQ[i].Quantity +
                                "-(SELECT op.q FROM sales.order_items op WHERE order_id =" + id + "AND product_id=" + OQ[i].Product_Id + ")" +
                                "WHERE product_id=" + OQ[i].Product_Id;
                        cmd.CommandText = sql;
                        cmd.CommandType = CommandType.Text;
                        sdr = cmd.ExecuteReader();
                        sdr.Close();

                    }
                    sql = "UPDATE sales.order_items set quantity =" + OQ[i].Quantity +
                    " WHERE(SELECT op.q FROM sales.order_items op" +
                    " WHERE order_id =" + id + "AND product_id=" + OQ[i].Product_Id + ")>" + OQ[i].Quantity +
                    " AND order_id =" + id + "AND product_id=" + OQ[i].Product_Id;
                    cmd.CommandText = sql;
                    cmd.CommandType = CommandType.Text;
                    sdr = cmd.ExecuteReader();
                    if (sdr.RecordsAffected > 0)
                    {
                        sdr.Close();
                        sql = "UPDATE production.stocks set quantity ="+ 
                              "quantity+(SELECT op.q FROM sales.order_items op WHERE order_id =" + id + "AND product_id=" + OQ[i].Product_Id + ")-"+OQ[i].Quantity +
                              "WHERE product_id=" + OQ[i].Product_Id;
                        cmd.CommandText = sql;
                        cmd.CommandType = CommandType.Text;
                        sdr = cmd.ExecuteReader();
                        sdr.Close();
                    }
                }
            }
        }
    }
}
