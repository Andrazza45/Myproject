﻿using Core_PrestitiVideoteca.Service;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
namespace BikeStores.Models
{
    public class Prodotto
    {
        public FieldInfo[] arr;
        public int Product_id;
        public string Product_name;
        public int Brand_id;
        public int Category_id;
        public int Model_year;
        public decimal List_price;

        public Prodotto(int Product_id, string Product_name, int Brand_id, int Category_id, int Model_year, decimal List_price)
        { 
            this.Product_id = Product_id;
            this.Product_name = Product_name;
            this.Brand_id = Brand_id;
            this.Category_id = Category_id;
            this.Model_year = Model_year;
            this.List_price = List_price;

        }

        public static List<string[][]> PopulateListProduct(SqlConnection sqlconnection)
        {
            int getTotalRows(SqlDataReader sdr)
            {
                int c = 0;
                while (sdr.Read())
                {
                    c++;
                }
                return c;
            }

            SqlDataReader sdr = null;
         List<string[][]> arr = new List<string[][]>();

         string sql = "SELECT p.product_id, p.product_name, p.list_price, b.brand_name, c.category_name " +
                         "FROM production.products p " +
                         "INNER JOIN production.brands b ON p.brand_id = b.brand_id " +
                         "INNER JOIN production.categories c ON p.category_id = c.category_id " +
                         "ORDER BY p.product_name ASC";

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            sdr = cmd.ExecuteReader();
            int rows = getTotalRows(sdr); 
            string[][] matrice = new string[rows][];

            for (int j = 0; j < matrice.Length; j++)
            {
                matrice[j] = new string[2];
            }

            int i = 0;
            sdr.Close();
            sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                string[] row = new string[sdr.FieldCount];
                row[0] = !sdr.IsDBNull(0) ? sdr.GetInt32(0).ToString() : null;
                row[1] = !sdr.IsDBNull(1) ? sdr.GetString(1) : null;
                row[2] = !sdr.IsDBNull(2) ? (sdr.GetDecimal(2)).ToString() : "0.0";
                row[3] = !sdr.IsDBNull(3) ? sdr.GetString(3) : null;
                row[4] = !sdr.IsDBNull(4) ? sdr.GetString(4) : null;
                matrice[i] = row;
                i++;
            }
             arr.Add(matrice);
             return arr;
        }
    }
}
