﻿class SearchParam {
    constructor(url) {
        this.URL = url;
    }
    getParam(param) {
        let params = (this.URL).split("?")[1];
        if (params.split("").includes('&')) {
            let vars = params.split("&");
            for (let i = 0; i < vars.length; i++) {
                if (vars[i].split("=")[0] == param) {
                    return vars[i].split("=")[1];
                }
            }
        }
        else {
            if (params.split("=")[0] == param) {
                return params.split("=")[1];
            }
        }
        return '';
    }

}

function reloadList(option) {
    //let table_OP = $('.Cart')[0];
    //let id_store = option.split("-")[0];
    //let rows = table_OP.rows;
    //for (let i = 1; i < rows.length; i++) {
    //    let cells = rows[i].cells;
    //    for (let j = 0; j < cells.length; j++) {
    //}
    let id_store = parseInt(option.split("-")[0]);
    let id_customer = parseInt($('#Customer_id').val());
    window.open('https://localhost:44378/CRUDS/Create?tipo=Ordine&admin=0&UI='+id_customer +'&store_id='+id_store);
    window.close();
}

function makeOrder(id) {
    let url = new SearchParam($('form')[0].action);
    let objs = [];
    let ordine = {};
    let products = $('input[type = checkbox]:checked');
    for (let i = 0; i < products.length; i++) {
        ordine = {};
        ordine.idP = parseInt(products[i].parentElement.parentElement.children[0].innerHTML);
        ordine.list_price = parseFloat(products[i].parentElement.parentElement.children[2].innerHTML);
        ordine.q = parseInt($($(products[i]).next('input')[0]).val());
        objs.push(ordine);
    }
    debugger;
    $.ajax({
        url: 'MakeOrder', // Specifica l'URL del controller e dell'azione a cui inviare la richiesta
        type: 'POST', // Metodo HTTP da utilizzare (POST nel caso di invio di dati)
        data: {
            ID: id,
            email:url.getParam("email"),
            store_id: parseInt($('.stores')[0].value.split("-")[0]),
            idC: parseInt($('#Customer_id').val()),
            OQ: JSON.stringify(objs)
        },
        success: function (result, status, settings) {
            console.log('success');
            //debugger;
            window.open('https://localhost:44378/Utenti/MyOrders?email=' + url.getParam("email"));
            window.close();
        },
        error: function (error) {
            // Gestisci eventuali errori durante la richiesta
            console.error(error.responseText);
        }
    });
}
function redirect() {
    let tipo = $('#me')[0].ariaLabel;
    let email = $('body p')[0].textContent.split("HomePage ")[1];
    window.open("https://localhost:44378/Utenti/Cruds?tipo="+tipo+"&admin=1&profilo=true&email="+email+"%20");
   
}

    $('.add').on('click', function () {
        let add = this;
        let quantity = $(this).next('input')[0];
        if (add.checked == true) {
            quantity.disabled = false;
        } else { quantity.disabled = true;}
    });

document.getElementById('btnDetails').onclick =function () {
   let opzioneSelezionata = document.getElementById('currentProd');
   let indiceNascosto = opzioneSelezionata.options[opzioneSelezionata.selectedIndex].getAttribute('data-index');
   window.open("https://localhost:44378/Prodotti/Details/" + indiceNascosto + "?tipo=Prodotto");
};
