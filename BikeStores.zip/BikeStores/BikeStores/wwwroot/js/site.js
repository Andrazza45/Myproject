﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
function setStorage() {
    localStorage.setItem("url", window.location.href);
}
function getUrl() {
    $($('.url')[0]).val(window.location.href);
}
getUrl();