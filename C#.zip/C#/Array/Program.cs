﻿using System;
using System.Linq;

namespace Es1;

public static class Program
{
	public static void Main()
	{
     char a = 'a';
	 int pos = 64;
	 float f2 = 12.55F;
	 float f = (float)12.55F;
	 byte b;
	 long l;
	 //dichiarazione array
	 int [] v = new int[3];
	 v[0] = 10;
	 v[1] = 10;
	 v[2] = 10;
	 for(int i = 0; i < v.Length; i++)
	    {
		Console.WriteLine(v[i]);
		}
			
//	foreach(int n in v)
//	Console.WriteLine(n);



string[]  nomi = {"Piero","Giulia","Ilaria","Monica","Laura"} ;
Random random = new Random();
Console.Write("inf:");
int inf = int.Parse(Console.ReadLine());
Console.Write("sup:");
int sup = int.Parse(Console.ReadLine());
int dim = random.Next(0,100) + 1;
int [] numeri = new int[dim];
for(int i = 0; i < numeri.Length; i++)
    numeri[i] = random.Next(inf, sup);
Console.WriteLine(string.Join("\n", numeri));
}
}
