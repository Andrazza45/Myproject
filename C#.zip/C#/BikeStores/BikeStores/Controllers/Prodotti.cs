﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BikeStores.Models;

namespace BikeStores.Controllers
{
    public class Prodotti : Controller
    {
        public IActionResult DashboardE(string prodotto)
        {
            ViewBag.id = prodotto.Substring(0,prodotto.Search(','));
            return View();
        }
        public IActionResult Details(int id,string tipo)
        {
            Fetch f = new Fetch(id,tipo);
            
            return View(f);
        }
    }
}
