﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using BikeStores.Models;

namespace BikeStores.Controllers
{
    public class Utenti : Controller
    {
        public IActionResult DashboardE(int id, string firstname, string lastname, string email, string phone, int active, int store_id,int admin, int manager_id,string pwd, string tipo)
        {
            if (tipo == "Register")
            {
                Dipendente s = new Dipendente(id,firstname,lastname,email,phone, active, store_id, manager_id, ViewBag.admin, pwd);

                var type = typeof(s);
                var properties = type.GetProperties();
                string[] array = new string[];
                for (int i = 0; i < 10; i++)
                {
                    array.Append(properties[i].toString());
                }
                ViewBag.Array = array;

                Gestionale g = new Gestionale(s);
                if (g.AddDipendente(s) == 0)
                {
                    ViewBag.Nominativo = s.Firstname +" "+ s.LastName;
                    Fetch f = new Fetch(null, null);
                    return View(s);
                }
                else { return View(); }
            }
            else
            {
                Dipendente s = new Dipendente(tipo,null ,null,email,null,null,null,null,null, pwd);
                Gestionale g = new Gestionale(s);
                if (g.Login(s) == 0)
                {
                    ViewBag.Nominativo = s.Firstname + " " + s.LastName;
                    ViewBag.admin = s.Admin;
                    Fetch f = new Fetch(null, null);
                    return View(s);
                }
                else { return View(); }


            }
        }

        public IActionResult DashboardC(int costumer_id, string firstName, string lastName, string phone, string email, string street, string city, string state, string zip_code, string pwd, string tipo)
        {

            if (tipo == "Register")
            {
                Cliente s = new Cliente(costumer_id,firstName,lastName,phone,email,street,city,state,zip_code,pwd);
                var type = typeof(s);
                var properties = type.GetProperties();
                string[] array = new string[];
                for (int i = 0; i < 10; i++)
                {
                    array.Append(properties[i].toString());
                }
                ViewBag.Array = array;
                Gestionale g = new Gestionale(s);
                if (g.AddDipendente(s) == 0)
                {
                    ViewBag.Nominativo = s.Firstname + " " + s.LastName;
                    Fetch f = new Fetch(null, null);
                    return View(s);
                }
                else { return View(); }
            }
            else
            {
                Cliente s = new Cliente(tipo, null, null, null, email, null, null, null,pwd);
                Gestionale g = new Gestionale(s);
                if (g.Login(s) == 0)
                {
                    ViewBag.Nominativo = s.Firstname + " " + s.LastName;
                    Fetch f = new Fetch(null, null);
                    return View(s);
                }
                else { return View(); }


            }
        }
        public IActionResult Register(string value)
        {
            var Model;
            switch (value)
            {
                case "Dipendente": ViewBag.tipo = "Dipendente"; ViewBag.admin = 0;Model = Dipendente; break;
                case "Cliente": ViewBag.tipo = "Cliente"; ViewBag.admin = 0; Model = Cliente; break;
                case "Admin": ViewBag.tipo = "Dipendente"; ViewBag.admin = 1; Model = Dipendente; break;
            }
            return View(Model);
        }
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Cruds(string tipo)
        {
            Fetch f = new Fetch(null, tipo);

            return View(f);
        }
        public IActionResult DashboardE(string tipo, string action)
        {
            Cruds c = new Cruds(action,tipo);

            return View(c);
        }
    }
}
