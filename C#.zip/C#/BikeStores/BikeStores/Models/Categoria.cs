﻿namespace BikeStores.Models
{
    public class Categoria
    {
        public int Category_id;
        public string Category_name;

        public Categoria(int Category_id, string Category_name)
        {
            this.Category_id = Category_id;
            this.Category_name = Category_name;
        }
    }

}
