﻿namespace BikeStores.Models
{
    public class Cliente
    {
        public int Costumer_id;
        public string FirstName;
        public string LastName;
        public string Phone;
        public string Email;
        public string Street;
        public string City;
        public string State;
        public string Zip_code;
        public string hashedInput;
        public Cliente(int costumer_id, string firstName, string lastName, string phone, string email, string street, string city, string state, string zip_code, string pwd)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Phone = phone;
            this.Email = email;
            this.Street = street;
            this.City = city;
            this.State = state;
            this.Zip_code = zip_code;
            string input = pwd;
            this.hashedInput = pwd;
            if (input != null && this.FirstName != null)
            {
                // Creazione del provider di crittografia MD5
                using (MD5 md5 = MD5.Create())
                {
                    // Calcola l'hash MD5 del testo di input
                    byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                    byte[] hashBytes = md5.ComputeHash(inputBytes);

                    // Converti il risultato in una stringa esadecimale
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < hashBytes.Length; i++)
                    {
                        builder.Append(hashBytes[i].ToString("x2"));
                    }

                    this.hashedInput = builder.ToString();
                }
            }

        }
    }
}
