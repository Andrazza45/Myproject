﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BikeStores.Models.Services;
namespace BikeStores.Models
{
    public class Cruds
    {
        private string tipo;
        private string modello;
        private string[] parameters;

        private SqlConnection sqlconnection;
        SqlCommand cmd = new SqlCommand();
        SqlDataReader sdr = null;

        private string response;

        public Cruds(string tipo, string modello)
        {
            this.modello = Traduzione.Translate(this.modello);
            this.tipo = tipo;
            this.modello = modello;
            this.sqlconnection = new Connection().Open(0);
            this.cmd.Connection = sqlconnection;

            switch (this.tipo)
            {
                case "Create":this.create(); break;
            
                case "Update": this.delete(); break;
                    
                case "Delete": this.update(); break;
            }
        }
        private void update()
        {
            string sql = "update "+this.modello+" set values(";
            for (int i = 0; i < this.parameters.Length; i++)
            {
                if (i != parameters.Length - 1)
                {
                    sql += parameters[i] + ", ";
                }
                else { sql += parameters[i] + ") where "+this.modello+"."+this.modello+"_id = "+parameters[0]; }
            }
            this.cmd.CommandText = sql;
            this.cmd.CommandType = CommandType.Text;
            this.sdr = this.cmd.ExecuteReader();
            this.response = "Riga modificata con successo!";
        }
        private void create()
        {
            string sql = "insert into" + this.modello + " values(";
            for (int i = 0; i < this.parameters.Length; i++)
            {
                if (i != parameters.Length - 1)
                {
                    sql += parameters[i] + ", ";
                }
                else { sql += parameters[i] + ")"; }
            }
            this.cmd.CommandText = sql;
            this.cmd.CommandType = CommandType.Text;
            this.sdr = this.cmd.ExecuteReader();
            this.response = "Riga aggiunta con successo!";
        }
        private void delete()
        {
            string sql = "Delete" + this.modello + ") where " + this.modello + "." + this.modello + "_id = " + parameters[0];
            this.cmd.CommandText = sql;
            this.cmd.CommandType = CommandType.Text;
            this.sdr = this.cmd.ExecuteReader();
            this.response = "Riga eliminata con successo!";
        }


    }
}
