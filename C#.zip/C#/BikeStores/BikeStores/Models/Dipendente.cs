﻿namespace BikeStores.Models
{
    public class Dipendente
    {
        public int Id;
        public string FirstName;
        public string LastName;
        public string Email;
        public string Phone;
        public int Active;
        public int Store_id;
        public int Manager_id;
        public int Admin;
        public string hashedInput;
    }
    public Dipendente(int id, string firstname,string lastname, string email, string phone, int active, int store_id, int manager_id, string pwd)
    {
        this.Id = id;
        this.Firstname = firstname;
        this.Lastname = lastname;
        this.Email = email;
        this.Phone = phone;
        this.Active = active;
        this.Store_id = store_id;
        this.Manager_id = manager_id;
        string input = pwd;
        this.hashedInput = pwd;
        if (input != null && this.FirstName != null)
        {
            // Creazione del provider di crittografia MD5
            using (MD5 md5 = MD5.Create())
            {
                // Calcola l'hash MD5 del testo di input
                byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Converti il risultato in una stringa esadecimale
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }

                this.hashedInput = builder.ToString();
            }
        }

    }
}
