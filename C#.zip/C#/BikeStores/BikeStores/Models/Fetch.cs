﻿using Core_PrestitiVideoteca.Service;
using System.Data.SqlClient;
using System.Data;

namespace BikeStores.Models
{
    public class Fetch
    {
        public string Tipo;
        public int Id = null;
        public List<Dipendente> negozi = new List<Dipendente>();
        public List<Cliente> negozi = new List<Cliente>();
        public List<Negozio> negozi = new List<Negozio>();
        public List<Prodotto> prodotti = new List<Prodotto>();
        public List<Marca> marche = new List<Marca>();
        public List<Categoria> categorie = new List<Categoria>();
        public List<Ordine> ordini= new List<Ordine>();
        public string[] array = new string[];
        private SqlConnection sqlconnection;
        SqlDataReader sdr = null;
        public Fetch(int id, string tipo )
        {
            this.Tipo = tipo;
            this.Id = id;
            this.sqlconnection = new Connection().Open(0);
            this.caricadati();
        }

        public void caricadati()
        {
            //accesso al DB
   

            string sql = "select * from production.products";
            string sql1 = "select * from sales.stores";
            string sql2 = "select * from production.brands";
            string sql3 = "select * from production.categories";
            string sql4 = "";
            if (this.Id != null)
            {
                sql4 += "select * from sales.staffs s where s.staff_id = " + this.Id;
            }
            else { sql4 += "select * from sales.staffs"; }
            string sql5 = "select * from sales.customers";
            if (this.Id != null)
            {
                sql5 += "select * from sales.customers s where s.customer_id = " + this.Id;
            }
            string sql6 = "select * from sales.orders o where o.customer_id = " + this.Id;



            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;

            if (tipo == null || tipo == "Prodotto")
            {
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {

                    (this.prodotti).Add(
                    new Prodotto(

                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetInt32(2) : 0,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetInt32(3) : 0,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetDateTime(4) : System.DateTime.MinValue,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetDouble(5) : 0
    ));

                }

                //ordina

                var properties = Prodotto.GetProperties();
                for (int i = 0; i < properties.Count; i++)
                {
                    this.array.Append(properties[i].toString());
                }
            }
            else if (tipo == null || tipo == "Negozio")
            {
                cmd.CommandText = sql1;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {

                    (this.negozi).Add(
                    new Negozio(

                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetString(2) : null,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetString(3) : null,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetString(4) : null,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetString(5) : null,
                    !this.sdr.IsDBNull(6) ? this.sdr.GetString(6) : null,
                    !this.sdr.IsDBNull(7) ? this.sdr.GetString(7) : null
    ));

                }
                var properties = Negozio.GetProperties();
                for (int i = 0; i < properties.Count; i++)
                {
                    this.array.Append(properties[i].toString());
                }
            }
            else if (tipo == null || tipo == "Marca")
            {
                cmd.CommandText = sql2;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {

                    (this.marche).Add(
                    new Marca(
                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null
    ));

                }
                var properties = Marca.GetProperties();
                for (int i = 0; i < properties.Count; i++)
                {
                    this.array.Append(properties[i].toString());
                }
            }

            else if (tipo == null || tipo == "Categoria")
            {
                cmd.CommandText = sql3;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {

                    (this.categorie).Add(
                    new Categoria(


                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(1) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null
    ));

                }
                var properties = Categoria.GetProperties();
                for (int i = 0; i < properties.Count; i++)
                {
                    this.array.Append(properties[i].toString());
                }
            }
            else if (tipo == "Dipendente")
            {
                cmd.CommandText = sql4;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {
                    (this.categorie).Add(
                    new Dipendente(
                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetString(2) : null,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetString(3) : null,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetString(4) : null,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetInt32(5) : 0,
                    !this.sdr.IsDBNull(6) ? this.sdr.GetInt32(6) : 0,
                    !this.sdr.IsDBNull(7) ? this.sdr.GetInt32(7) : 0,
                    !this.sdr.IsDBNull(8) ? this.sdr.GetInt32(8) : 0,
                    !this.sdr.IsDBNull(9) ? this.sdr.GetString(9) : null
    ));

                }
                var properties = Dipendente.GetProperties();
                for (int i = 0; i < properties.Count; i++)
                {
                    this.array.Append(properties[i].toString());
                }
            }
            else if (tipo == "Cliente")
            {
                cmd.CommandText = sql5;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {
                    (this.categorie).Add(
                    new Cliente(
                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetString(2) : null,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetString(3) : null,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetString(4) : null,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetString(5) : null,
                    !this.sdr.IsDBNull(6) ? this.sdr.GetString(6) : null,
                    !this.sdr.IsDBNull(7) ? this.sdr.GetString(7) : null,
                    !this.sdr.IsDBNull(8) ? this.sdr.GetString(8) : null,
                    !this.sdr.IsDBNull(9) ? this.sdr.GetString(9) : null
    ));

                }
                var properties = Cliente.GetProperties();
                for (int i = 0; i < properties.Count; i++)
                {
                    this.array.Append(properties[i].toString());
                }
            }
            else if (tipo == "Ordine")
            {
                cmd.CommandText = sql6;
                this.sdr = cmd.ExecuteReader();
                while (this.sdr.Read())
                {
                    (this.categorie).Add(
                    new Ordine(
                    !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                    !this.sdr.IsDBNull(1) ? this.sdr.GetInt32(1) : 0,
                    !this.sdr.IsDBNull(2) ? this.sdr.GetString(2) : null,
                    !this.sdr.IsDBNull(3) ? this.sdr.GetDateTime(3) : System.DateTime.MinValue,
                    !this.sdr.IsDBNull(4) ? this.sdr.GetDateTime(4) : System.DateTime.MinValue,
                    !this.sdr.IsDBNull(5) ? this.sdr.GetDateTime(5) : System.DateTime.MinValue,
                    !this.sdr.IsDBNull(6) ? this.sdr.GetInt32(6) : 0,
                    !this.sdr.IsDBNull(7) ? this.sdr.GetInt32(7) : 0

    ));

                }
                var properties = Ordine.GetProperties();
                for (int i = 0; i < properties.Count; i++)
                {
                    this.array.Append(properties[i].toString());
                }
            }
        }

    }
}

