﻿using BikeStores.Models.Services;
using Core_PrestitiVideoteca.Models;
using Core_PrestitiVideoteca.Service;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace PrestitiVideoteca.Models
{
    public class Gestionale
    {
        private T S = null;
        private List<S> utenti = new List<S>();
        private string Ty = null;
        private SqlConnection sqlconnection;
        SqlDataReader sdr = null;
        public Gestionale(T s, Type type)
        {
            this.S = s;
            this.Ty = type.tostring();
            this.sqlconnection = new Connection().Open(0);
            Traduzione.Translate(this.Ty);
        }

        public int AddUtente(Utente s)
        {
            string sql = "select * from sales."+this.Ty;
            string sql1 = "insert into sales." + this.Ty + " values('";
            string str = "";
            switch (this.Ty)
            {
                case "staffs":
                str += S.Id + "','" +
                S.Firsname + "','" +
                S.Lastname+ "','" +
                S.Email + "','" +
                S.Phone + "','" +
                S.Active + "','" +
                S.Store_Id + "','" +
                S.Menager_Id + "','" +
                S.Admin + "','" +
                S.hashedInput + "'";
                break;
                case "customers":
                str += S.Matricola + "','" +
                S.Nome + "','" +
                S.Cognome + "','" +
                S.Email + "','" +
                S.Classe + "','" +
                S.Matricola + "','" +
                S.Nome + "','" +
                S.Cognome + "','" +
                S.Email + "','" +
                S.Classe +"'";
                break;
            }
            sql1 += str;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            this.sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {

                (this.utenti).Add(
                new Utente(

                !this.sdr.IsDBNull(0) ? this.sdr.GetString(0) : null,
                !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                !this.sdr.IsDBNull(2) ? this.sdr.GetString(2) : null,
                !this.sdr.IsDBNull(3) ? this.sdr.GetString(3) : null,
                !this.sdr.IsDBNull(4) ? this.sdr.GetString(4) : null,
                null
));
            }
                bool trovato = false;
                for (int i = 0; i < this.utenti.Count; i++)
                {
                    if (this.utenti[i].Matricola == S.Matricola)
                    {
                        trovato = true;
                        i = this.utenti.Count;
                    }
                }
                if (trovato == true)
                {
                    return -1;
                }
                else {
                this.sdr.Close();
                cmd.CommandText = sql1;
                cmd.CommandType = CommandType.Text;
                this.sdr = cmd.ExecuteReader();
                return 0; 
                }
            
            
        }
        public int Login(Utente s)
        {
            string sql = "select * from sales." + this.Ty;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {

                (this.utenti).Add(
                new Utente(

                !sdr.IsDBNull(0) ? sdr.GetString(0) : null,
                null,
                !sdr.IsDBNull(2) ? sdr.GetString(2) : null,
                !sdr.IsDBNull(3) ? sdr.GetString(3) : null,
                !sdr.IsDBNull(4) ? sdr.GetString(4) : null,
                !sdr.IsDBNull(5) ? sdr.GetString(5) : null
));

            }

            for (int i = 0; i < this.utenti.Count; i++)
            {
                if (this.utenti[i].Matricola == S.Matricola)
                {
                    if (this.utenti[i].hashedInput == S.hashedInput)
                    {
                        return 0;

                    }
                }
            }
            return -1;
        }


    }
}
