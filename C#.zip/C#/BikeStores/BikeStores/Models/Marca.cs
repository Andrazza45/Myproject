﻿namespace BikeStores.Models
{
    public class Marca
    {
        private int id;
        public string brand_name;
        public Marca(int id, string brand_name)
        {
            this.id = id;
            this.brand_name = brand_name;
        }
    }
}
