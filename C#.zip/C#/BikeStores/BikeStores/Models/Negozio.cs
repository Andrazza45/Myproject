﻿using System.ComponentModel.DataAnnotations;

namespace BikeStores.Models
{
    public class Negozio
    {
        public int Store_id;
        public string Store_name;
        public string Phone;
        public string Email;
        public string Street;
        public string City;
        public string State;
        public string Zip_code;

        public Negozio(int store_id, string store_name,string phone, string email,string street, string city, string state, string zip_code) {
        this.Store_id = store_id;
            this.Store_name = store_name;
            this.Phone = phone;
            this.Email = email;
            this.Street = street;
            this.City = city;
            this.State = state;
            this.Zip_code = zip_code;
        
        }
    }
}
