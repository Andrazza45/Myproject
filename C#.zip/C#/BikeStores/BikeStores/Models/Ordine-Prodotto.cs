﻿namespace BikeStores.Models
{
    public class Catalogo
    {
        public int Order_Id;
        public int Item_Id;
        public int Product_Id;
        public int Quantity;
        public double Tot;
        public double Discount;


        public Catalogo(int order_id,int item_id, int product_id, int quantity, double tot, double discount) 
        {
            this.order_Id = order_id;
            this.Item_Id = item_id;
            this.Product_Id = product_id;
            this.Quantity = quantity;
            this.Tot = tot;
            this.Discount = discount;
        }
    }
}
