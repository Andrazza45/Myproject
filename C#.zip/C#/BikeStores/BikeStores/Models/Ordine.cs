﻿namespace BikeStores.Models
{
    public class Ordine
    {
        public int Order_id;
        public int Custumer_id;
        public string Order_status;
        public DateTime Order_date;
        public DateTime Required_date;
        public DateTime Shipped_date;
        public int Store_id;
        public int Staff_id;

    }
    public Ordine(int order_id, int customer_id,DateTime order_date, string order_status, DateTime orderdate, DateTime required_date, DateTime shipped_date,int store_id, int staff_id)
    {
        this.Order_id = order_id;
        this.Customer_id = customer_id;
        this.OrderStatus = order_status;
        this.Order_date = order_date;
        this.Required_date = required_date;
        this.Shipped_date = shipped_date;
        this.Store_id = store_id;
        this.Staff_id = staff_id;



    }
}
