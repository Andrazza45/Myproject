﻿namespace BikeStores.Models
{
    public class Prodotto
    {
        public int Product_id;
        public string Product_name;
        public int Brand_id;
        public int Category_id;
        public DateTime Model_year;
        public double List_price;
        public  Prodotto(int Product_id, string Product_name, int Brand_id, int Category_id, DateTime Model_year, double List_price)
        { 
            this.Product_id = Product_id;
            this.Product_name = Product_name;
            this.Brand_id = Brand_id;
            this.Category_id = Category_id;
            this.Model_year = Model_year;
            this.List_price = List_price;
        }

    }
}
