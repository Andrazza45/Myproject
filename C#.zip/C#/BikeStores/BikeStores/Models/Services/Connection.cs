﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Core_PrestitiVideoteca.Service
{
    public class Connection
    {
        private List<object> conn = new List<object>();
        SqlConnectionStringBuilder connection = new SqlConnectionStringBuilder();
        public Connection()
        {
            connection.DataSource = @"localhost\MSSQLSERVER01";//@".\MSSQLSERVER03"; dbms
            connection.PersistSecurityInfo = true;
            connection.UserID = "sa";
            connection.Password = "sqlserver01";
            connection.InitialCatalog = "BikeStores";
            this.conn.Add(get_sql_connection());
        }


        public SqlConnection Open(int i = 0)
        {
            var c = (SqlConnection)this.conn[i];//Sql connection
            c.Open();
            return c;
        }

        public SqlConnection get_sql_connection()
        {
            SqlConnection c = new SqlConnection();
            c.ConnectionString = connection.ConnectionString;
            return c;
        }

    }
}
