﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeStores.Models.Services
{
    public class Traduzione
    {
        public void Translate(string t)
        {
            switch (t)
            {
                case "Dipendente": t = "staffs"; break;
                case "Cliente": t = "customers"; break;
                case "Prodotto": t = "products"; break;
                case "Marca": t = "brands"; break;
                //case "Catalogo": t = ""; break;
                case "Categoria": t = "categories"; break;
                case "Negozio": t = "stores"; break;
                case "Ordine": t = "orders"; break;
                case "Magazzino": t = "stocks"; break;
            }
        }
    }
}
