﻿namespace ClasseAuto
{
    public enum Carburante
    {
        BENZINA,DIESEL,GPL,METANO
    }
}