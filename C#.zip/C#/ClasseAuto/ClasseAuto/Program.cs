﻿namespace ClasseAuto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Classe Auto!");

            // Marca, Modello, Cilindrata, Alimentazione, Colore
            // VelocitaMax => cilindrata/10 + alimentazione(Benzina=30,Diesel=10,GPL=-10,Metano=-30)
            var bmw = new Auto
            {
                Marca = "BMW",
                Modello = "X5",
                Cilindrata = 689,
                Carburante = Carburante.BENZINA,
                Colore = "Bianco"
            };
            Console.WriteLine(bmw);

            string menu = $"" +
                $"\nScegli una delle seguenti azioni:" +
                $"\n1 - Accelera" +
                $"\n2 - Frena" +
                $"\n0 - Termina" +
                $"\n\n" +
                $"Scegli: ";
            int scelta;
            do
            {
                Console.WriteLine($"\nVelocità: {bmw.Velocita} km/h");
                Console.Write(menu);
                scelta = Convert.ToInt32(Console.ReadLine());
                switch(scelta)
                {
                    case 0:Console.WriteLine("Programma terminato"); break;
                        case 1:bmw.Accelera();break;
                    case 2: bmw.Frena();break;
                    default:Console.WriteLine("Scelta inserita non valida");break;
                }

            } while (scelta != 0);

        }
    }
}