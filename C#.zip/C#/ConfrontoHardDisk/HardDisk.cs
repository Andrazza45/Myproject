namespace ConfrontoHardDisk;
public class HardDisk
{
private String marca;
private int RPM;
private double accesstime;
private int capacita;
private int pp = 0; 
 public HardDisk(String marca, int RPM,double accesstime,int capacita)
 {
  this.marca = marca;
  this.RPM = RPM;
  this.accesstime = accesstime;
  this.capacita = capacita;
  this.pp = this.RPM -200*(int)Math.Floor(this.accesstime)+500*this.capacita;
 }
    public String GetMarca()
    {
        return this.marca;
    }
    public int GetRPM()
    {
        return this.RPM;
    }
    public double GetAccesstime()
    {
        return this.accesstime;
    }
    public int GetCapacita()
    {
        return this.capacita;
    }
    public void Set_capacita(int cap)
    {
        this.capacita = cap;
    }

    public int GetPunteggio()
    {
        return this.pp;
    }

public override bool Equals(object? o)
    { 
         if(o is HardDisk HRD)
        {
         if(this.marca == HRD.GetMarca() &&
            this.RPM == HRD.GetRPM() &&
            this.accesstime == HRD.GetAccesstime() &&
            this.capacita == HRD.GetCapacita())
            {return true;}else{return false;}
         }
         else{return false;}
    }
    public override string ToString()
    {
        return "Marca=" + this.marca + " RPM=" + this.RPM + " AccessTime=" + this.accesstime + " Capacità=" + this.capacita + " Punteggio=" + this.pp;
    
    }

}