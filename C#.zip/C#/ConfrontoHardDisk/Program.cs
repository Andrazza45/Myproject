﻿namespace ConfrontoHardDisk;   
public class Elenco_HardDisk
   {
    List<HardDisk> HardDisks = new List<HardDisk>(); 
    

    public Elenco_HardDisk(){}
    public List<HardDisk> GetLista()
    {
        return this.HardDisks;
    }
    public HardDisk GetHardDisk(int i)
    {
        return this.HardDisks[i];
    }
    public void Add(HardDisk o)
    {
    this.HardDisks.Add(o);
    }
    public String GetStr_elenco()
    {
        string str = "";
        for(int i= 0; i < this.HardDisks.Count; i++ )
        {
            str += this.HardDisks[i].ToString()+"\n";
        }
        return str;
    }
    public String Ordinamento()
    {
        List<HardDisk> OrderH = this.HardDisks;
        String str = "";//perchè concateno
        int indice = 0;
        int maxi = 0;
        for(int i = 0; i < OrderH.Count -1;i++)
        {
            maxi = OrderH[i].GetCapacita();
            for(int j = i + 1; j < OrderH.Count;j++)
            {
                
                if(OrderH[j].GetCapacita() <= maxi)
                {
                    maxi = OrderH[j].GetCapacita();
                    indice = j; 
                    int valore = OrderH[i].GetCapacita();
                    OrderH[i].Set_capacita(maxi);
                    OrderH[indice].Set_capacita(valore);
                }
            }

        }
        for(int i = 0; i < OrderH.Count;i++)
            {
                str += OrderH[i].ToString()+"\n";
            }
        return str;
    }
    public String PunteggioMigliore()
    {   
        int maxi = 0;
        object hd = (HardDisk) this.HardDisks[0];
        for(int i = 0; i < this.HardDisks.Count;i++)
        {
            if(this.HardDisks[i].GetPunteggio() >= maxi)
            {
                hd = (HardDisk)this.HardDisks[i];
            }
        }
        return hd.ToString();
    }
    public String PunteggioPeggiore()
    {
        object hd = (HardDisk)this.HardDisks[0];
        int min = this.HardDisks[0].GetPunteggio();
        for(int i = 0; i < this.HardDisks.Count;i++)
        {
            if(this.HardDisks[i].GetPunteggio() <= min)
            {
                hd = (HardDisk)this.HardDisks[i];
            }
        }
        return hd.ToString();
    }

     public String Cerca(String marca)
    {
        foreach (var i  in this.HardDisks)
        {
            var O = (HardDisk)i;
            if (O.GetMarca() == marca)
               {return O.ToString();}
        }
        return "Prodotto non trovato!!";
    }

public double InserisciDouble(string mes)
    {
       Boolean criteri = false;
       String nd = "";
       while(criteri == false)
       {
        Console.WriteLine(mes);
        nd = Console.ReadLine();
        int count = 0;
        char[]chr = nd.ToCharArray();
        for(int i = 0; i < nd.Length; i ++)
        {
            if(chr[i] == '.')
            {
                count +=1;
            }
            if((int)(chr[i]) >= 48 && (int)(chr[i]) <= 57 && count == 1 )
            {
                criteri = true;
            }
            else{criteri = false;}
        }
        
       }
        return Convert.ToDouble(nd);
    }


    static void Main()
    {

        int InserisciIntero(String mes)
     {
        String intero ="";
        Boolean criterio = false;
        int count = 0;
        while(criterio == false)
        {
        Console.WriteLine(mes);
        intero = Console.ReadLine();  
        char[]chr = intero.ToCharArray();
        for(int i = 0; i <chr.Length; i ++)
        {
            if(chr[i] == '-')
            {
                count += 1;
            }
            if((int)(chr[i]) >= 48 && (int)(chr[i]) <= 57 && count == 0 || count == 1 )
            {
                criterio = true;
            }
            else{criterio = false;}
        }
        }
        return Convert.ToInt32(intero);
     }

     Console.WriteLine("Elenco HardDisk: \n");
     Elenco_HardDisk el= new Elenco_HardDisk();
	 String str = @"
     1.visualizzare l'elenco degli hard disk
     2.ordinare gli hard disk in base alla capacità crescente
     3.mostrare i dati dell’hard disk con punteggio migliore 
     4.mostrare i dati dell’hard disk con punteggio peggiore
     5.mostrare i dati di un certo hard disk individuato tramite la marca
     6.Aggiungi hard-disk
     7.Confronta hard-disk
     8.esci 
     ";
    int scelta = 0;
    do{
    Console.Write(str);
    Console.WriteLine();
    scelta = Convert.ToInt32(Console.ReadLine());
    switch(scelta)
     {
     case 1:
            if(el.GetLista().Count != 0) 
               {Console.Write(el.GetStr_elenco());}
            else{Console.WriteLine("La lista è vuota!");}
               break;
     case 2: 
            if(el.GetLista().Count != 0)
               {Console.Write(el.Ordinamento());}
            else{Console.WriteLine("La lista è vuota!");}
            break;
     case 3:
             if(el.GetLista().Count != 0)
                {Console.WriteLine(el.PunteggioMigliore());}
             else{Console.WriteLine("La lista è vuota!");}
                break;
     case 4:
            if(el.GetLista().Count != 0) 
            {Console.WriteLine(el.PunteggioPeggiore());}
            else{Console.WriteLine("La lista è vuota!");}
            break;
     case 5:
            if(el.GetLista().Count != 0)
            {
            String marca = Console.ReadLine(); 
            Console.WriteLine(el.Cerca(marca));
            }
            else{Console.WriteLine("La lista è vuota!");}
            break;
     case 6:
            Console.WriteLine("Inserire la marca dell'hard-disk:");
            String ma =Console.ReadLine();
            int RPM = InserisciIntero("Inserire la velocità espressa in RPM: ");
            double accesstime = el.InserisciDouble("Inserire il tempo di accesso espresso in ms:");
            int capacita = InserisciIntero("Inserire la capacità dell'Hard-Disk");
            HardDisk d = new HardDisk(ma,RPM,accesstime,capacita); 
            el.Add((HardDisk) d);
            break;

     case 7:
             int d1 = InserisciIntero("Inserisci la posizione del primo disco ");
             int d2 = InserisciIntero("Inserisci la posizione del secondo disco");
             object o1= (HardDisk)el.GetHardDisk(d1);
             object o2= (HardDisk)el.GetHardDisk(d2);
             Console.WriteLine(o1.Equals(o2));
             break;      
     case 8: Console.WriteLine("Fine!");break;
     }

    }while(scelta != 8);
    }
   }