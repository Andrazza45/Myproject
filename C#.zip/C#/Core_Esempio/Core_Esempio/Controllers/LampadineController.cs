﻿using Core_Esempio.Models;
using Microsoft.AspNetCore.Mvc;

namespace Core_Esempio.Controllers
{
    public class LampadineController : Controller
    {
        private static Lampadina lampadina=new Lampadina();
                
        public IActionResult Index(string? action)
        {     
            if (!string.IsNullOrEmpty(action))
               lampadina.Click();
            return View(lampadina);//model
        }
    }
}
