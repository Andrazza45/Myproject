﻿namespace Core_Esempio.Models
{
    public class Lampadina
    {
        private int maxClick = 10; //numero massimo di click prima che la lampadina si rompa
        private int contaClick=0;
        private StatoLampadina statoLampadina=StatoLampadina.Spenta;

        public StatoLampadina Stato()
        {            
            return statoLampadina;   
        }

        public void Click()
        {
            if (contaClick > maxClick)
                statoLampadina = StatoLampadina.Rotta;
            else
            {
                if (statoLampadina == StatoLampadina.Spenta)
                    statoLampadina = StatoLampadina.Accesa;
                else
                    statoLampadina = StatoLampadina.Spenta;

                contaClick++;
            }
        }

    }
}
