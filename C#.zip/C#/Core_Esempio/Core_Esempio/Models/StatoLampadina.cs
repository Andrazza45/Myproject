﻿namespace Core_Esempio
{
    public enum StatoLampadina
    {
        Spenta,Accesa,Rotta
    }
}