﻿using System;
using System.Linq;

namespace EstrazioneLotto;

public static class Program
{
public static void Main()
{
Random random = new Random();
int n = random.Next(10,30) +1;
int [] vet = new int[10];
console.writeline(n);
}
}
