﻿using System;
using System.Linq;

namespace EstrazioneLotto;

public static class Program
{
	public static void Main()
	{
Random random = new Random();
int es1 = 0,es2 = 0,es3  = 0,es4 = 0,es5 = 0;
do{

}while(true);

do{

}while(true);

do{

}while(es1 == es5 || es2 == es5 || es3 == es5 || es4 == es5);

}
}
