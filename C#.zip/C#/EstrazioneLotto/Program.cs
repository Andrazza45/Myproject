﻿using System;
using System.Linq;

namespace EstrazioneLotto;

public static class Program
{
	public static void Main()
	{
Random random = new Random();
int es1,es2,es3,es4,es5;
do{
es1 = 	
}while();

do{
es1 = 	
}while();

do{
es1 = 	
}while(e1 == e5 || e2 == e5 || e3 == e5 || e4 == e5);

	}
}
