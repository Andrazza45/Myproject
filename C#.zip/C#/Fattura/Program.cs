﻿using System;
using System.Linq;

namespace Fattura;

public static class Program
{
	//iva 22% di imponibile rivalsa 4% del costo
	//imponibile 1040,00€
	// iva di imp 228,00€
	//tot lordo: 1268,00€
	//Ritenuta d'acconto 20% imponibile
	// tot netto 1060,00€
	
	public static void Main()
	{
	 Console.WriteLine("Inserire imponibile:");	
	 string imponibile = Console.ReadLine();
	 double lordo;
	 double ritenuta;
	 lordo = float.Parse(imponibile) + float.Parse(imponibile) *0.22;
	 ritenuta = float.Parse(imponibile) * 0.20;
     double netto = ritenuta + float.Parse(imponibile);
	 string msg = netto.ToString() ;
     Console.WriteLine(msg);
		  
	 Console.WriteLine(lordo+"€");	
	}
}
