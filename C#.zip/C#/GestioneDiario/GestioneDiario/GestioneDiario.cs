﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestioneDiario
{
    public class GestioneDiario
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Gestione di un diario! ");
            string path = @"c:\Users\andre\Documenti\files\diario.txt";
            /*
              Data e ora
              Frase del giorno

              Data e ora
              Frase del giorno

              Data e ora
              Frase del giorno
             */
            if (!File.Exists(path))
                File.Create(path);
             
            Console.WriteLine("Inserisci la frase del giorno:");
            string frase = Console.ReadLine();
            try 
            {
                string testo = Mylibrary.LeggiFileTesto(path);
                testo += "\n"+DateTime.Now.ToString() + "\n" + frase;
                Mylibrary.ScriviFileTesto(path, testo);
                testo = Mylibrary.LeggiFileTesto(path);
                Console.WriteLine("File aggiornato: \n"+testo);
            }catch (Exception ex) {Console.WriteLine(ex.Message);}
        }
        
    }
}
