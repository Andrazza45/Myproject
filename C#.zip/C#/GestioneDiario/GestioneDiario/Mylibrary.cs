﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestioneDiario
{
    public class Mylibrary
    {
        //lettura di file da file di testo
        public static string LeggiFileTesto(string path)
        {
            try 
            {
                StreamReader sr = new StreamReader(path);
                string testo = sr.ReadToEnd();
                sr.Close();
                return testo;

            }
            
                
            catch (FileNotFoundException ex) { throw new FileNotFoundException(); }

        }
        //Scrittura su file di testo
        public static void ScriviFileTesto(string path, string testo)
        {
            StreamWriter sw = new StreamWriter(path);
            sw.Write(testo);
            sw.Flush();
            sw.Close();

        }
        }
}
