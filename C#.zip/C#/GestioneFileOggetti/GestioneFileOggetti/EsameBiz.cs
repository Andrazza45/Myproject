﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using static GestioneDiario.Mylibrary;
namespace GestioneFileOggetti
{
    internal class EsameBiz
    {
        private List<Esame> elenco;
        public EsameBiz()
        {
            this.elenco = new List<Esame>();
        }
        public void CaricaDati()
        {
            String path = @"c:\Users\andre\Documenti\files\Esami.csv";
            if (!File.Exists(path))
                File.Create(path);

            String dati = Esame.LeggiFileTesto(path);

            String[] righe = dati.Split('\n');
            for(int i = 0; i < righe.Length; i ++)
            {
                String[] contenuti = righe[i].Split(',');
                 this.elenco.Add ( new Esame { Cognome = contenuti[0]
                ,Nome = contenuti[1]
                ,Materia = contenuti[2]
                ,Voto = int.Parse(contenuti[4])
                ,Data = contenuti[3]      
                });
            }
        }
        public String str() { return string.Join("\n", this.elenco); }

    }
}
