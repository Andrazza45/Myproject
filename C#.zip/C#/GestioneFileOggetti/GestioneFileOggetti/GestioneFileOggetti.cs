﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Solidi;

namespace GestioneFileOggetti

{
    
    public class GestioneFileOggetti
    {
        // public System.Data.SerializationFormat RemotingFormat { get; set; }
        static void Main(string[] args)
        {
            
        //     Console.WriteLine("File di oggetti!");
        //     string path = @"c:\Users\andre\Documenti\files\dati.dat";
        //     if (!File.Exists(path))
        //         {File.Create(path);}
        //     var alluminio = new TipoMateriale { Materiale = Materiale.Alluminio, PesoSpecifico = 2.6 };
        //     var q = new Cubo { Lato = 1.1, Materiale = alluminio };

        //     //accesso in modalita scrittura
        //     FileStream fw = new FileStream(path, FileMode.Open, FileAccess.Write);
        //     BinaryFormatter bf = new BinaryFormatter();
        //     bf.Serialize(fw, q);
        //     fw.Flush();
        //     fw.Close();
        //     Console.WriteLine("Operazione avvenuta con successo");
        //     //accesso in modalita lettura
        //     FileStream fr = new FileStream(path,FileMode.Open,FileAccess.Read);
        //     bf.Deserialize(fr);
        //     fr.Flush();
        //     fr.Close();
        //     Console.WriteLine("OP avvenuta con successo");
        //     File.Delete(path); 
            Program p = new Program();
            p.Main2();
        }

        
    }
}
