﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestioneFileOggetti
{
    public class Esame
    {
        public String Cognome { get; set; }
        public String Nome { get; set; }
        public String Materia { get; set; }
        public int Voto { get; set; }
        public String Data { get; set; }


        
        public override string ToString()
        {
            return $"{nameof(Nome)} = {Nome}"+
                   $" {nameof(Cognome)} = {Cognome}"+
                   $" {nameof(Materia)} = {Materia}"+
                   $" {nameof(Voto)} = {Voto}"+
                   $" {nameof(Data)} = {Data}";
        }          




        public static string LeggiFileTesto(string path)
        {
            try 
            {
                StreamReader sr = new StreamReader(path);
                string testo = sr.ReadToEnd();
                sr.Close();
                return testo;

            }
            
                
            catch (FileNotFoundException ex) { throw new FileNotFoundException(); }

        }

        public static void ScriviFileTesto(string path, string testo)
        {
            StreamWriter sw = new StreamWriter(path);
            sw.Write(testo);
            sw.Flush();
            sw.Close();

        }

    }
}
