﻿ namespace GestioneFileOggetti
{
    public class Program
    {
        public void Main2()
        {
            EsameBiz esame = new EsameBiz();
            esame.CaricaDati();
            String str = esame.str();
            Console.WriteLine("Studenti: \n"+str);
        }
    }
}