﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestione_dipendenti
{
    internal class Azienda:Gestione_dipendenti
    {
        static Operaio o1 = new Operaio( "Cardone", "Diego",  Mansione.mansione.a, 150, 35.25,  "SI",0);
        static Operaio o2 = new Operaio( "Mansion",  "Luigi",  Mansione.mansione.b,  150,  35.25,  "NO",10);
        static Operaio o3 = new Operaio( "Spadaccino",  "Dario",  Mansione.mansione.c,  150,  35.25,  "NO",50);

        static OperaioSpecializzato os1 = new OperaioSpecializzato( "Cardone",  "Diego",  150,  35.25);
        static OperaioSpecializzato os2 = new OperaioSpecializzato( "Marilli",  "Giuseppe",  150,  28.20);
        static OperaioSpecializzato os3 = new OperaioSpecializzato( "Alì",  "Roberto",  150,  30);
        static OperaioSpecializzato os4 = new OperaioSpecializzato( "Momo",  "Taro",  150,  27.15);
        static OperaioSpecializzato os5 = new OperaioSpecializzato( "Karl",  "Denny",  150,  30.15);
        static  OperaioSpecializzato os6 = new OperaioSpecializzato( "Rima",  "Renzo",  150,  35.25);

        static amministratore a1 = new amministratore( "Cardone",  "Diego",   150,  35.25);
        static amministratore a2 = new amministratore( "kiki",  "Dian",   150,  35.25);
        static amministratore a3 = new amministratore( "Anita",  "Eleonora",   150,  35.25);

        List<OperaioSpecializzato> os = new List<OperaioSpecializzato> {os1,os2,os3,os4,os5,os6};
        List<amministratore> am = new List<amministratore> {a1,a2,a3};
        List<Operaio> op = new List<Operaio> {o1,o2,o3};
        static object[]dipendenti ={os1,os2,os3,os4,os5,os6,a1,a2,a3,o1,o2,o3 };
        public override String Stampa_dipendenti()
        {
            string str = "";
            foreach (var d in os)
            {       
                var obj = (OperaioSpecializzato) d;
                str += obj.ToString() + "\n";
    
            }
            foreach (var d in am)
            {       
                var obj = (amministratore) d;
                str += obj.ToString() + "\n";
    
            }
            foreach (var d in op)
            {       
                var obj = (Operaio) d;
                str += obj.ToString() + "\n";
    
            }
            return str;
        }
        public static void Main(string[] args)
        {
            Console.WriteLine("Azienda Petrolchimica");
            var biz = new Azienda();
            Console.WriteLine("Dipendenti:("+ biz.NumeroMissioni(dipendenti)+")missioni\n");
            Console.WriteLine(biz.Stampa_dipendenti());

        }
    }
   

}
