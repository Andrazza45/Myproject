﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Functions;
namespace Gestione_dipendenti
{
    internal class Azienda:Gestione_dipendenti
    {
        static Operaio o1 = new Operaio( "Cardone", "Diego",  Mansione.mansione.INSTALLATORE, 150, 35.25);
        static Operaio o2 = new Operaio( "Mansion",  "Luigi",  Mansione.mansione.MANUTENTORE,  150,  35.25);
        static Operaio o3 = new Operaio( "Spadaccino",  "Dario",  Mansione.mansione.INSTALLATORE,  150,  35.25);

        static OperaioSpecializzato os1 = new OperaioSpecializzato( "Cardone",  "Diego",  150,  35.25,  "SI",10);
        static OperaioSpecializzato os2 = new OperaioSpecializzato( "Marilli",  "Giuseppe",  150,  28.20,  "NO",0);
        static OperaioSpecializzato os3 = new OperaioSpecializzato( "Alì",  "Roberto",  150,  30,  "NO",0);
        static OperaioSpecializzato os4 = new OperaioSpecializzato( "Momo",  "Taro",  150,  27.15,  "NO",0);
        static OperaioSpecializzato os5 = new OperaioSpecializzato( "Karl",  "Denny",  150,  30.15,"SI",90);
        static  OperaioSpecializzato os6 = new OperaioSpecializzato( "Rima",  "Renzo",  150,  35.25,"SI",30);

        static amministratore a1 = new amministratore( "Cardone",  "Diego",Mansione.mansione.CONTABILE ,  150,  35.25);
        static amministratore a2 = new amministratore( "kiki",  "Dian", Mansione.mansione.RISORSE_UMANE , 150,  35.25);
        static amministratore a3 = new amministratore( "Ania",  "Eleonora", Mansione.mansione.DIRETTORE,  150,  35.25);

        static object[]dipendenti ={os1,os2,os3,os4,os5,os6,a1,a2,a3,o1,o2,o3};
        public override String Stampa_dipendenti()
        {
            String str = "";
            for(int i= 0;i < dipendenti.Length; i++ )
            {
                str += dipendenti[i].ToString() + "\n";
            }
            return str;
        }
        public static void Main(string[] args)
        {
        Console.WriteLine("Azienda Petrolchimica \n");
        var biz = new Azienda();
        String str = @"
        1.Aggiungi dipendente
        2.Stampa dipendenti
        3.Totale stipendi da pagare
        4.visualizzare il totale delle ore lavorate da dipendente x
        5.visualizzare il numero dei dipendenti
        6.visualizzare la paga oraria media degli operai
        7.visualizzare il numero di missioni che sono state effettuate
        8.FINE ";
        int scelta = 0;
        do
        {
            
        Console.Write(str);
        Console.WriteLine();
        scelta = Convert.ToInt32(Console.ReadLine());
        switch(scelta)
        {
            
            case 1:
                    Tastiera tastiera = new Tastiera();
                    String nome, cognome;
                    int OreLavoro;
                    double PagaO;
                    int mansione;
                    Enum M = Mansione.mansione.RISORSE_UMANE;//default
                    int tipo = tastiera.InserisciIntero("Che tipo di dipendente vuoi inserire?(1.Operaio/2.OperaioSpecializzato/3.amministratore)");
                    switch(tipo)
                    {
                      case 1:
                            Console.WriteLine("Inserire il nome del dipendente:");
                            nome = Console.ReadLine();
                            Console.WriteLine("Inserire il cognome del dipendente:");
                            cognome =Console.ReadLine();
                            mansione = -1;
                            while(mansione < 1 || mansione > 2)
                            {
                            mansione =tastiera.InserisciIntero("Inserire la mansione(1.INSTALLATORE/2.MANUTENTORE):");
                            switch(mansione)
                            {
                                case 1:M = Mansione.mansione.INSTALLATORE;break;
                                case 2:M = Mansione.mansione.MANUTENTORE;break;
                                default:Console.WriteLine("Mansione non trovata");break;
                            }
                            }
                            
                            OreLavoro = tastiera.InserisciIntero("Inserire il numero di ore di lavoro mensili:");
                            PagaO =tastiera.InserisciDouble("Inserire la Paga Oraria del dipendente:");
                            Operaio op= new Operaio(cognome,nome,M,OreLavoro,PagaO);
                            dipendenti.Append(op);
                            break;
                      case 2:
                            Console.WriteLine("Inserire il nome del dipendente:");
                            nome = Console.ReadLine();
                            Console.WriteLine("Inserire il cognome del dipendente:");
                            cognome =Console.ReadLine();
                            OreLavoro = tastiera.InserisciIntero("Inserire il numero di ore di lavoro mensili:");
                            PagaO =tastiera.InserisciDouble("Inserire la Paga Oraria del dipendente:");
                            String IndMiss = "";
                            while (IndMiss != "SI" && IndMiss != "NO")
                            {
                            Console.WriteLine("Indennita Missione(SI/NO):");
                            IndMiss = Console.ReadLine();
                            }
                            int missioni = tastiera.InserisciIntero("Quante missioni hai già svolto?");
                            OperaioSpecializzato ops = new OperaioSpecializzato(cognome,nome,OreLavoro,PagaO,IndMiss,missioni);
                            dipendenti.Append(ops);
                            break;
                      case 3:
                            Console.WriteLine("Inserire il nome del dipendente:");
                            nome = Console.ReadLine();
                            Console.WriteLine("Inserire il cognome del dipendente:");
                            cognome =Console.ReadLine();
                            mansione = -1;
                            while(mansione < 1 || mansione > 3)
                            {
                            mansione =tastiera.InserisciIntero("Inserire la mansione(1.CONTABILE/2.RISORSE_UMANE/3.DIRETTORE):");
                            switch(mansione)
                            {
                                case 1:M = Mansione.mansione.CONTABILE;break;
                                case 2:M = Mansione.mansione.RISORSE_UMANE;break;
                                case 3:M = Mansione.mansione.DIRETTORE;break;
                                default:Console.WriteLine("Mansione non trovata");break;
                            }
                            }
                            OreLavoro = tastiera.InserisciIntero("Inserire il numero di ore di lavoro mensili:");
                            PagaO =tastiera.InserisciDouble("Inserire la Paga Oraria del dipendente:");
                            amministratore a = new amministratore(cognome,nome,M,OreLavoro,PagaO);
                            dipendenti.Append(a);                 
                            break;
                      default: Console.WriteLine("Tipo non trovato!");break;
                    }

                    break;
            case 2:
                    if(biz.Get_lista(dipendenti).Length != 0)
                    {
                    Console.WriteLine(biz.Stampa_dipendenti());
                    }
                    else{Console.WriteLine("La lista dei dipendenti è vuota");}
                    break;

            case 3:
                    if(biz.Get_lista(dipendenti).Length != 0)
                        {
                        Console.WriteLine("Il totale dello stipendio da pagare dei dipendenti è: "+biz.Tot_stipendi(dipendenti)+" euro.");
                        }
                        else{Console.WriteLine("La lista dei dipendenti è vuota");}break;
            
            case 4:
                    Console.WriteLine("Inserisci il cognome del dipendente del quale si vuole conoscere il numero di ore lavorate:");
                    String c = Console.ReadLine();
                    if(biz.Get_lista(dipendenti).Length != 0)
                    {
                    int Nore = biz.Ore_lavorateX(dipendenti, c);
                    if(Nore  != -1)
                    {Console.WriteLine("Il numero di ore di lavoro mensile effettuate da "+c+" sono: "+Nore+".");}
                    else{ Console.WriteLine("Dipendente non trovato!");}
                    }
                    else{Console.WriteLine("La lista dei dipendenti è vuota");}break;

            case 5:
                    Console.WriteLine("Il numero complessivo di dipendenti è:"+ biz.totale_dipendenti(dipendenti));
                    break;
            
            case 6:
                   if(biz.Get_lista(dipendenti).Length != 0)
                   {
                   Console.WriteLine("La paga oraria media degli Operai è: "+biz.PagaOMedia(dipendenti)+" euro.");
                   }
                   else{Console.WriteLine("La lista dei dipendenti è vuota");}
                   break;

            case 7:
                   if(biz.Get_lista(dipendenti).Length != 0)
                   {
                   Console.WriteLine("Dipendenti:("+ biz.NumeroMissioni(dipendenti)+")missioni\n");
                   }
                   else{Console.WriteLine("La lista dei dipendenti è vuota");}
                   break; 

            case 8:Console.WriteLine("FINE!");break;

            default:Console.WriteLine("Scelta non valida!");break;
        }
        }
        while(scelta != 8);

        }
    }
   

}
