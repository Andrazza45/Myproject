﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gestione_dipendenti;
namespace Gestione_dipendenti
{
    public abstract class Gestione_dipendenti
    {
        private object[]dipendenti = new object[12];
        public Gestione_dipendenti()
        {}

        public int totale_dipendenti()
        {return dipendenti.Length; }

        
         public int NumeroMissioni(object[] dipendenti)
         {
             int conta = 0;
             foreach (var i  in dipendenti )
              {
                 if(i is Operaio)
                 {   
                     var  O = (Operaio)i; 
                     conta += O.Get_missioni();

                 }      
             }
             return conta;
         }
        public abstract String Stampa_dipendenti();


        public override String ToString()
        {   
            return Stampa_dipendenti();
        }
    }

}

