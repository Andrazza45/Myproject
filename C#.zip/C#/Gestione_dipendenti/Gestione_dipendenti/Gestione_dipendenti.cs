﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gestione_dipendenti;
namespace Gestione_dipendenti
{
    public abstract class Gestione_dipendenti
    {
        public Gestione_dipendenti()
        {}
        public object[] Get_lista(object[] dipendenti)
        {
            return dipendenti;
        }
        public int totale_dipendenti(object[] dipendenti)
        {return dipendenti.Length; }

        public int Ore_lavorateX(object[] dipendenti,String cognome)
        {
         for(int i = 0; i < dipendenti.Length; i++)
         {
            switch(dipendenti[i])
            {
                case Operaio:
                             Operaio obj1 =(Operaio)dipendenti[i];
                             if(obj1.GetCognome() == cognome)
                                {return obj1.GetOreLavoro();}
                             break;
                case OperaioSpecializzato:
                                          OperaioSpecializzato obj2 =(OperaioSpecializzato)dipendenti[i];
                                          if(obj2.GetCognome() == cognome)
                                            {return obj2.GetOreLavoro();}
                                          break;
                case amministratore:
                                    amministratore obj3 =(amministratore)dipendenti[i];
                                    if(obj3.GetCognome() == cognome)
                                      {return obj3.GetOreLavoro();}
                                    break;
            }
            
         }
         return -1;
        }
        public double Tot_stipendi(object[] dipendenti)
        {
            double tot = 0;
            for(int i = 0; i < dipendenti.Length; i++)
            {
            switch(dipendenti[i])
            {
                case Operaio:
                             Operaio obj1 =(Operaio)dipendenti[i];
                             tot += obj1.GetStip();             
                             break;
                case OperaioSpecializzato:
                                          OperaioSpecializzato obj2 =(OperaioSpecializzato)dipendenti[i];
                                          tot += obj2.GetStip();
                                          break;
                case amministratore:
                                    amministratore obj3 =(amministratore)dipendenti[i];
                                    tot += obj3.GetStip();
                                    break;
            }
            }
            return tot;
        }
        public double PagaOMedia(object[] dipendenti)
        {
            double somma = 0;
            for(int i = 0; i < dipendenti.Length; i++)
            {
            switch(dipendenti[i])
            {
                case Operaio:
                             Operaio obj =(Operaio)dipendenti[i];
                             somma += obj.GetPagaO();             
                             break;
            }
            }
            return somma / dipendenti.Length;
        }

         public int NumeroMissioni(object[] dipendenti)
         {
             int conta = 0;
             foreach (var i  in dipendenti )
              {
                 if(i is OperaioSpecializzato)
                 {   
                     var  O = (OperaioSpecializzato)i; 
                     conta += O.Get_missioni();

                 }      
             }
             return conta;
         }
        public abstract String Stampa_dipendenti();
    }

}

