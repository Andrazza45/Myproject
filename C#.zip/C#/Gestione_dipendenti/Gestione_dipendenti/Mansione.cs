﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestione_dipendenti
{
    public class Mansione
    {
        public enum mansione
            {
            CONTABILE, RISORSE_UMANE, DIRETTORE,INSTALLATORE, MANUTENTORE
            }
    }
}
