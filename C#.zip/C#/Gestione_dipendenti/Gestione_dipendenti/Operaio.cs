﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestione_dipendenti
{
    public class Operaio
    {
        private String Cognome;
        private String Nome;
        private String mansione;
        private double PagaOraria;
        private int OreLavorate;
        private double stipendio;
        private double bonus;
        
        public Operaio(String Cognome,String Nome, Enum mansione,int  Ore,double PagaOraria)
        {
            this.Cognome = Cognome;
            this.Nome = Nome;
            this.mansione = (mansione).ToString();
            this.OreLavorate = Ore;
            this.PagaOraria = PagaOraria;
            switch(this.mansione)
            {
                case "INSTALLATORE": this.bonus = 175.50;break;
                case "MANUTENTORE":this.bonus = 250.75; break;
            }
            this.stipendio = this.PagaOraria * this.OreLavorate + this.bonus;

        }

        public String GetNome()
        {
            return this.Nome;
        }

        public String GetCognome()
        {
            return this.Cognome;
        }
        
        public String GetMansione()
        {
            return this.mansione;
        }

        public int GetOreLavoro()
        {
            return this.OreLavorate;
        }

        public double GetPagaO()
        {
            return this.PagaOraria;
        }
        public double GetStip()
        {
            return this.stipendio;
        }

        public override string ToString()
        {
            return this.Cognome+this.Nome+this.mansione.ToString()+this.OreLavorate.ToString()+this.PagaOraria.ToString();
        }





    }
}
