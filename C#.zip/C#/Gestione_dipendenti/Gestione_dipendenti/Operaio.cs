﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestione_dipendenti
{
    public  class Operaio
    {
        private String Cognome;
        private String Nome;
        private String mansione;
        private double PagaOraria;
        private int OreLavorate;
        private String IndennitaMissione;
        private int missioni;
        
        public Operaio(String Cognome,String Nome, Enum mansione,int  Ore,double PagaOraria, String IndennitaMissione, int missioni)
        {
            this.Cognome = Cognome;
            this.Nome = Nome;
            this.mansione = (mansione).ToString();
            this.OreLavorate = Ore;
            this.PagaOraria = PagaOraria;
            this.IndennitaMissione = IndennitaMissione;
            this.missioni = missioni;
        }
        public int Get_missioni()
        {
            return this.missioni;
        }
        public override string ToString()
        {
            return this.Cognome+this.Nome+this.mansione.ToString()+this.OreLavorate.ToString()+this.PagaOraria.ToString()+this.IndennitaMissione;
        }





    }
}
