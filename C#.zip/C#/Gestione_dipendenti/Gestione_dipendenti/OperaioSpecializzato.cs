﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestione_dipendenti
{
    public class OperaioSpecializzato
    {
        private String Cognome;
        private String Nome;
        private String mansione;
        private double PagaOraria;
        private int OreLavorate;
        private String IndennitaMissione;
        private int missioni;
        private double stipendio;
        public OperaioSpecializzato(String Cognome,String Nome, int Ore,double PagaOraria,String IndennitaMissione, int missioni )
        {
            this.Cognome = Cognome;
            this.Nome = Nome;
            this.OreLavorate = Ore;
            this.PagaOraria = PagaOraria;
            this.IndennitaMissione = IndennitaMissione;
            this.missioni = missioni;
            if(this.IndennitaMissione == "SI")
            {
            this.stipendio = this.PagaOraria * this.OreLavorate +24 *this.PagaOraria* this.missioni;
            }
            else
            {
             this.stipendio = this.PagaOraria * this.OreLavorate;
            }
        }
        public String GetNome()
        {
            return this.Nome;
        }

        public String GetCognome()
        {
            return this.Cognome;
        }

        public int GetOreLavoro()
        {
            return this.OreLavorate;
        }

        public double GetPagaO()
        {
            return this.PagaOraria;
        }
        public double GetStip()
        {
            return this.stipendio;
        }

        public int Get_missioni()
        {
            return this.missioni;
        }

        public override String ToString()
        {
            return this.Cognome+this.Nome+this.OreLavorate.ToString()+this.PagaOraria.ToString()+this.IndennitaMissione+this.missioni;
        }



    }

}
