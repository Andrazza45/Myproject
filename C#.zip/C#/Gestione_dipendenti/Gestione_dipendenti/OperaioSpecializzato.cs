﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestione_dipendenti
{
    public class OperaioSpecializzato
    {
        protected String Cognome;
        protected String Nome;
        protected String mansione;
        protected double PagaOraria;
        protected int OreLavorate;
        public OperaioSpecializzato(String Cognome,String Nome, int Ore,double PagaOraria )
        {
            this.Cognome = Cognome;
            this.Nome = Nome;
            this.OreLavorate = Ore;
            this.PagaOraria = PagaOraria;

        }


        public override String ToString()
        {
            return this.Cognome+this.Nome+this.OreLavorate.ToString()+this.PagaOraria.ToString();
        }



    }

}
