namespace Gestione_dipendenti
{
    public class pub
    {
        
    }
}