﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestione_fileTxt
{
    public class GestioniFileTxt
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Gestione file di testo!");
            string path = @"c:\Users\andre\Documenti\files\testo.txt";
            if (!File.Exists(path))
                File.Create(path);
            //scrittura
            StreamWriter streamW = new StreamWriter(path);
            String frase = Console.ReadLine();
            streamW.WriteLine(frase);
            streamW.Flush();
            streamW.Close();
            //lettura
            StreamReader StreamR = null;
            try
            {
                StreamReader streamR = new StreamReader(path);
                string testo = string.Empty;
                testo = streamR.ReadToEnd();
                streamR.Close();
                Console.WriteLine($"testo recuperato dalla scrittura del file: {testo}");
            }
            catch (System.IO.FileNotFoundException ex) { Console.WriteLine("ERRORE! \n File non trovato!"); Console.WriteLine($"ERRORE!{ex.Message}"); }
            finally {
                if (StreamR != null)
                { StreamR.Close(); }
            }
        }
    }
}
