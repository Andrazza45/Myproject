﻿namespace GuiCatalogo
{
    partial class ElencoProdotto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnExpCsv = new System.Windows.Forms.Button();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.Lstprod = new System.Windows.Forms.ListBox();
            this.LblNprod = new System.Windows.Forms.Label();
            this.LblTitolo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnExpCsv
            // 
            this.BtnExpCsv.Location = new System.Drawing.Point(488, 82);
            this.BtnExpCsv.Name = "BtnExpCsv";
            this.BtnExpCsv.Size = new System.Drawing.Size(129, 41);
            this.BtnExpCsv.TabIndex = 9;
            this.BtnExpCsv.Text = "Esporta CSV";
            this.BtnExpCsv.UseVisualStyleBackColor = true;
            this.BtnExpCsv.Click += new System.EventHandler(this.BtnExpCsv_Click);
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 450);
            this.splitter1.TabIndex = 8;
            this.splitter1.TabStop = false;
            // 
            // Lstprod
            // 
            this.Lstprod.FormattingEnabled = true;
            this.Lstprod.Location = new System.Drawing.Point(136, 195);
            this.Lstprod.Name = "Lstprod";
            this.Lstprod.Size = new System.Drawing.Size(550, 186);
            this.Lstprod.TabIndex = 7;
            // 
            // LblNprod
            // 
            this.LblNprod.AutoSize = true;
            this.LblNprod.Location = new System.Drawing.Point(133, 165);
            this.LblNprod.Name = "LblNprod";
            this.LblNprod.Size = new System.Drawing.Size(10, 13);
            this.LblNprod.TabIndex = 6;
            this.LblNprod.Text = "-";
            // 
            // LblTitolo
            // 
            this.LblTitolo.AutoSize = true;
            this.LblTitolo.Location = new System.Drawing.Point(359, 9);
            this.LblTitolo.Name = "LblTitolo";
            this.LblTitolo.Size = new System.Drawing.Size(79, 13);
            this.LblTitolo.TabIndex = 5;
            this.LblTitolo.Text = "Elenco Prodotti";
            // 
            // ElencoProdotto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnExpCsv);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.Lstprod);
            this.Controls.Add(this.LblNprod);
            this.Controls.Add(this.LblTitolo);
            this.Name = "ElencoProdotto";
            this.Text = "ElencoProdottocs";
            this.Load += new System.EventHandler(this.ElencoProdottocs_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnExpCsv;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.ListBox Lstprod;
        private System.Windows.Forms.Label LblNprod;
        private System.Windows.Forms.Label LblTitolo;
    }
}