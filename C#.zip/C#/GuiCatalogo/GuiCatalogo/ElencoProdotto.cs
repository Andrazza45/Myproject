﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuiCatalogo
{
    public partial class ElencoProdotto : Form
    {
        private List<ElencoProdotto> list = new List<ElencoProdotto>();
        private String PathCSV = @"..\..\File\prodotti.csv";
        public String PATH = @"..\..\File\prodotti.dat";
        public ElencoProdotto()
        {
            InitializeComponent();
            LoadDati();
        }
        private void LoadDati()
        {
            String PATH = @"..\..\File\prodotti.dat";
            var lista = Mylibrary.LeggiFileOggetti(PATH);
            //FileStream fs = new FileStream(PATH, FileMode.Open, FileAccess.Read);
            //BinaryFormatter bf = new BinaryFormatter();
            //var p = bf.Deserialize(fs) as GuiCatalogo;
            //fs.Close();
            //Lstprod.Items.Add(p.Nome);
            LblNprod.Text = (lista.Count).ToString();
            for (int i = 0; i < lista.Count; i++)
            {
                Lstprod.Items.Add(lista[i].ToString());
            }
        }
        private void ElencoProdottocs_Load(object sender, EventArgs e)
        {

        }

        private void BtnExpCsv_Click(object sender, EventArgs e)
        {
            List<GuiCatalogo> lista= Mylibrary.LeggiFileOggetti(PATH);

            Mylibrary.ScriviFileCSV(PathCSV, lista);
        }
    }
}
