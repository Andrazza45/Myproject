﻿namespace GuiCatalogo
{
    partial class EliminaProdotto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.Txtdesc = new System.Windows.Forms.TextBox();
            this.Lbldesc = new System.Windows.Forms.Label();
            this.Txtprezzo = new System.Windows.Forms.TextBox();
            this.Lblprezzo = new System.Windows.Forms.Label();
            this.Btncartella = new System.Windows.Forms.Button();
            this.Txtgiac = new System.Windows.Forms.TextBox();
            this.Lblgiac = new System.Windows.Forms.Label();
            this.Txtnome = new System.Windows.Forms.TextBox();
            this.Lblnome = new System.Windows.Forms.Label();
            this.Txtcod = new System.Windows.Forms.TextBox();
            this.Lblcod = new System.Windows.Forms.Label();
            this.LblTitolo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BtnEliminazione = new System.Windows.Forms.Button();
            this.Txtmod = new System.Windows.Forms.TextBox();
            this.Lblmod = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Txtdesc);
            this.panel2.Controls.Add(this.Lbldesc);
            this.panel2.Controls.Add(this.Txtprezzo);
            this.panel2.Controls.Add(this.Lblprezzo);
            this.panel2.Controls.Add(this.Btncartella);
            this.panel2.Controls.Add(this.Txtgiac);
            this.panel2.Controls.Add(this.Lblgiac);
            this.panel2.Controls.Add(this.Txtnome);
            this.panel2.Controls.Add(this.Lblnome);
            this.panel2.Controls.Add(this.Txtcod);
            this.panel2.Controls.Add(this.Lblcod);
            this.panel2.Location = new System.Drawing.Point(60, 181);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(284, 238);
            this.panel2.TabIndex = 8;
            // 
            // Txtdesc
            // 
            this.Txtdesc.Location = new System.Drawing.Point(92, 95);
            this.Txtdesc.Name = "Txtdesc";
            this.Txtdesc.Size = new System.Drawing.Size(145, 20);
            this.Txtdesc.TabIndex = 24;
            // 
            // Lbldesc
            // 
            this.Lbldesc.AutoSize = true;
            this.Lbldesc.Location = new System.Drawing.Point(22, 98);
            this.Lbldesc.Name = "Lbldesc";
            this.Lbldesc.Size = new System.Drawing.Size(62, 13);
            this.Lbldesc.TabIndex = 23;
            this.Lbldesc.Text = "Descrizione";
            // 
            // Txtprezzo
            // 
            this.Txtprezzo.Location = new System.Drawing.Point(92, 128);
            this.Txtprezzo.Name = "Txtprezzo";
            this.Txtprezzo.Size = new System.Drawing.Size(145, 20);
            this.Txtprezzo.TabIndex = 22;
            // 
            // Lblprezzo
            // 
            this.Lblprezzo.AutoSize = true;
            this.Lblprezzo.Location = new System.Drawing.Point(23, 131);
            this.Lblprezzo.Name = "Lblprezzo";
            this.Lblprezzo.Size = new System.Drawing.Size(39, 13);
            this.Lblprezzo.TabIndex = 21;
            this.Lblprezzo.Text = "Prezzo";
            // 
            // Btncartella
            // 
            this.Btncartella.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Btncartella.Location = new System.Drawing.Point(162, 212);
            this.Btncartella.Name = "Btncartella";
            this.Btncartella.Size = new System.Drawing.Size(75, 23);
            this.Btncartella.TabIndex = 20;
            this.Btncartella.Text = "cartella";
            this.Btncartella.UseVisualStyleBackColor = false;
            // 
            // Txtgiac
            // 
            this.Txtgiac.Location = new System.Drawing.Point(92, 164);
            this.Txtgiac.Name = "Txtgiac";
            this.Txtgiac.Size = new System.Drawing.Size(145, 20);
            this.Txtgiac.TabIndex = 18;
            // 
            // Lblgiac
            // 
            this.Lblgiac.AutoSize = true;
            this.Lblgiac.Location = new System.Drawing.Point(26, 167);
            this.Lblgiac.Name = "Lblgiac";
            this.Lblgiac.Size = new System.Drawing.Size(52, 13);
            this.Lblgiac.TabIndex = 17;
            this.Lblgiac.Text = "Giacenza";
            // 
            // Txtnome
            // 
            this.Txtnome.Location = new System.Drawing.Point(92, 55);
            this.Txtnome.Name = "Txtnome";
            this.Txtnome.Size = new System.Drawing.Size(145, 20);
            this.Txtnome.TabIndex = 16;
            // 
            // Lblnome
            // 
            this.Lblnome.AutoSize = true;
            this.Lblnome.Location = new System.Drawing.Point(26, 58);
            this.Lblnome.Name = "Lblnome";
            this.Lblnome.Size = new System.Drawing.Size(35, 13);
            this.Lblnome.TabIndex = 15;
            this.Lblnome.Text = "Nome";
            // 
            // Txtcod
            // 
            this.Txtcod.Location = new System.Drawing.Point(92, 8);
            this.Txtcod.Name = "Txtcod";
            this.Txtcod.Size = new System.Drawing.Size(145, 20);
            this.Txtcod.TabIndex = 14;
            // 
            // Lblcod
            // 
            this.Lblcod.AutoSize = true;
            this.Lblcod.Location = new System.Drawing.Point(26, 15);
            this.Lblcod.Name = "Lblcod";
            this.Lblcod.Size = new System.Drawing.Size(40, 13);
            this.Lblcod.TabIndex = 13;
            this.Lblcod.Text = "Codice";
            // 
            // LblTitolo
            // 
            this.LblTitolo.AutoSize = true;
            this.LblTitolo.Location = new System.Drawing.Point(375, 31);
            this.LblTitolo.Name = "LblTitolo";
            this.LblTitolo.Size = new System.Drawing.Size(83, 13);
            this.LblTitolo.TabIndex = 7;
            this.LblTitolo.Text = "Elimina Prodotto";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.BtnEliminazione);
            this.panel1.Controls.Add(this.Txtmod);
            this.panel1.Controls.Add(this.Lblmod);
            this.panel1.Location = new System.Drawing.Point(28, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(744, 94);
            this.panel1.TabIndex = 6;
            // 
            // BtnEliminazione
            // 
            this.BtnEliminazione.Location = new System.Drawing.Point(555, 35);
            this.BtnEliminazione.Name = "BtnEliminazione";
            this.BtnEliminazione.Size = new System.Drawing.Size(102, 23);
            this.BtnEliminazione.TabIndex = 2;
            this.BtnEliminazione.Text = "Eliminazione";
            this.BtnEliminazione.UseVisualStyleBackColor = true;
            this.BtnEliminazione.Click += new System.EventHandler(this.BtnEliminazione_Click_1);
            // 
            // Txtmod
            // 
            this.Txtmod.Location = new System.Drawing.Point(195, 35);
            this.Txtmod.Name = "Txtmod";
            this.Txtmod.Size = new System.Drawing.Size(158, 20);
            this.Txtmod.TabIndex = 1;
            // 
            // Lblmod
            // 
            this.Lblmod.AutoSize = true;
            this.Lblmod.Location = new System.Drawing.Point(106, 38);
            this.Lblmod.Name = "Lblmod";
            this.Lblmod.Size = new System.Drawing.Size(81, 13);
            this.Lblmod.TabIndex = 0;
            this.Lblmod.Text = "Nome Prodotto:";
            // 
            // EliminaProdotto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.LblTitolo);
            this.Controls.Add(this.panel1);
            this.Name = "EliminaProdotto";
            this.Text = "EliminaProdotto";
            this.Load += new System.EventHandler(this.EliminaProdotto_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox Txtdesc;
        private System.Windows.Forms.Label Lbldesc;
        private System.Windows.Forms.TextBox Txtprezzo;
        private System.Windows.Forms.Label Lblprezzo;
        private System.Windows.Forms.Button Btncartella;
        private System.Windows.Forms.TextBox Txtgiac;
        private System.Windows.Forms.Label Lblgiac;
        private System.Windows.Forms.TextBox Txtnome;
        private System.Windows.Forms.Label Lblnome;
        private System.Windows.Forms.TextBox Txtcod;
        private System.Windows.Forms.Label Lblcod;
        private System.Windows.Forms.Label LblTitolo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BtnEliminazione;
        private System.Windows.Forms.TextBox Txtmod;
        private System.Windows.Forms.Label Lblmod;
    }
}