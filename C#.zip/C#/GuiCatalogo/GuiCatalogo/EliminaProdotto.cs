﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuiCatalogo
{
    public partial class EliminaProdotto : Form
    {

        public GuiCatalogo prodotto = new GuiCatalogo();
        public List<GuiCatalogo> catalogo = new List<GuiCatalogo>();
        public EliminaProdotto()
        {
            InitializeComponent();
        }

        private void EliminaProdotto_Load(object sender, EventArgs e)
        {

        }
        private void BtnEliminazione_Click_1(object sender, EventArgs e)
        {
            String PATH = @"..\..\File\prodotti.dat";
            var lista = Mylibrary.LeggiFileOggetti(PATH);
            int codice = Convert.ToInt32(Txtmod.Text);
            foreach (var item in lista)
            {
                if (item.Cod == codice)
                    prodotto = item;
            }
            DialogResult dialog = MessageBox.Show("Sicuro di voler eliminare questo prodotto","Eliminazione Prodotto", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                lista.Remove(prodotto);
                prodotto = null;
                Txtcod.Text = string.Empty;
                Txtnome.Text = string.Empty;
                Txtdesc.Text = string.Empty;
                Txtprezzo.Text = string.Empty;
                Mylibrary.ScriviFileOggetti(PATH,lista);
            }
            else { MessageBox.Show("Operazione Fallita"); }
        }
    }
}
