﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuiCatalogo
{
    public partial class ModificaProdotto : Form
    {
        private bool ok = false;
        public ModificaProdotto()
        {
            InitializeComponent();
        }

        private void ModificaProdotto_Load(object sender, EventArgs e)
        {

        }

        private void BtnCerca_Click_1(object sender, EventArgs e)
        {
            if (this.ok == false)
            {
                String PATH = @"..\..\File\prodotti.dat";
                var lista = Mylibrary.LeggiFileOggetti(PATH);
                int codice = Convert.ToInt32(Txtmod.Text);

                for (int i = 0; i < lista.Count; i++)
                {
                    if (lista[i].Cod == codice)
                    {
                        lista[i].Nome = Txtnome.Text;
                        lista[i].prezzo = Convert.ToDouble(Txtprezzo.Text);
                        lista[i].Desc = Txtdesc.Text;
                        lista[i].giacenza = Convert.ToInt32(Txtgiac.Text);
                        MessageBox.Show("Modifica Effettuata con successo!!");
                        Mylibrary.ScriviFileOggetti(PATH, lista);
                        i = lista.Count;
                    }

                }
            }
            else { Txtmod.Text = "";this.ok = false; }
        }

        private void Txtmod_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar < 48 || (int)e.KeyChar > 57 && (int)e.KeyChar != 127)
            {
                MessageBox.Show("Non sono concesse lettere");
                this.ok = true;   
                // Azioni da eseguire quando viene premuto il tasto "Invio"
            }
            else { this.ok = false; }
        }

        private void BtnInserisci_Click(object sender, EventArgs e)
        {

        }
    }
}
