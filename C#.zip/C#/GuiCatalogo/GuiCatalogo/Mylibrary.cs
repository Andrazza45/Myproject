﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuiCatalogo
{
    internal class Mylibrary
    {
        public static List<GuiCatalogo> LeggiFileOggetti(string PATH)
        {
            List<GuiCatalogo> lista = new List<GuiCatalogo>();
            FileStream fs = new FileStream(PATH, FileMode.Open, FileAccess.Read);
            BinaryFormatter bf = new BinaryFormatter();
            try
            {
                lista = bf.Deserialize(fs) as List<GuiCatalogo>;
            }
            catch (Exception)
            { 
            }
            fs.Close();
            return lista;
        }
        public static void ScriviFileOggetti(String PATH, List<GuiCatalogo> p)
        {
            FileStream fs = new FileStream(PATH, FileMode.Open, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, p);
            fs.Flush();
            fs.Close();
        }
        public static void ScriviFileCSV(String PATH, List<GuiCatalogo> elenco)
        {
            if (!File.Exists(PATH))
            {
                File.Create(PATH);
            }
            String txt = String.Join("\n", elenco);
            foreach (var item in elenco)
            {
                txt += (txt.Length != 0 ? "\n" : "") + item.ExportCSV();//non devi scrivere return
                StreamWriter sw = new StreamWriter(PATH);
                sw.WriteLine(txt);
                sw.Flush();
                sw.Close();

            }

        }


        public static List<GuiCatalogo> LeggiFileCSV(String PATH)
        {
            var lista = new List<GuiCatalogo>();
            StreamReader sr = new StreamReader(PATH);
            String txt = sr.ReadToEnd();
            sr.Close();
            String[] righe = txt.Split('\n');

            foreach (var item in righe)
            {
                String[] dati = item.Split(';');
                lista.Add(
                    new GuiCatalogo
                    {
                        Cod = Convert.ToInt32(dati[0]),
                        Nome = dati[1],
                        Desc = dati[3],
                        prezzo = Convert.ToDouble(dati[2]),
                        giacenza = Convert.ToInt32(dati[4])

                    }

                    );

            }
            return lista;

        }
    }
}
