﻿namespace GuiCatalogo
{
    partial class NuovoProdotto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txtdesc = new System.Windows.Forms.TextBox();
            this.Lbldesc = new System.Windows.Forms.Label();
            this.Txtprezzo = new System.Windows.Forms.TextBox();
            this.Lblprezzo = new System.Windows.Forms.Label();
            this.Btncartella = new System.Windows.Forms.Button();
            this.BtnInserisci = new System.Windows.Forms.Button();
            this.Txtgiac = new System.Windows.Forms.TextBox();
            this.Lblgiac = new System.Windows.Forms.Label();
            this.Txtnome = new System.Windows.Forms.TextBox();
            this.Lblnome = new System.Windows.Forms.Label();
            this.Txtcod = new System.Windows.Forms.TextBox();
            this.Lblcod = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Txtdesc
            // 
            this.Txtdesc.Location = new System.Drawing.Point(128, 140);
            this.Txtdesc.Name = "Txtdesc";
            this.Txtdesc.Size = new System.Drawing.Size(145, 20);
            this.Txtdesc.TabIndex = 24;
            // 
            // Lbldesc
            // 
            this.Lbldesc.AutoSize = true;
            this.Lbldesc.Location = new System.Drawing.Point(62, 142);
            this.Lbldesc.Name = "Lbldesc";
            this.Lbldesc.Size = new System.Drawing.Size(60, 13);
            this.Lbldesc.TabIndex = 23;
            this.Lbldesc.Text = "descrizione";
            // 
            // Txtprezzo
            // 
            this.Txtprezzo.Location = new System.Drawing.Point(128, 172);
            this.Txtprezzo.Name = "Txtprezzo";
            this.Txtprezzo.Size = new System.Drawing.Size(145, 20);
            this.Txtprezzo.TabIndex = 22;
            // 
            // Lblprezzo
            // 
            this.Lblprezzo.AutoSize = true;
            this.Lblprezzo.Location = new System.Drawing.Point(62, 175);
            this.Lblprezzo.Name = "Lblprezzo";
            this.Lblprezzo.Size = new System.Drawing.Size(39, 13);
            this.Lblprezzo.TabIndex = 21;
            this.Lblprezzo.Text = "Prezzo";
            // 
            // Btncartella
            // 
            this.Btncartella.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Btncartella.Location = new System.Drawing.Point(220, 258);
            this.Btncartella.Name = "Btncartella";
            this.Btncartella.Size = new System.Drawing.Size(75, 23);
            this.Btncartella.TabIndex = 20;
            this.Btncartella.Text = "cartella";
            this.Btncartella.UseVisualStyleBackColor = false;
            // 
            // BtnInserisci
            // 
            this.BtnInserisci.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.BtnInserisci.Location = new System.Drawing.Point(128, 258);
            this.BtnInserisci.Name = "BtnInserisci";
            this.BtnInserisci.Size = new System.Drawing.Size(75, 23);
            this.BtnInserisci.TabIndex = 19;
            this.BtnInserisci.Text = "Inserisci";
            this.BtnInserisci.UseVisualStyleBackColor = false;
            this.BtnInserisci.Click += new System.EventHandler(this.BtnInserisci_Click_1);
            // 
            // Txtgiac
            // 
            this.Txtgiac.Location = new System.Drawing.Point(128, 215);
            this.Txtgiac.Name = "Txtgiac";
            this.Txtgiac.Size = new System.Drawing.Size(145, 20);
            this.Txtgiac.TabIndex = 18;
            // 
            // Lblgiac
            // 
            this.Lblgiac.AutoSize = true;
            this.Lblgiac.Location = new System.Drawing.Point(62, 218);
            this.Lblgiac.Name = "Lblgiac";
            this.Lblgiac.Size = new System.Drawing.Size(52, 13);
            this.Lblgiac.TabIndex = 17;
            this.Lblgiac.Text = "Giacenza";
            // 
            // Txtnome
            // 
            this.Txtnome.Location = new System.Drawing.Point(128, 99);
            this.Txtnome.Name = "Txtnome";
            this.Txtnome.Size = new System.Drawing.Size(145, 20);
            this.Txtnome.TabIndex = 16;
            // 
            // Lblnome
            // 
            this.Lblnome.AutoSize = true;
            this.Lblnome.Location = new System.Drawing.Point(62, 102);
            this.Lblnome.Name = "Lblnome";
            this.Lblnome.Size = new System.Drawing.Size(35, 13);
            this.Lblnome.TabIndex = 15;
            this.Lblnome.Text = "Nome";
            // 
            // Txtcod
            // 
            this.Txtcod.Location = new System.Drawing.Point(128, 52);
            this.Txtcod.Name = "Txtcod";
            this.Txtcod.Size = new System.Drawing.Size(145, 20);
            this.Txtcod.TabIndex = 14;
            // 
            // Lblcod
            // 
            this.Lblcod.AutoSize = true;
            this.Lblcod.Location = new System.Drawing.Point(62, 59);
            this.Lblcod.Name = "Lblcod";
            this.Lblcod.Size = new System.Drawing.Size(40, 13);
            this.Lblcod.TabIndex = 13;
            this.Lblcod.Text = "Codice";
            // 
            // NuovoProdotto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 406);
            this.Controls.Add(this.Txtdesc);
            this.Controls.Add(this.Lbldesc);
            this.Controls.Add(this.Txtprezzo);
            this.Controls.Add(this.Lblprezzo);
            this.Controls.Add(this.Btncartella);
            this.Controls.Add(this.BtnInserisci);
            this.Controls.Add(this.Txtgiac);
            this.Controls.Add(this.Lblgiac);
            this.Controls.Add(this.Txtnome);
            this.Controls.Add(this.Lblnome);
            this.Controls.Add(this.Txtcod);
            this.Controls.Add(this.Lblcod);
            this.Name = "NuovoProdotto";
            this.Text = "NuovoProdotto";
            this.Load += new System.EventHandler(this.NuovoProdotto_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Txtdesc;
        private System.Windows.Forms.Label Lbldesc;
        private System.Windows.Forms.TextBox Txtprezzo;
        private System.Windows.Forms.Label Lblprezzo;
        private System.Windows.Forms.Button Btncartella;
        private System.Windows.Forms.Button BtnInserisci;
        private System.Windows.Forms.TextBox Txtgiac;
        private System.Windows.Forms.Label Lblgiac;
        private System.Windows.Forms.TextBox Txtnome;
        private System.Windows.Forms.Label Lblnome;
        private System.Windows.Forms.TextBox Txtcod;
        private System.Windows.Forms.Label Lblcod;
    }
}