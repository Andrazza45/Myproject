﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuiCatalogo
{
    public partial class NuovoProdotto : Form
    {
        public NuovoProdotto()
        {
            InitializeComponent();
        }
        private void BtnInserisci_Click_1(object sender, EventArgs e)
        {
            String PATH = @"..\..\File\prodotti.dat";
            if (!File.Exists(PATH))
            {
                FileStream fs = new FileStream(PATH, FileMode.CreateNew, FileAccess.Write);
            }
            var lista = Mylibrary.LeggiFileOggetti(PATH);
            lista.Add(new GuiCatalogo
            {
                Cod = Convert.ToInt32(Txtcod.Text),
                Nome = Txtnome.Text,
                Desc = Txtdesc.Text,
                prezzo = Convert.ToDouble(Txtprezzo.Text),
                giacenza = Convert.ToInt32(Txtgiac.Text)
            }

                );
            Mylibrary.ScriviFileOggetti(PATH, lista);
            MessageBox.Show("Op avvenuta con successo!");

            //1.
            //var p = new GuiCatalogo
            //{
            //    Codice = Convert.ToInt32(Txtcod.Text),
            //    Nome = Txtnome.Text,
            //    Descrizione = Txtdesc.Text,
            //    Prezzo = Convert.ToDouble(Txtprezzo.Text),
            //    Giacenza = Convert.ToInt32(Txtgiac.Text)
            //};


            //2.
            //BinaryFormatter bf = new BinaryFormatter();
            //bf.Serialize(fs, p);
            //fs.Close();
        }

        private void NuovoProdotto_Load(object sender, EventArgs e)
        {

        }
    }
}
