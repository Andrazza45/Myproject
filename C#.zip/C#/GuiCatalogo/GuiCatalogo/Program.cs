﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuiCatalogo
{

    [Serializable]
    public class GuiCatalogo

    {
        public int Cod { get; set; }
        public String Nome { get; set; }
        public String Desc { get; set; }
        public double prezzo { get; set; }
        public int giacenza { get; set; }

        public bool Scorta() => giacenza > 0 && giacenza < 10;
        public bool Esaurito() => giacenza == 0;
        public String ExportCSV()
        {
            //codice; nome; prezzo; giacenza
            return $"" +
                $"{Cod.ToString() }" + "," +
                $"{Nome}" + "," +
                $"{prezzo.ToString() }" + "," +
                $"{giacenza.ToString() }" + ";";
        }
        // public VenditaProdotti(int Cod, String Nome, double prezzo, DateTime dob, string[] MateriePrime)
        // {
        // this.Cod = Cod;
        // this.Nome = Nome;
        // this.prezzo = prezzo;
        // this.dob = (dob).ToString();
        // this.MateriePrime = MateriePrime;
        // }

        public override string ToString()
        {
            return this.Cod.ToString() + ";" + this.Nome + ";" + this.Desc + ";" + this.prezzo.ToString() + ";" + this.giacenza.ToString() + ";";
        }
    }
    static class Program
    {
        /// <summary>
        /// Punto di ingresso principale dell'applicazione.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Menu());
        }
    }
}
