﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atleti
{
    public interface IAtleta
    {
        public string Corro();
        public string Salto();
    }
}
