﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atleti
{
    public interface ITennista
    {
        public string Dritto();
        public string Rovescio();
    }
}
