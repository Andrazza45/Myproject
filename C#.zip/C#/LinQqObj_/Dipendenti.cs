﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace LinQqObj
{

        public class Persona
        {
            private String Cognome;
            private String Nome;
            private String Codfisc;
            private String mansione;
            private double PagaOraria;
            private int OreLavorate;
            private String dob;
            private String sesso;
            private String luogo;
            private double stipendio;
            private double bonus;

            public Persona(String Cognome, String Nome, String dob, String sesso, String luogo, Enum mansione, int Ore, double PagaOraria)
            {
                this.Cognome = Cognome;
                this.Nome = Nome;
                this.dob = dob;
                this.mansione = (mansione).ToString();
                this.luogo = luogo;
                this.OreLavorate = Ore;
                this.PagaOraria = PagaOraria;
                this.sesso = sesso;
                this.Codfisc = CodFisc(); 
                
                switch (this.mansione)
                {
                    case "INSTALLATORE": this.bonus = 175.50; break;
                    case "MANUTENTORE": this.bonus = 250.75; break;
                }
                this.stipendio = this.PagaOraria * this.OreLavorate + this.bonus;

            }
            private String CodFisc()
            {
            char[] CodFisc = new char[16];
            char[] CodificaM = { 'A', 'B', 'C', 'D', 'E', 'H', 'L', 'M', 'P', 'R', 'S', 'T' };
            char[] vocali = {'a','e','i','o','u'};
            char[] nome = this.Nome.ToCharArray();
            char[] cognome = this.Cognome.ToCharArray();
            char[] giorno = this.dob.ToString().Split('-')[2].ToCharArray();
            String mese = this.dob.ToString().Split('-')[1];
            char[] anno = this.dob.ToString().Split('-')[0].ToCharArray();
            String File = Mylibrary.LeggiFileTesto(@".\Files\Elenco-comuni-italiani.csv");
            char[]belfiore = (Mylibrary.Belfiore(File, this.luogo)).ToCharArray();

            int inseriti = 0;
            int c = 0;            
                for(int j = 0; inseriti < 3 && j < cognome.Length; j++)
                {
                    for(int k = 0; k < 5; k++)
                    {
                    if(cognome[j] != vocali[k])
                    {   
                        c+=1;
                    }

                    }
                    if(c == 5)
                    {
                    CodFisc[inseriti] = cognome[j];
                    inseriti+= 1;
                    }
                    c = 0;
                }
            if(inseriti < 3)
            {
                for(int j = 0;inseriti < 3 && j < cognome.Length ; j++)
                {
                    for(int k = 0; k < 5; k++)
                    {
                    if(cognome[j] == vocali[k])
                    {
                        CodFisc[inseriti] = cognome[j];
                        inseriti+= 1;
                        k = 5;
                    }
                    }
                }
            }
            inseriti = 3;
                for(int j = 0; inseriti < 6 && j < nome.Length; j++)
                {
                    for(int k = 0; k < 5; k++)
                    {
                   if(nome[j] != vocali[k])
                    {   
                        c+=1;
                    }

                    }
                    if(c == 5)
                    {
                    CodFisc[inseriti] = nome[j];
                    inseriti+= 1;
                    }
                    c = 0;
                    }
            if(inseriti < 6)
            {
                for(int j = 0;inseriti < 6 && j < nome.Length ; j++)
                {
                    for(int k = 0; k < 5; k++)
                    {
                    if(nome[j] == vocali[k])
                    {
                        CodFisc[inseriti] = nome[j];
                        inseriti+= 1;
                        k = 5;
                    }
                    }
                }
            }
            CodFisc[6] = anno[2];
            CodFisc[7] = anno[3];
            switch (Convert.ToInt32(mese))
            {
                case 1: CodFisc[8] = CodificaM[0]; break;
                case 2: CodFisc[8] = CodificaM[1]; break;
                case 3: CodFisc[8] = CodificaM[2]; break;
                case 4: CodFisc[8] = CodificaM[3]; break;
                case 5: CodFisc[8] = CodificaM[4]; break;
                case 6: CodFisc[8] = CodificaM[5]; break;
                case 7: CodFisc[8] = CodificaM[6]; break;
                case 8: CodFisc[8] = CodificaM[7]; break;
                case 9: CodFisc[8] = CodificaM[8]; break;
                case 10: CodFisc[8] = CodificaM[9]; break;
                case 11: CodFisc[8] = CodificaM[10]; break;
                case 12: CodFisc[8] = CodificaM[11]; break;
            }
            int gc;
            if (this.sesso is "M")
            {
                if(giorno.Length == 2)
                {
                CodFisc[9] = giorno[0];
                CodFisc[10] = giorno[1];
                }
                else
                {
                CodFisc[9] = '0';
                CodFisc[10] = giorno[0];
                    
                }
            }
            else
            {
                gc = Convert.ToInt32(string.Join("", giorno))+40;
                CodFisc[9] = gc.ToString().ToCharArray()[0];
                CodFisc[10] = gc.ToString().ToCharArray()[1];
            }
                CodFisc[11] = belfiore[0];
                CodFisc[12] = belfiore[1];
                CodFisc[13] = belfiore[2];
                CodFisc[14] = belfiore[3];
                CodFisc[15] = Mylibrary.CarattereControllo(CodFisc);


            return new string(CodFisc);
            }
            public int GetMinore()
            {
            int diff = 0;
            DateTime ora = DateTime.Now;
            int oggi = Convert.ToInt32((ora.ToString()).Split('-')[0]);
            int anno = Convert.ToInt32(this.dob.ToString().Split('-')[0].ToCharArray());
            diff = oggi - anno;
            if(diff < 18)
            {return diff;}
            else
            {
                return -1;
            }
            }
            public String GetNome()
            {
                return this.Nome;
            }

            public String GetCognome()
            {
                return this.Cognome;
            }

            public String GetMansione()
            {
                return this.mansione;
            }

            public int GetOreLavoro()
            {
                return this.OreLavorate;
            }

            public double GetPagaO()
            {
                return this.PagaOraria;
            }
            public double GetStip()
            {
                return this.stipendio;
            }

            public override string ToString()
            {
                return "Codice Fiscale: "+this.Codfisc+" Mansione: "+ this.mansione.ToString() +" Ore Lavorate: "+ this.OreLavorate.ToString() +" Paga Oraria: "+ this.PagaOraria.ToString();
            }





        }
    }

