namespace Functions {
    

public class Tastiera 
{
     public String InserisciTesto(String str)
     {
        String testo ="";
        Boolean criterio = false;
        while(criterio == false)
        {
        Console.WriteLine(str);
        testo = Console.ReadLine();  
        char[]chr = testo.ToCharArray();
        for(int i = 0; i <chr.Length; i ++)
        {
            if((int)(chr[i]) >= 65 && (int)(chr[i]) <= 128 )
            {
                criterio = true;
            }
            else{criterio = false; i = chr.Length;}
        }
        }
        return testo;
    }
     public int InserisciIntero(String str)
     {
        String intero ="";
        Boolean criterio = false;
        int count = 0;
        while(criterio == false)
        {
        Console.WriteLine(str);
        intero = Console.ReadLine();  
        char[]chr = intero.ToCharArray();
        for(int i = 0; i <chr.Length; i ++)
        {
            if(chr[i] == '-')
            {
                count += 1;
            }
            if((int)(chr[i]) >= 48 && (int)(chr[i]) <= 57 && count == 0 || count == 1 )
            {
                criterio = true;
            }
            else{criterio = false; i= chr.Length;}
        }
        }
        return Convert.ToInt32(intero);
    }

    public double InserisciDouble(String str)
    {
       Boolean criteri = false;
       String nd = "";
       while(criteri == false)
       {
        Console.WriteLine(str);
        nd = Console.ReadLine();
        int count = 0;
        char[]chr = nd.ToCharArray();
        for(int i = 0; i < nd.Length; i ++)
        {
            if(chr[i] == '.')
            {
                count +=1;
            }
            if((int)(chr[i]) >= 48 && (int)(chr[i]) <= 57 && count == 1 )
            {
                criteri = true;
            }
            else{criteri = false;}
        }
        
       }
        return Convert.ToDouble(nd);
    }

}
}