﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinQqObj
{
    public class Mylibrary
    {
        //lettura di file da file di testo
        public static string LeggiFileTesto(string path)
        {
            try 
            {
                String testo = "";
                StreamReader sr = new StreamReader(path);
                testo = sr.ReadToEnd();
                
                sr.Close();
                return testo;

            }
                
            catch (FileNotFoundException ex) { throw new FileNotFoundException(); }

        }
        //Scrittura su file di testo
        public static void ScriviFileTesto(string path, string testo)
        {
            StreamWriter sw = new StreamWriter(path);
            sw.Write(testo);
            sw.Flush();
            sw.Close();

        }


        public static String[] ListaComuni(String file)
        {
            String[] riga = file.Split('\n');

            String[] Lista = new string[riga.Length - 3];

            for (int i = 3; i < riga.Length - 3; i++)
            {
              Lista[i - 3] = (riga[i].Split(',')[5]).Replace("\"","");
            }
            return Lista;
        }
        public static String Belfiore(String file, String luogo)
        {
            luogo = "\""+luogo+"\"";
            String[] riga = file.Split('\n');
            for(int i = 3; i < riga.Length - 3 ; i ++)
            {
             if(riga[i].Split(',')[5] == luogo )
               { return riga[i].Split(',')[19].Replace("\"","");}
            }
            return "Non trovato";
        }


        public static char CarattereControllo(char[] codfisc)
        {
            char [] Pari = {'0','1','2', '3', '4', '5', '6', '7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
            String [] Dispari = {"1","0","5", "7", "9", "13", "15", "17","19","21","1","0","5","7","9","13","15","17","19","21","2","4","18","20","11","3","6","8","12","14","16","10","22","25","24","23"};
            char [] alfabeto = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
            int somma = 0;
            for(int i = 0; i < codfisc.Length; i++)
            {
            if(i % 2 != 0)
            {
                for(int j = 0; j < Pari.Length; j++)
                    if(codfisc[i] == Pari[j])
                    {
                        if((int)(Pari[j]) >=48 && (int)(Pari[j]) <= 57)
                        {somma += j;break;}
                        else{somma += j - 10 ;break;}
                    }
                    
            }
            else{
                for(int j = 0; j < Pari.Length; j++)
                    if(codfisc[i] == Pari[j]) 
                    {somma += Convert.ToInt32(Dispari[j]);break;}
                    
            }  
            }
            int r = somma % 26;
            char ch = alfabeto[r];
            return ch;
        }



        }
}
