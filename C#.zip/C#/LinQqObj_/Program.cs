﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Functions;
namespace LinQqObj
{
    internal class Gestionale
    {
        List<Persona> dip = new List<Persona>();
        public void AddPersona(Persona p)
        {
            dip.Add(p);
        }
        public override String ToString()
        {
            String str = "";
            for(int i = 0; i < dip.Count; i++)
            {
                str += dip[i].ToString()+"\n";
            }
            return str; 
        }
        static void Main(string[] args)
        {
        Gestionale g = new Gestionale();        
        String str = @"
        1.Aggiungi dipendente
        2.Stampa dipendenti
        3.Fine";
        int scelta = 0;
        do
        {
            
        Console.Write(str);
        Console.WriteLine();
        scelta = Convert.ToInt32(Console.ReadLine());
        switch(scelta)
        {
            case 1: 
                   string basePath = Directory.GetCurrentDirectory();
                   Console.WriteLine(basePath);
                   Tastiera tastiera = new Tastiera();
                   String nome = "", cognome = "", dob;
                   String sesso = "";
                   String luogo = "";
                   int anno = 0, mese, giorno;
                   int OreLavoro;
                   double PagaO;
                   int mansione;
                   Enum M = Mansione.mansione.RISORSE_UMANE;
                   while(nome.Length < 2)
                   {nome = tastiera.InserisciTesto("Inserire il nome del dipendente:");}
                   while(cognome.Length < 2)
                   {cognome =tastiera.InserisciTesto("Inserire il cognome del dipendente:");}

                   mansione = -1;
                   while(mansione < 1 || mansione > 2)
                   {
                      mansione =tastiera.InserisciIntero("Inserire la mansione(1.INSTALLATORE/2.MANUTENTORE):");
                      switch(mansione)
                        {
                            case 1:M = Mansione.mansione.INSTALLATORE;break;
                            case 2:M = Mansione.mansione.MANUTENTORE;break;
                            default:Console.WriteLine("Mansione non trovata");break;
                        }
                   }

                    int len = 0;
                    while(len < 4)
                    {
                     anno = tastiera.InserisciIntero("Inserire l'anno di nascita:");
                     len = (anno).ToString().ToCharArray().Length;
                    }
                    
                    mese = tastiera.InserisciIntero("Inserire il mese di nascita:");

                    while (mese < 1 || mese > 12)
                        mese = tastiera.InserisciIntero("Inserire il mese di nascita:");

                    if (mese == 4 || mese == 6 || mese == 9 || mese == 11)
                    {
                        giorno = tastiera.InserisciIntero("Inserire il giorno di nascita:");
                    while (giorno < 1 || giorno > 30)
                            giorno = tastiera.InserisciIntero("Inserire il giorno di nascita:");
                    }
                    else if (mese == 2)
                    {
                            giorno = giorno = tastiera.InserisciIntero("Inserire il giorno di nascita:");
                            while (giorno < 1 || giorno > 28)
                                giorno = tastiera.InserisciIntero("Inserire il giorno di nascita:");
                    }
                        else
                        {
                            giorno = tastiera.InserisciIntero("Inserire il giorno di nascita:");
                            while (giorno < 1 || giorno > 31)    
                                    giorno = tastiera.InserisciIntero("Inserire il giorno di nascita:");
                        }
                    dob = anno+"-"+mese+"-"+giorno;


                    while(sesso != "M" && sesso != "F" )
                    {
                     Console.WriteLine("Inserire il Sesso del dipendente:");
                     sesso = Console.ReadLine();
                     if(sesso != "M" && sesso != "F" )
                     {
                        Console.WriteLine("Sesso sconosciuto!");
                     }
                    }

                    String File = Mylibrary.LeggiFileTesto(@"./Files/Elenco-comuni-italiani.csv");
                    String[] l; 
                    l = Mylibrary.ListaComuni(File);
                    bool trovato = false;
                    while(trovato == false)
                    {
                    for(int i = 0; i < l.Length - 3; i++)
                    {
                        Console.WriteLine(i.ToString()+"."+l[i]);
                    }
                     Console.WriteLine("Inserire il luogo di nascita:");
                     luogo = Console.ReadLine();
                     for(int i = 0; i < l.Length; i++)
                     {
                        if(l[i] == luogo)
                        {
                            trovato = true;
                            i = l.Length;
                        }
                     }
                     if(trovato == false)
                     {
                        Console.WriteLine("Comune inesistente, riprovare!");
                     }
                    }

                    OreLavoro = tastiera.InserisciIntero("Inserire il numero di ore di lavoro mensili:");
                    PagaO =tastiera.InserisciDouble("Inserire la Paga Oraria del dipendente:");

                    Persona p= new Persona(cognome, nome, dob, sesso, luogo, M, OreLavoro,PagaO);
                    g.AddPersona(p);
                    break;
            case 2:Console.WriteLine(g.ToString());break;       
            case 3:Console.WriteLine("FINE!");break;
            default:Console.WriteLine("Scelta non valida!");break;
        }
        }while(scelta != 3);

    }
}
}
