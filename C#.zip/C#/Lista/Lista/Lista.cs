﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace Lista
{
    internal class Program
    {
        static void Main(string[] args) 
        {
            Console.WriteLine("");
            Console.WriteLine("");
            var lista = new ArrayList();
            var lista1 = new List<int>() { 12, 4, -5, -56, -90, 78 };
            Console.WriteLine($"Capacità: {lista.Capacity}");
            Console.WriteLine($"Dimensione: {lista.Count}");
            //Aggiunta di elementi alla lista
            lista.Add("Piero");
            lista.Add(12);
            lista.Add(12.75);
            lista.Add(false);
            lista.Add('@');
            lista.Add(new ArrayList());
            Console.WriteLine($"Capacità: {lista.Capacity}");
            Console.WriteLine($"Dimensione: {lista.Count}");

            foreach (var item in lista)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine($"Elemento in posizione 2:{lista[2]}");
            lista.Insert(2,"Giulia");
            for(int i = 0; i < lista.Count; i ++)
            {
                Console.WriteLine($"{i}: {lista[i]}");
            }
            lista.RemoveAt(4);
            Console.WriteLine("Oggetto in posizione 4 rimosso");
            Console.WriteLine(string.Join(",",lista1));

            //esempio
            //creo lista di numeri generati casualmente [1, 100]
            //cerco un numero dato in input
            Random random = new Random();
            var numeri = new List<int>();
            int numeriDaGenerare = random.Next(100) + 1;
            for (int i = 0; i < numeriDaGenerare; i++)
            {
                numeri.Add(random.Next(100) + 1);
            }
            Console.Write("Inserisci il numero da cercare:");
            int numero = int.Parse(Console.ReadLine());
            int posizione = numeri.IndexOf(numero);
            Console.WriteLine($"{numero} trovato in posizione {posizione}");
            Console.WriteLine(string.Join(", ", numeri));
        }
    }
}
