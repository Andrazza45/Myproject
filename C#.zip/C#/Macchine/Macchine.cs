using System;
using System.Linq;
namespace auto;
public class auto
{   
    private int cc;
    private int posti;
    private float v;
    private String marca;
    private String targa;
    private Boolean stato;
    private Boolean abs;
    private Boolean freno;
    private Boolean accelleratore;
    private Boolean Anabbaglianti;
    private Boolean luce;
    private string []seq = {"Accendi","Aria","Anabbaglianti"}; //default
     public void init()
     {   
     for(int i = 0; i < 3;i ++)
     {
         switch(seq[i])
         {
             case "Accendi":break;// this.accendi();
              case "Aria":break;// this.Aria();
             case "Anabbaglianti":this.Anabbaglianti_on();break;
         }
     }
     }
    public auto(int posti,String marca, String targa)
    {    this.cc = 1500; 
         this.v = 50;
         this.posti  = posti;
         this.marca = marca;
         this.targa = targa;
         this.abs = false;
         this.freno = false;
         this.accelleratore = false;
         this.Anabbaglianti = false;
         this.luce = false;
    }
    public String Get_marca()
    {
        return this.marca;
    }
        public String Get_targa()
    {
        return this.targa;
    }
        public int Get_posti()
    {
        return this.posti;
    }
    public Boolean Get_abs()
    {
        return this.abs;
    }
        public Boolean Get_freno()
    {
        return this.freno;
    }
    private Boolean abs_on()
    {   this. v += 22; 
        this.abs = true;
        return this.abs;
    }
       public Boolean frenata()
       {   
        if (this.freno == false)
           {
           this.accelleratore = false;
           this.freno = true;
           this.decelera();
           }
        return this.freno;
    }
    public Boolean accellerazione()
       {   
        if (this.accelleratore == false)
           {
           this.freno = false;
           this.accelleratore = true;
           this.accellera();
           }

        return this.accelleratore;
    }
    private double accellera(float a = 134)
    {
    
     double  ds = 0.1;
     ds += this.v + 0.5* a * Math.Pow(3600,2);  
     return ds;
    }
    private double decelera(float a = 80)
    {
 
     this.abs_on();
     double  ds = 0.1;
     ds -= this.v - 0.5* a * Math.Pow(3600,2);  
     return ds;
    }
    public double apri_(double o)
    {
      double ap = 100.11;
      if (o < ap)
      {ap -= o;}
      else{ap += o;}
      return ap;
    }
    public Boolean Anabbaglianti_on()
    {
      if (this.Anabbaglianti == false)
          this.Anabbaglianti = true;
        
      else 
          this.Anabbaglianti = false;
        return this.Anabbaglianti;
    }
    public Boolean Luci()
    {
     if (this.luce == false)
        this.luce = true;
           
      else 
          this.luce = false;
      return this.luce;
    }
    public double oscilla()
    {
      double x = 0.0;
      double x1 = 21.0, x2 = 100.0;
      
      
           if(this.stato == true)
             {this.stato = false;}
           else
           {
            this.stato = true;
           }
      switch (this.stato)
      {
        case  true: x += x1;return x;
        case  false: x += x2;return x;
      }
      
    }
    private void suono()
    {
     
    }
    public override string ToString()
    {
     return $"{nameof(cc)} = {cc.ToString()}" +
     $", {nameof(v)} = {v.ToString()}" +
     $", {nameof(posti)} = {posti.ToString()}"+
     $", {nameof(marca)} = {marca}" +
     $", {nameof(targa)} = {targa}" +
     $", {nameof(Anabbaglianti)} = {Anabbaglianti}" +
     $", {nameof(luce)} = {luce}"+
     $", {nameof(freno)} = {freno}"+
     $", {nameof(accelleratore)} = {accelleratore}";
    }
}