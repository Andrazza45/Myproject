namespace auto
{
   internal class Program
   {
        static void Main(string[] args)
        {
        double o;
        auto auto1 = new auto( 3, "Honda", "rt342y6");
        auto1.init();
        auto1.accellerazione();
        auto1.frenata();
        auto1.Anabbaglianti_on();
        Console.WriteLine(auto1);
        int t = 1;
      while(t == 1)
      {    
         if(Console.ReadKey(true).Key == ConsoleKey.Enter)
         {t = -1;}

        if(t != 1)
          {

            for(int i = 0; i >= 0; i++ )
            {
            o = auto1.oscilla();
            Console.Write("|" + o + "|");
            }
        
          }
      }
     }
  }
}