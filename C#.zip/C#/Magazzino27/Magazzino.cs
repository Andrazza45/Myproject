namespace Magazzino27;
public class Prodotto
{
    private int Codice;
    private String Nome;
    private String Descrizione;
    private double Prezzo;
    private int Giacenza;


    public Prodotto(int Cod, string Nome, String desc, double prezzo,int giac)
    {
        this.Codice = Cod;
        this.Nome = Nome;
        this.Descrizione = desc;
        this.Prezzo = prezzo;
        this.Giacenza = giac;
    }
    public int Get_codice()
    {return this.Codice;}
    public String  Get_Nome()
    {return this.Nome;}
    
    public String Get_Descrizione()
    {return this.Descrizione;}
    
    public double Get_Prezzo()
    {return this.Prezzo;}
    
    public int Get_Giacenza()
    {return this.Giacenza;}
    
    public double Valore()
    {
        return this.Prezzo * this.Giacenza;
    }

    public override String ToString() 
    {
        
    return "Codice=" + this.Codice + " Nome=" + this.Nome + " Descrizione=" + this.Descrizione + " Prezzo=" + this.Prezzo + " Giacenza=" + this.Giacenza;
    
    }
    
}