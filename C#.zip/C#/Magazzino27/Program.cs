﻿using System;
using System.Linq;

namespace Magazzino27;

public class GestioneProdotti
{
    private List<Prodotto> prodotti= new List<Prodotto>();

    public GestioneProdotti()
    {}
    public List<Prodotto> Get_lista()
    {
        return this.prodotti;
    }

    public void Add(Prodotto p)
    {
        this.prodotti.Add(p);
    }
    public String Costoso()
    {   
        object Costoso = prodotti[0];
        double massimo = 0;
        foreach (var i  in prodotti)
        {
            var O = (Prodotto)i;
            if (massimo < O.Get_Prezzo())
               {
                massimo = O.Get_Prezzo();
                Costoso = O; 
               }
        }
        return Costoso.ToString();
    }
    public String Cerca(int cod)
    {
        foreach (var i  in prodotti)
        {
            var O = (Prodotto)i;
            if (O.Get_codice() == cod)
               {return O.ToString();}
        }
        return "Prodotto non trovato!!";
    }
    public double ValoreComplessivo()
    {
        double somma = 0;
        foreach (var i  in prodotti)
        {
            var O = (Prodotto)i;
            somma += O.Get_Prezzo();
        }
        return somma;
    }
    public String Prodotti_in_scorta()
    {
        String str = "Prodotti in scorta: \n";
        foreach (var i  in prodotti)
        {
            var O = (Prodotto)i;
            if(O.Get_Giacenza() >= 1 && O.Get_Giacenza() <= 9 )
            {
            str += O.ToString()+"\n";
            }
        }
        return str;
    }
    public String esauriti()
    {
        String str = "Prodotti Esauriti: \n";
        foreach (var i  in prodotti)
        {
            var O = (Prodotto)i;
            if(O.Get_Giacenza() == 0 )
            {
            str += O.ToString()+"\n";
            }
        }
        return str;
    }
    public double Inserisciprezzo()
    {
       Boolean criteri = false;
       String nd = "";
       while(criteri == false)
       {
        Console.WriteLine("Inserire il prezzo:");
        nd = Console.ReadLine();
        int count = 0;
        char[]chr = nd.ToCharArray();
        for(int i = 0; i < nd.Length; i ++)
        {
            if(chr[i] == '.')
            {
                count +=1;
            }
            if((int)(chr[i]) >= 48 && (int)(chr[i]) <= 57 && count == 1 )
            {
                criteri = true;
            }
            else{criteri = false;}
        }
        
       }
        return Convert.ToDouble(nd);
    }
	public static void Main()
	{
     int InserisciIntero()
     {
        String intero ="";
        Boolean criterio = false;
        int count = 0;
        while(criterio == false)
        {
        intero = Console.ReadLine();  
        char[]chr = intero.ToCharArray();
        for(int i = 0; i <chr.Length; i ++)
        {
            if(chr[i] == '-')
            {
                count += 1;
            }
            if((int)(chr[i]) >= 48 && (int)(chr[i]) <= 57 && count == 0 || count == 1 )
            {
                criterio = true;
            }
            else{criterio = false;}
        }
        }
        return Convert.ToInt32(intero);
     }

     Console.WriteLine("Gestione Magazzino \n");
     GestioneProdotti prodotti = new GestioneProdotti();
	 String str = @"
     1.visualizzare il prodotto con prezzo maggiore
     2.cercare un prodotto di cui si conosce il codice
     3.stabilire quanto è il valore del magazzino 
     4.elencare i prodotti che sono in scorta (giacenza [1-9])
     5.elencare i prodotti esauriti (giacenza=0)
     6.Aggiungi prodotto
     7.esci ";
    int scelta = 0;
    do
    {
        
     Console.Write(str);
     Console.WriteLine();
     scelta = Convert.ToInt32(Console.ReadLine());
     switch(scelta)
     {
        case 1:
               if(prodotti.Get_lista().Count != 0)
               {Console.WriteLine("Il prodotto con prezzo maggiore è: \n "+prodotti.Costoso());}
               else{Console.WriteLine("La lista dei prodotti è vuota");}
               break;
        case 2:
               if(prodotti.Get_lista().Count != 0)
               {
               Console.WriteLine("Inserire il codice del prodotto da cercare:");
               int c = Convert.ToInt32(Console.ReadLine());
               Console.WriteLine(prodotti.Cerca(c));
               }
               else{Console.WriteLine("La lista dei prodotti è vuota");}
               break;
        case 3:
               if(prodotti.Get_lista().Count != 0)
               {Console.WriteLine("Il valore complessivo del magazziono è:"+prodotti.ValoreComplessivo().ToString()+"€7");}
                else{Console.WriteLine("La lista dei prodotti è vuota");}break;
        
        case 4:
               if(prodotti.Get_lista().Count != 0)
               {Console.WriteLine(prodotti.Prodotti_in_scorta());}
                else{Console.WriteLine("La lista dei prodotti è vuota");}break;
        case 5:
               if(prodotti.Get_lista().Count != 0)
               {Console.WriteLine(prodotti.esauriti());}
                else{Console.WriteLine("La lista dei prodotti è vuota");}break;
        
        case 6:
               Console.WriteLine("<inserire il codice del prodotto:>");
               int Cod =InserisciIntero();
               Console.WriteLine("Inserire il nome del prodotto:");
               String nome =Console.ReadLine();
               Console.WriteLine("Inserire la descrizione del prodotto:");
               String descrizione =Console.ReadLine();
               Console.WriteLine("Inserire il prezzo del prodotto:");
               double prezzo = prodotti.Inserisciprezzo();
               Console.WriteLine("Inserire la giacenza del prodotto:");
               int giacenza =InserisciIntero();
               Prodotto p = new Prodotto(Cod,nome,descrizione,prezzo, giacenza);
               prodotti.Add(p);
               break;
        case 7: Console.WriteLine("FINE!");break;
        default:Console.WriteLine("Scelta non valida!");break;
     }
    }
    while(scelta != 7);
	}
			
}

