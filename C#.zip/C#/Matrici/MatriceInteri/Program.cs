﻿using System;
/*
 Generare una matrice di numeri interi casuali
con valori nell'intervallo [1,100]
 Stampare la matrice
 */
namespace MatriceInteri;
public static class Program
{
public static void Main()
{
Random random = new Random();

//matrice bidimensionale
int righe = 10;
int colonne = 7;

int[,] matrice = new int[righe,colonne];

for (int i = 0; i < righe; i++)
    for (int j = 0; j < colonne; j++)
        matrice[i,j]=random.Next(100)+1;

for (int i = 0; i < righe; i++)
{
    for (int j = 0; j < colonne; j++)
        Console.Write(matrice[i, j] + " ");
    Console.WriteLine();
}
}
}