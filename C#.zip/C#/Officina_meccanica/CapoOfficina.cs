using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Officina_meccanica
{
    public class CapoOfficina:Meccanico
    {
        private List<Ordine> Ordini= new List<Ordine>();
        public CapoOfficina(String Nome, String Cognome, double Stipendio, Enum Tipologia):base(Nome,Cognome,Stipendio,Tipologia)
        {
            base.Nome = Nome;
            base.Cognome = Cognome;
            base.Stipendio = Stipendio;
            this.Tipologia = Tipologia.ToString();
        }
        public List<Ordine> Get_listaO()
        {return this.Ordini;}
        public void AggiungiOrdine(Ordine ordine)
        {  
        Ordini.Add(ordine);
        }
        public int NoOrdini()
        {
            return this.Ordini.Count;
        }
        public override double Tredicesima()
        {
            double StipInc = (this.Stipendio)*2;
            double tot = 0;
            for(int i = 0; i < Ordini.Count;i++)
            {
             List<Prodotto> lstProd = new List<Prodotto>();
             lstProd = (List<Prodotto>)Ordini[i].GetListaP();
             for(int j = 0; j < lstProd.Count;j++)
             {
                tot += lstProd[j].Get_Prezzo();
             }
             StipInc += (tot * 0.05);
             tot = 0;
            }
            return StipInc;
        }
        public String StampOrd(int index)
        {
            return Ordini[index].ToString();
        }
        public String StampaOrdini()
        {
            String str ="";
            for(int i = 0; i < Ordini.Count;i++)
            {
                str+= Ordini[i].ToString();
            }
            return str;
        }
        public override String ToString()
        {
         return  " Nome  = "+base.Nome+" Cognome = "+ base.Cognome+ " Stipendio = "+base.Stipendio +" Tipologia = "+ this.Tipologia;
        }
    }
}