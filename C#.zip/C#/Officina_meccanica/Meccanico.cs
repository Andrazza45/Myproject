using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Officina_meccanica
{
    public class Meccanico:Persona
    {
        protected String Tipologia { get; set; }
        public Meccanico(String Nome, String Cognome, double Stipendio,Enum Tipologia)
        {
            base.Nome = Nome;
            base.Cognome = Cognome;
            base.Stipendio = Stipendio;
            this.Tipologia = Tipologia.ToString();
        }
        public String Get_Tipologia ()
        {
         return this.Tipologia;
        }
        public override double Tredicesima () // 93% in più dello stipendio
        {
            return this.Stipendio + (this.Stipendio* 0.93);
        }
        public override bool Equals(object? o) 
    
        {
         if(o is Meccanico)
         {
            Meccanico ob = (Meccanico) o;
            if(this.Nome == ob.Get_Nome() && this.Cognome == ob.Get_Cognome()
            && this.Stipendio == ob.Get_stipendio())
            {
                return true;
            }
            else{return false;}   
         }
         else{return false;}
        }
        public override String ToString()
        {
         return  " Nome  = "+base.Nome+" Cognome = "+ base.Cognome+ " Stipendio = "+base.Stipendio +" Tipologia = "+ this.Tipologia;
        }

    }
}