using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Officina_meccanica
{
    public class Ordine
    {
        private int id_ordine;
        private String data;
        private List<Prodotto> lista_prodotti = new List<Prodotto>();
        Venditore venditore = new Venditore("","",1000.0,Settori.settori.MECCANICA);
        public Ordine(int id_ordine, DateTime data, Venditore venditore)
        {
          this.id_ordine = id_ordine;
          this.data = (data).ToString();
        }
        public void AggiungiProd(Prodotto prod)
        {
            lista_prodotti.Add(prod);
        }
        public List<Prodotto> GetListaP()
        {
            return lista_prodotti;
        }
        public int NoProdotti()
        {
            return this.lista_prodotti.Count;
        }
        public double Totale()
        {
            double tot = 0;
            for(int i = 0; i < this.lista_prodotti.Count; i++)
            {
                tot += lista_prodotti[i].Get_Prezzo(); 
            }
            return tot;
        }
        public String StampaVenditore()
        {
            return this.venditore.ToString();
        }

        public override String ToString()//Stampa il risultato globale 
        {return  " ID_ordine = "+this.id_ordine+" data = "+ this.data; }
        public String Scontrino()//al dettaglio
        {
            String str= "";
            double subtot = 0;
            for(int i = 0; i < this.lista_prodotti.Count; i ++)
            {   
                 subtot += this.lista_prodotti[i].Get_Prezzo() * this.lista_prodotti[i].Get_qtord(); 
            }
            for(int i = 0; i < this.lista_prodotti.Count; i ++)
            {
                str += lista_prodotti[i].ToString() +" SUBTOTALE: "+subtot.ToString()+"\n";
            }
            return str;
        }
    }
}