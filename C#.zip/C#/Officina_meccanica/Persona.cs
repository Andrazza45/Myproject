using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Officina_meccanica
{
    public abstract class Persona
    {
        protected String Nome { get; set; }
        protected String Cognome{ get; set; }
        protected double Stipendio{ get; set; }
        // public Persona(String Nome, String Cognome, double Stipendio)
        // {
        //     this.Nome = Nome;
        //     this.Cognome =Cognome;
        //     this.Stipendio = Stipendio;
        // }
        public String Get_Nome()
        {return this.Nome;}
        public String Get_Cognome()
        {return this.Cognome;}
        public double Get_stipendio()
        {return this.Stipendio;}
        public abstract double Tredicesima();
        public abstract override String ToString();
    }
}