using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Officina_meccanica
{
    public class Prodotto
    {
        private String codice; //16 chr
        private String prodotto;
        private String descrizione;
        private double prezzo;
        private int qtord;
        public Prodotto(String codice, String Prodotto, String Descrizione, double prezzo)
        {
         this.codice = codice;
         this.prodotto = Prodotto;
         this.descrizione = Descrizione;
         this.prezzo = prezzo;
        }
        public int Get_qtord()
        {return this.qtord;}
        public String Get_Codice()
        {return this.codice;}
        public String Get_Prodotto()
        {return this.prodotto;}
        
        public String Get_Descrizione()
        {return this.descrizione;}
        
        public double Get_Prezzo()
        {return this.prezzo;}
        
        public String Tostring()
        {return  " Codice = "+this.codice +" Prodotto = "+ this.prodotto +" Descrizione = "+ this.descrizione+" Prezzo ="+ this.prezzo+" qt.ordinata = "+ this.qtord; }
    }
}