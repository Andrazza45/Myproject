using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Officina_meccanica
{
    public class Program
    {
    static CapoOfficina capO = new CapoOfficina("Andrea","Azzalin",2200.0,Settori.settori.AUTOMOBILE);
    static ResponsabileVenditori Resp = new ResponsabileVenditori("Andrea","Azzalin",2200.0,Settori.settori.MECCANICA);
    static List<Meccanico> meccanici = new List<Meccanico>();
    static List<Venditore> Venditori = new List<Venditore>();
    static void Main(string [] args)
    {
      
      int InserisciIntero(String mes)
     {
        String intero ="";
        Boolean criterio = false;
        int count = 0;
        while(criterio == false)
        {
        Console.WriteLine(mes);
        intero = Console.ReadLine();  
        char[]chr = intero.ToCharArray();
        for(int i = 0; i <chr.Length; i ++)
        {
            if(chr[i] == '-')
            {
                count += 1;
            }
            if((int)(chr[i]) >= 48 && (int)(chr[i]) <= 57 && count == 0 || count == 1 )
            {
                criterio = true;
            }
            else{criterio = false;}
        }
        }
        return Convert.ToInt32(intero);
     }
     double InserisciDouble(string mes)
    {
       Boolean criteri = false;
       String nd = "";
       while(criteri == false)
       {
        Console.WriteLine(mes);
        nd = Console.ReadLine();
        int count = 0;
        char[]chr = nd.ToCharArray();
        for(int i = 0; i < nd.Length; i ++)
        {
            if(chr[i] == '.')
            {
                count +=1;
            }
            if((int)(chr[i]) >= 48 && (int)(chr[i]) <= 57 && count == 1 )
            {
                criteri = true;
            }
            else{criteri = false;}
        }
        
       }
        return Convert.ToDouble(nd);
    }
     Console.WriteLine("Officina_Meccanica \n");
	 String str = @"
     1.Stampa dell’elenco dei venditori
     2.Stampa dell’elenco dei meccanici
     3.Stampa di un certo ordine
     4.Stampa dei dati del responsabile venditori
     5.Stampa dei dati del capo officina
     6.Inserimento dati
     7.Crea un ordine
     8.FINE
     ";
    int scelta = 0;
    do
    {
        
     Console.Write(str);
     Console.WriteLine();
     scelta = Convert.ToInt32(Console.ReadLine());
     switch(scelta)
     {
        case 1:
               if(Resp.Get_Venditori().Count != 0)
               {Console.WriteLine(Resp.StampaVenditori());}
               else{Console.WriteLine("La lista dei Venditori è vuota");}
               break;
        case 2:
               String stringa = "";
               for(int j = 0; j < meccanici.Count;j++)
               {
                 stringa += meccanici[j].ToString()+"\n";
               }
               Console.WriteLine(stringa);
               break;
        case 3:
               if(capO.Get_listaO().Count != 0)
            
                 {  
                    int x = InserisciIntero("Inserisci l'indice dell'ordine che vuoi trovare:");
                    Console.WriteLine(capO.StampOrd(x));
                 }
                else{Console.WriteLine("La lista degli ordini è vuota");}break;
                break;
        case 4:
               Console.WriteLine("Responsabile Venditori:\n");
               Console.WriteLine(Resp.ToString());
               break;
        case 5:
               Console.WriteLine("Capo Officina:\n");
               Console.WriteLine(capO.ToString());
               break;
        case 6:
               Console.WriteLine("Inserire il tipo di Responsabile:(1.Capo Officina, 2.meccanico 3.ResponsabileVenditori 4.Venditore)");
               String Nome = "",Cognome = "";
               double Stipendio = 0.0;
               int i = -1;
               while(i < 1 || i > 4)
               {
               i =InserisciIntero("Inserire un opzione:");
               switch(i)
               {
                case 1:
                       Console.WriteLine("Inserisci il nome:");
                       Nome = Console.ReadLine();
                       Console.WriteLine("Inserisci il cognome:");
                       Cognome = Console.ReadLine();
                       Console.WriteLine("Inserisci lo stipendio:");
                       Stipendio =InserisciDouble("Inserisci lo stipendio");
                       CapoOfficina co = new CapoOfficina(Nome,Cognome,Stipendio,Settori.settori.MECCANICA);
                       meccanici.Add(co);
                       break;
                case 2:
                       Console.WriteLine("Inserisci il nome:");
                       Nome = Console.ReadLine();
                       Console.WriteLine("Inserisci il cognome:");
                       Cognome = Console.ReadLine();
                       Console.WriteLine("Inserisci lo stipendio:");
                       Stipendio =InserisciDouble("Inserisci lo stipendio");
                       Meccanico m = new Meccanico(Nome,Cognome,Stipendio,Settori.settori.MECCANICA);
                       meccanici.Add(m);
                       break;
                case 3:
                        Console.WriteLine("Inserisci il nome:");
                       Nome = Console.ReadLine();
                       Console.WriteLine("Inserisci il cognome:");
                       Cognome = Console.ReadLine();
                       Console.WriteLine("Inserisci lo stipendio:");
                       Stipendio =InserisciDouble("Inserisci lo stipendio");
                       ResponsabileVenditori rv = new ResponsabileVenditori(Nome,Cognome,Stipendio,Settori.settori.CARROZZERIA);
                       Venditori.Add(rv);
                       break;
                        break;
                case 4:
                       Console.WriteLine("Inserisci il nome:");
                       Nome = Console.ReadLine();
                       Console.WriteLine("Inserisci il cognome:");
                       Cognome = Console.ReadLine();
                       Console.WriteLine("Inserisci lo stipendio:");
                       Stipendio =InserisciDouble("Inserisci lo stipendio");
                       Venditore v = new Venditore(Nome,Cognome,Stipendio,Settori.settori.CARROZZERIA);
                       Venditori.Add(v);
                       break;
                        break;
                default:
                        Console.WriteLine("Non trovato!");
                        break;
               }
               }
                break;
        case 7:
               String c = "";
               Console.WriteLine("Cognome: ");
               c = Console.ReadLine();

                if(capO.Get_Cognome() == c)
                {
                    int id = InserisciIntero("Inserire id dell'ordine");
                    DateTime data = DateTime.Now;
                    int vend = -1;
                    while(vend <= -1 || vend >= Venditori.Count)
                    {
                    vend = InserisciIntero("Da quale venditore vuoi acquistare?");
                    }
                    Ordine ordine = new Ordine(id,data, Venditori[vend]);
                    Console.WriteLine("Inserimento prodotti:");
                    bool conferma = false;
                    while(conferma == false)
                    {
                     int Len = 0;
                     String cod = "";
                     String name = "";
                     String desc = "";
                     double price;
                     while(Len < 16)
                     { 
                     Console.WriteLine("Codice:");
                     cod = Console.ReadLine();
                     Len = cod.ToCharArray().Length;
                     }
                     Console.WriteLine("Nome:");
                     name = Console.ReadLine();
                     Console.WriteLine("Descrizione:");
                     desc = Console.ReadLine();
                     price = InserisciDouble("Prezzo:");
                     Prodotto prod = new Prodotto(cod,name,desc,price);
                     ordine.AggiungiProd(prod);
                     int op = InserisciIntero("Vuoi smettere?(0.SI Other.NO)");
                     if(op == 0)
                     {
                      conferma = true;
                     }
                    }
                    capO.AggiungiOrdine(ordine);
               }
               else{Console.WriteLine("Capo_Officina non trovato!!");}
               break;
        case 8: Console.WriteLine("FINE!");break;
        default:Console.WriteLine("Scelta non valida!");break;
     }
    }
    while(scelta != 8);
        }
        
    }
}