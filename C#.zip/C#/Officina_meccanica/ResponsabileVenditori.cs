using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Officina_meccanica
{
    public class ResponsabileVenditori:Venditore
    {
     private List<Venditore> Venditori = new List<Venditore>();
        public ResponsabileVenditori(String Nome, String Cognome, double Stipendio, Enum Settore):base(Nome,Cognome,Stipendio,Settore)
        {
         base.Nome = Nome;
         base.Cognome = Cognome;
         base.Stipendio = Stipendio;
         this.Settore = Settore.ToString();
        }
     public List<Venditore> Get_Venditori()
     {
        return this.Venditori;
     }
     public void AggiungiVenditore(Venditore venditore)
     {
        Venditori.Add(venditore);
     }
     public Venditore Get_venditore(int index)
     {
        return Venditori[index];
     }
     public void CancellaVenditore(int index)
     {
        this.Venditori.Remove(this.Venditori[index]);

     }
     public override double Tredicesima()
     {
        double StipInc = (this.Stipendio)*2;
        for(int i = 0; i < this.Venditori.Count; i ++)
        {
         StipInc += ((this.Venditori[i].Get_stipendio())/30)* 0.15;
        }
        return StipInc;
     }
     public String StampaVenditori()
     {
        String str = "";
        for(int i= 0;i < this.Venditori.Count;i++ )
        {
            str += i.ToString()+"."+this.Venditori[i].ToString()+"\n";
        }
        return str;
     }
        public override String ToString()
        {
             return  " Nome  = "+base.Nome+" Cognome = "+ base.Cognome+ " Stipendio = "+base.Stipendio +" Settore = "+this.Settore;
        
        }
    }
}