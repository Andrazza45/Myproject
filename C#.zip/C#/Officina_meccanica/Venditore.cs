using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Officina_meccanica
{
    public class Venditore:Persona
    {
        protected String Settore { get; set; }
        public Venditore(String Nome, String Cognome, double Stipendio, Enum Settore)
        {
         base.Nome = Nome;
         base.Cognome = Cognome;
         base.Stipendio = Stipendio;
         this.Settore = Settore.ToString();
        }
    
        public  String Get_Settore()
        {
            return this.Settore;
        }

        public override double Tredicesima()
        {
            return this.Stipendio +(this.Stipendio *0.91);
        }
        public override String ToString()
        {
             return  " Nome  = "+base.Nome+" Cognome = "+ base.Cognome+ " Stipendio = "+base.Stipendio +" Settore = "+this.Settore;
        
        }

    }
}