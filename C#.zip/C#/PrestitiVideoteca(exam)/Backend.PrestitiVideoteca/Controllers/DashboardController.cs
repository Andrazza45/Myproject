﻿using Core_PrestitiVideoteca.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Backend.PrestitiVideoteca.Controllers
{
    public class DashboardController : Controller
    {
        private Core_PrestitiVideotecaContext db = new Core_PrestitiVideotecaContext();


        public IActionResult Index()
        {
            ViewBag.NumeroPrestitiAttivi = db.Prestiti.Where(p => p.DataRestituzione == null).ToListAsync();
            return View();

        }
    }
}
