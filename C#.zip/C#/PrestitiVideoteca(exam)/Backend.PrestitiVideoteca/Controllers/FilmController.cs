﻿using Core_PrestitiVideoteca.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Backend.PrestitiVideoteca.Controllers
{
    [Authorize(Roles = "Admminisrator")]
    public class FilmController : Controller
    {
        private readonly Core_PrestitiVideotecaContext _context;
        public FilmController(Core_PrestitiVideotecaContext context)
        {
            _context = context;
        }
        private Core_PrestitiVideotecaContext db = new Core_PrestitiVideotecaContext();

        //GET:Films
        public IActionResult Film()
        {
            ViewBag.films = db.Films.Where(f => f.Codice != null).ToListAsync();
            return View();

            
        }
    }
}
