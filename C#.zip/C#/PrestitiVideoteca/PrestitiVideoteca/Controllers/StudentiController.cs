﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Core_PrestitiVideoteca.Models;
using Core_PrestitiVideoteca.Service;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.IO;
using Newtonsoft.Json;
using PrestitiVideoteca.Models;

namespace Core_PrestitiVideoteca.Controllers
{
    public class StudentiController : Controller
    {

        public IActionResult PrestitiStudenteX(string search, bool orderby)
        {
            
            if (search == null)
            {
                search = "Reale";
            }

            RicercaXStudente r = new RicercaXStudente(search);

            //Assegna al modello il contenuto della ricerca per poi ordinarlo al click del link
            r.Ricerca = search;
            if (orderby == false)
            { r.ordina = true; }
            else { r.ordina = false; }

            return View(r);
        }
        public IActionResult Dashboard(string matricola, string nome, string cognome, string email, string classe, string pwd,string tipo)
        {
            if (tipo == "Register")
            {
                Studente s = new Studente(matricola, nome, cognome, email, classe, pwd);
                Gestionale g = new Gestionale(s);
                if (g.AddStudente(s) == 0)
                {
                    return View(s);
                }
                else { return View(); }
            }
            else
            {
                Studente s = new Studente(matricola, tipo, null, null, null, pwd);
                Gestionale g = new Gestionale(s);
                if (g.Login(s) == 0)
                {
                    return View(s);
                }
                else { return View(); }


            }
        }
        public IActionResult Register()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
    }
}
