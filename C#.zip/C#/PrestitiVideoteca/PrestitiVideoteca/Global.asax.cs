﻿using Microsoft.AspNetCore.Hosting.Server;
using System;
using System.Collections.Generic;
using Core_PrestitiVideoteca.Service;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Optimization;
using System.Web;
using Microsoft.AspNetCore.Http.Features;
using System.Composition.Hosting;
namespace PrestitiVideoteca
{
    public class Http : IHttpApplication<RicercaXStudente>
    {
        public Http()
        {
            Application_Start();
        }
        protected void Application_Start()
        {
            BundleTable.EnableOptimizations = false;
            #if DEBUG
            BundleTable.Bundles.GetBundleFor("./Service/RicercaXStudente");
            #endif
        }

        RicercaXStudente IHttpApplication<RicercaXStudente>.CreateContext(IFeatureCollection contextFeatures)
        {
            throw new NotImplementedException();
        }

        void IHttpApplication<RicercaXStudente>.DisposeContext(RicercaXStudente context, Exception exception)
        {
            throw new NotImplementedException();
        }

        Task IHttpApplication<RicercaXStudente>.ProcessRequestAsync(RicercaXStudente context)
        {
            throw new NotImplementedException();
        }
    }
}
