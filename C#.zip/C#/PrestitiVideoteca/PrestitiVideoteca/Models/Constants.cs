using System.IO;

namespace Core_PrestitiVideoteca.Models
{
    public class Constants
    {
        const string PATH = "../PrestitiVideoteca/Files/Liste.dat";
        public string getPath()
        {
            if (!File.Exists(Constants.PATH))
            { File.Create(Constants.PATH); }

            return Constants.PATH;
        
        }
    }
}