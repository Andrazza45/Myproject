﻿using Core_PrestitiVideoteca.Service;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Core_PrestitiVideoteca.Models
{
    public class MostraFilm
    {

        private List<Film> films = new List<Film>();
        public MostraFilm()
        { this.caricafilms(); }

        public void caricafilms()
        {
            //accesso al DB
            SqlConnection sqlconnection = new Connection().Open(0);
            string sql = "select * from Film";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {

                (this.films).Add(
                new Film(
                !sdr.IsDBNull(0) ? sdr.GetInt32(0) : 0,
                !sdr.IsDBNull(1) ? sdr.GetString(1) : null,
                !sdr.IsDBNull(2) ? sdr.GetString(2) : null,
                !sdr.IsDBNull(3) ? sdr.GetString(3) : null,
                !sdr.IsDBNull(4) ? sdr.GetString(4) : null,
                !sdr.IsDBNull(5) ? sdr.GetString(5) : null));

            }
            //Mylibrary.ScriviFileOggetti(Constants.getPath(), films);
        }
        public List<Film> getList()
        { return this.films; }
    }
}
