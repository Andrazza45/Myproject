﻿using Core_PrestitiVideoteca.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Core_PrestitiVideoteca.Models
{
    internal class Mylibrary
    {
        public static List<Prestito> LeggiFileOggetti(string PATH)
        {
            List<Prestito> lista = new List<Prestito>();
            FileStream fs = new FileStream(PATH, FileMode.Open, FileAccess.Read);
            BinaryFormatter bf = new BinaryFormatter();
            try
            {
                lista = bf.Deserialize(fs) as List<Prestito>;
            }
            catch (Exception)
            { 
            }
            fs.Close();
            return lista;
        }
        public static void ScriviFileOggetti(String PATH, List<Prestito> p)
        {
            FileStream fs = new FileStream(PATH, FileMode.Open, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, p);
            fs.Flush();
            fs.Close();
        }

    }
}
