﻿using System;

namespace Core_PrestitiVideoteca.Models
{
    [Serializable]
    public partial class Prestito
    {
        private int Id { get; set; }
        private int IdFilm { get; set; }
        private String Matricola { get; set; }
        private DateTime DataPrestito { get; set; }
        private DateTime DataRestituzione { get; set; }
        

        public Prestito(int IdFilm, String Matricola, DateTime DataPrestito, DateTime DataRestituzione)
        {
            this.IdFilm = IdFilm;
            this.Matricola = Matricola;
            this.DataPrestito = DataPrestito;
            this.DataRestituzione = DataRestituzione;
        }
        public int get_id
        {
            get { return this.IdFilm; }
        }
        public String get_matricola
        {
            get { return this.Matricola; }
        }
        public DateTime get_dataP
        {
            get { return this.DataPrestito; }
        }
        public DateTime get_dataR
        {
            get { return this.DataRestituzione; }
        }
        public virtual Film IdFilmNavigation { get; set; } = null!;
        public virtual Studente MatricolaNavigation { get; set; } = null!;
    }
}
