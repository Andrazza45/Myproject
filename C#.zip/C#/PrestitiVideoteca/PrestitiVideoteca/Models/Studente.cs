﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Core_PrestitiVideoteca.Models
{
    [Serializable]
    public partial class Studente
    {
        public String Matricola { get; set; }
        public String Nome { get; set; } = null!;
        public String Cognome { get; set; } = null!;
        public String Email { get; set; } = null!;
        public String Classe { get; set; } = null!;
        public String hashedInput { get; set; } = null!;

        public Studente(String Matricola,String Nome, String Cognome,String Email,String Classe, String Pwd)
        {
            this.Matricola = Matricola;
            this.Nome = Nome;
            this.Cognome = Cognome;
            this.Email = Email;
            this.Classe = Classe;
            String input = Pwd;
            this.hashedInput = Pwd;
            if (input != null && this.Nome != null)
            {
                // Creazione del provider di crittografia MD5
                using (MD5 md5 = MD5.Create())
                {
                    // Calcola l'hash MD5 del testo di input
                    byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                    byte[] hashBytes = md5.ComputeHash(inputBytes);

                    // Converti il risultato in una stringa esadecimale
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < hashBytes.Length; i++)
                    {
                        builder.Append(hashBytes[i].ToString("x2"));
                    }

                    this.hashedInput = builder.ToString();
                }
                
            }
            Prestiti = new HashSet<Prestito>();
        }

        public virtual ICollection<Prestito> Prestiti { get; set; }//Virtual Connection
    }
}
