﻿using DevExpress.Utils.CommonDialogs.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Quadrato
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var q = new Quadrato(3.4);
            try
            {
                q.lato = double.Parse(Txtlato.Text);
                if (Txtlato.Text.Trim().Length == 0)
                    throw new Exception("Il lato è obbligatorio!");
                TxtRis.Text = q.ToString();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message,"DATI INSERITI NON CORRETTI!",MessageBoxButton.OK); }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            DialogResult dialog = (DialogResult)MessageBox.Show("Sicuro di voler eliminare i seguenti risultati", "Clear", MessageBoxButton.YesNo);


            if (dialog == DevExpress.Utils.CommonDialogs.Internal.DialogResult.Yes)
            {
                TxtRis.Text = "";
                TxtRis.Text = string.Empty;
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
