﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Quadrato
{
    internal class Quadrato
    {
        public double lato;
        public Quadrato(double l) {
        
        this.lato = l;
        }
        public double GetArea()
        {
            return lato * lato;
        }

        public double GetP()
        {
            return lato * 4;
        }

        public override String ToString()
        {
            return "Lato quadrato:" + lato +" cm\n Area: " +GetArea().ToString() +" cm \n Perimetro:"+ GetP().ToString()+" cm";
        }
    }
}
