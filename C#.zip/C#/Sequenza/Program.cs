﻿using System;
using System.Linq;

namespace Sequenza;
public static class Sequenza
{
	public static void Main()
	{
		int somma;
		Console.WriteLine("x:");
		string x = Console.ReadLine();
		Console.WriteLine("y:");
		string y = Console.ReadLine();
		somma = int.Parse(x) + int.Parse(y);
		Console.WriteLine("somma:" + x + "+" + y + "=" + somma);
		Console.WriteLine($"{y} + {x} = {somma}");//interpolazione;
		float Q;
		int R;
		R = int.Parse(x) % int.Parse(y);
		Q = int.Parse(x) / int.Parse(y);
		Console.WriteLine("Divisione: " + Math.Round(Q, 2) + " resto:" + R);
	}
}

