﻿namespace Solidi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I solidi e il loro peso!");

            //Solido s = null;

            //s = new Solido(); //no istanza di classe astratta

            //calcolare il cubo di alluminio
            //cubo di acciaio
            //sfera di alluminio
            //sfera di rame

            //fonte dei pesi specifici: https://www.oppo.it/tabelle/pesi_specifici.html
            var alluminio = new TipoMateriale { Materiale = Materiale.Alluminio, PesoSpecifico = 2.6 };
            var acciaio = new TipoMateriale { Materiale = Materiale.Acciaio, PesoSpecifico = 7.85 };
            
            var c1 = new Cubo { Lato = 1, Materiale=alluminio };    //obj        
            var c2 = new Cubo { Lato = 1, Materiale=acciaio };
            var sf1 = new Sfera { Raggio = 1, Materiale = acciaio };
            var sf2 = new Sfera { Raggio = 1, Materiale = alluminio };

            Solido[] solidi = { c1, c2, sf1, sf2 };

            foreach(var s in solidi)
                Console.WriteLine(s);

        }
    }
}