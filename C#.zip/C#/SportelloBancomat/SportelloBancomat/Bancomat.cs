﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportelloBancomat
{
    public class Bancomat
    {
        private int banconote20;
        private int banconote50;
        private int banconote10;
        private int bc20;
        private int bc50;
        private int bc10;
        private int totale;
        public Bancomat(int banconote20, int banconote50, int banconote10)
        {
            this.bc20 = 0;
            this.bc50 = 0;
            this.bc10 = 0;
            this.banconote20 = banconote20;
            this.banconote50 = banconote50;
            this.banconote10 = banconote10;
            this.totale = (this.banconote10 * 10) + (this.banconote20 * 20) + (this.banconote50 * 50);
        }
        public int Banconote20 { get { return this.banconote20; } set { this.banconote20 = value; } }
        public int Banconote50 { get { return this.banconote50; } set { this.banconote50 = value; } }
        public int Banconote10 { get { return this.banconote10; } set { this.banconote10 = value; } }

        public bool togli50()
        {
            if (this.banconote50 > 0)
            {
                this.banconote50 -= 1;
                this.totale -= 50;
                return true;
            }
            else { return false; }

        }
        public bool togli20()
        {
            if (this.banconote20 > 0)
            {
                this.banconote20 -= 1;
                this.totale -= 20;
                return true;
            }
            else { return false; }

        }
        public bool togli10()
        {
            if (this.banconote10 > 0)
            {
                this.banconote10 -= 1;
                this.totale -= 10;
                return true;
            }
            else { return false; }

        }
        public String[] prelievo(int n)
        {
            int importo = n;
            int c1 = 0, c2 = 0, c3 = 0;
            String esito = "Fallita";
            String[] str = new String[4];
            if (n > 0)
            {
                this.totale -= n;
                esito = "Riuscita";
                str[0] = esito;
                for (int i = 0; importo != 0; i++)
                {
                    if (n % 50 == 0)
                    {
                        importo -= 50;
                        c1 += 1;
                    }
                    else if (n % 20 == 0)
                    { importo -= 20; c2 += 1; }
                    else { importo -= 10; c3 += 1; }
                       
                }
                this.bc50 += c1;
                this.bc20 += c2;
                this.bc10 += c3;
                str[1] = c1.ToString();
                str[2] = c2.ToString();
                str[3] = c3.ToString();
            }
            return str;

        }

        public bool versamento(int n1,int n2, int n3)
        {
            for (int i = 0; i < n1; i++)
            {
                this.totale += n1 * 10;
            }

            for (int i = 0; i < n2; i++)
            {
                this.totale += n2 * 20;
            }

            for (int i = 0; i < n3; i++)
            {
                this.totale += n3 * 50;
            }
            return true;

        }

        public String resoconto()
        {
            String str = "Sportello Bancomat \n disponibilità \n Totale:" +
                         (this.totale).ToString() + " euro \n" + "Banconote disponibili da 50 euro:" +
                         this.banconote50.ToString() + "\n Banconote disponibili da 20 euro:" + this.banconote20.ToString() +
                         "\n Banconote disponibili da 10 euro: " + this.banconote10.ToString() +
                         "\n Numero di banconote consegnate da 50:" + this.bc50.ToString() +
                         "\n Numero di banconote consegnate da 20:" + this.bc20.ToString() +
                         "\n Numero di banconote consegnate da 10:" + this.bc10.ToString();
                         

            return str;
        }
    }
}
