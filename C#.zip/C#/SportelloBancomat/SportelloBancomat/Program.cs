﻿//      Azzalin Andrea                                     17/04/2023
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportelloBancomat
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String[] p = new string[4];
            var bancomat = new Bancomat(30,40,60);
            Console.WriteLine("Inserire il valore di soldi da prelevare.");
            int n = int.Parse(Console.ReadLine());
            p = bancomat.prelievo(n);
            if (p != null)
            {
                Console.WriteLine("Op Riuscita \n");
                String str = string.Join(",", p);
                Console.WriteLine(str);
            }
            else { Console.WriteLine("Op Fallita \n"); }
            Console.WriteLine(bancomat.resoconto());
        }

    }

}
