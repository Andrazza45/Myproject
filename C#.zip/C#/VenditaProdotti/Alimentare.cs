namespace VenditaProdotti
{
public class Alimentare:VenditaProdotti

{
   
   private String scadenza { get; set; }
   
   public Alimentare(int CodM,int CodC, String Nome, double prezzo, DateTime dob, string[] MateriePrime, String scadenza)
   {
      this.CodM = CodM;
      this.CodC = CodC;
      base.barcode = Conversioni.Conversione(this.CodM,'B')+ Conversioni.Conversione(this.CodC,'B')+Conversioni.Conversione(this.CodM + this.CodC,'B').Substring(6,2);
      this.Nome = Nome;
      this.prezzo = prezzo;
      this.dob = (dob).ToString();
      this.scadenza = (scadenza).ToString();
      this.MateriePrime = MateriePrime;
   }
   public int Get_Cod () { return this.CodC; }
   public String Get_Nome() { return this.Nome; }
   public double Get_Prezzo()  { return this.prezzo; }
   public String Get_dob() { return this.dob; }
   public string Get_scadenza()
   {
      return this.scadenza;
   }
    public string[] Get_MateriePrime()
    {
        return MateriePrime;
    }

   public override String ToString()
   {return "Cod: " +(this.CodM).ToString() +" Nome: "+ this.Nome +" Prezzo: "+(this.prezzo).ToString()+" Data_produzione: "+this.dob +"  Data_scadenza: "+ this.scadenza +" Barcode: "+ base.barcode;}

}
}