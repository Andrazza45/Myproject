namespace VenditaProdotti
{
public class Alimentare:VenditaProdotti

{
   
   private String scadenza { get; set; }
   
   public Alimentare(int Cod, String Nome, double prezzo, DateTime dob, string[] MateriePrime, DateTime scadenza)
   {
      this.Cod = Cod;
      this.Nome = Nome;
      this.prezzo = prezzo;
      this.dob = (dob).ToString();
      this.scadenza = (scadenza).ToString();
      this.MateriePrime = MateriePrime;
   }
   public int Get_Cod () { return this.Cod; }
   public String Get_Nome() { return this.Nome; }
   public double Get_Prezzo()  { return this.prezzo; }
   public String Get_dob() { return this.dob; }
   public string Get_scadenza()
   {
      return this.scadenza;
   }
    public string[] Get_MateriePrime()
    {
        return MateriePrime;
    }

   public override String ToString()
   {return "Cod: " +(this.Cod).ToString() +" Nome: "+ this.Nome +" Prezzo: "+(this.prezzo).ToString()+" Data_produzione: "+this.dob +"  Data_scadenza: "+ this.scadenza;}

}
}