namespace VenditaProdotti
{
    public class Conversioni
    {
    public static String Conversione(int decimale, char tipo)
    {
	String str = "";
	char [] stringa = {'0','0','0','0','0','0','0','0'};
	int j = 0;
    int r = 0;
    switch(tipo)
    {

        case 'O':
				 while(decimale > 0)
				 {
                 for(int i = decimale ; i - 8 >= 0; j++)
                 {
					
                    i -= 8;
                    if(i >= 0)
					{r = i;}
				
				 } 
				 if(decimale - 8 >= 0)
				 {str += r.ToString();}
				 else{str += decimale.ToString();}
				 decimale = j;
				 j = 0;
				 }
				 stringa = str.ToCharArray();
				 Array.Reverse(stringa);
				 str = string.Join("",stringa);
                 break;
        case 'B':

				 while(decimale != 1)
				 {
                 for(int i = decimale ; i > 0; j++)
                 {
					
                    i -= 2;
                    if(i >= 0)
					{r = i;}
				
				 } 
				 
				 str +=r.ToString();
				 decimale -= j;
				 j = 0;
				 }
				 str += (1).ToString();
 				 char [] ss = str.ToCharArray();
				 int k = 0;
				 Array.Reverse(ss);
				 str = new String(ss);
				 for(int i = 8 - ss.Length; i < 8; i ++)
				 {
                  stringa[i] = (char)ss[k];
				  k += 1;
				 }
				 
				 str = string.Join("",stringa);
                 break;

        case 'F':

				 while(decimale > 0)
				 {
                 for(int i = decimale ; i - 16 >= 0; j++)
                 {
					
                    i -= 16;
                    if(i >= 0)
					{r = i;}
				
				 } 
				 if(decimale - 16 >= 0)
				 {str += r.ToString()+'-';}
				 else{str += decimale.ToString();}
				 decimale = j;
				 j = 0;
				 }
				 String [] ex = str.Split('-');
				 str = "";
				 for(int i = 0; i < ex.Length; i++)
				 {
					 switch(ex[i])
					 {
						 case "10":
								 str += 'A';
								 break;
						 case "11":
								 str += 'B';
								 break;
						 case "12":
								 str += 'C';
								 break;
						 case "13":
								 str += 'D';
								 break;
						 case "14":
								 str += 'E';
								 break;
						 case "15":
								 str += 'F';
								 break;
						 default:
								 str += ex[i].ToString();
								 break;
					 }
				 }
			     stringa = str.ToCharArray();
				 Array.Reverse(stringa);
				 str = string.Join("",stringa);
                 break;
		default: return "Tipo di conversione inesistente!";break;
    }
	return str;
}




    }
}