namespace VenditaProdotti
{
    public class Materiale :VenditaProdotti

    {
    private double PercCompP { get; set; }
    public  Materiale(int Cod, String Nome, double prezzo, DateTime dob, string[] MateriePrime,double PercCompP)
    {
    this.Cod = Cod;
    this.Nome = Nome;
    this.prezzo = prezzo;
    this.dob = (dob).ToString();
    this.PercCompP = PercCompP; 
    this.MateriePrime = MateriePrime;
    }
   public int Get_Cod () { return this.Cod; }
   public String Get_Nome() { return this.Nome; }
   public double Get_Prezzo()  { return this.prezzo; }
   public String Get_dob() { return this.dob; }
    public double Get_PercCompP()
    {
        return this.PercCompP;
    }
    public string[] Get_MateriePrime()
    {
        return MateriePrime;
    }
    public override String ToString()
    {return " Codice: "+this.Cod.ToString() +" Nome: "+ this.Nome +" Prezzo: "+this.prezzo.ToString()+" Data_produzione: "+this.dob +" Percentuale_componenti: "+ this.PercCompP.ToString();}
    }
}