namespace VenditaProdotti
{
public class Materia
{
    public enum Materie
    {
        CARTA, PLASTICA, VETRO, ALLUMINIO, LEGNO, SUGHERO, POLIESTERE,POTASSIO,CARBONIO
    }
}
}