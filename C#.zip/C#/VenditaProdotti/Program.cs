﻿using Functions;
namespace VenditaProdotti
{
public class GestioneProdotti

{
List<Alimentare> ProdottiA = new List<Alimentare>(); 
List<Materiale> ProdottiM = new List<Materiale>(); 
 public GestioneProdotti()
 {
 }
 public List<Materiale> GetMateriali()
  {
    return this.ProdottiM;
  }

public List<Alimentare> GetAlimenti()
  {
    return this.ProdottiA;
  }
public void AddAlimento(Alimentare o)
{
    this.ProdottiA.Add(o);
}
public void AddMateriale(Materiale o)
{
    this.ProdottiM.Add(o);
}
public String ElencoProdotti()
{
 String str = "";
  for(int i = 0; i < this.ProdottiA.Count;i++)
 {
    str += (this.ProdottiA[i]).ToString(); 
 }
   for(int i = 0; i < this.ProdottiM.Count;i++)
 {
    str += (this.ProdottiM[i]).ToString(); 
 }
  return str;
}
public String  Prodotti_in_scadenza()
{
 String str = "";
 int day = Convert.ToInt32(((DateTime.Now).ToString()).Split('/')[0]);
 int M = Convert.ToInt32(((DateTime.Now).ToString()).Split('/')[1]);
 int dayS;
 int Ms;
 for(int i = 0; i < this.ProdottiA.Count;i++)
 {  
    int GG;
    Ms = Convert.ToInt32(((this.ProdottiA[i].Get_scadenza()).ToString()).Split('/')[1]);
    dayS = Convert.ToInt32((this.ProdottiA[i].Get_scadenza()).Split('/')[0]); 
    if(Ms - M < 2  && Ms - 1 >=  M )
    {
       int deltaM = Ms - M;
       if(deltaM == 0)
       {
        if(dayS - day < 10)
        {   
            GG = dayS - day;
            str += (this.ProdottiA[i]).ToString()+". Mancano "+GG+" giorni alla scadenza." + "\n";
        }
       }
       else{
        if(dayS + day - 30 < 10)
        {
          GG = dayS + day - 30;
          str += (this.ProdottiA[i]).ToString()+". Mancano "+GG+" giorni alla scadenza."+ "\n";
        }
        }
    }
 }
 return str;
}
public String Materie_Prime()
{
 String str = "";
 for(int i = 0; i < this.ProdottiA.Count;i++)
 {
    str += this.ProdottiA[i].Get_Nome()+": ";
   for(int j = 0; j < this.ProdottiA[i].Get_MateriePrime().Length;j++)
   {
    str += "|"+this.ProdottiA[i].Get_MateriePrime()[j]+"|";
   }
str += "\n";
 }

 for(int i = 0; i < this.ProdottiM.Count;i++)
 {
    str += this.ProdottiM[i].Get_Nome()+": ";
   for(int j = 0; j < this.ProdottiM[i].Get_MateriePrime().Length;j++)
   {
    str += "|"+this.ProdottiM[i].Get_MateriePrime()[j]+"|";
   }
str += "\n";
 }
 return str;
}


    static void Main(string[] args)
    { 
    void Menu()
    {
      for(int i = 0; i <  Enum.GetNames(typeof(Materia.Materie)).Length; i++)
      {
        Console.WriteLine(i.ToString()+"."+(Materia.Materie)i+"\n");
      }   
    }
    GestioneProdotti g = new GestioneProdotti();
    try{
     Console.WriteLine("Gestione Magazzino \n");
	   String str = @"
     1.Elenco Prodotti
     2.Elenco Prodotti in scadenza
     3.Elenco Materie prime 
     4.Aggiungi prodotto
     5.esci ";
    int scelta = 0;
    do
    {
        
     Console.Write(str);
     Console.WriteLine();
     scelta = Convert.ToInt32(Console.ReadLine());
     switch(scelta)
     {
        case 1:
               if(g.GetAlimenti().Count != 0 || g.GetMateriali().Count != 0)
               {
                Console.WriteLine();
                Console.WriteLine("Elenco Prodotti:");
                Console.WriteLine(g.ElencoProdotti());

               }
               else{Console.WriteLine("La lista dei prodotti è vuota");}
               break;
        case 2:
               if(g.GetAlimenti().Count != 0 || g.GetMateriali().Count != 0)
               {
                Console.WriteLine("Elenco Prodotti in scadenza:");
                Console.WriteLine(g.Prodotti_in_scadenza());
               }
               else{Console.WriteLine("La lista dei prodotti è vuota");}
               break;
        case 3:
               if(g.GetAlimenti().Count != 0 || g.GetMateriali().Count != 0)
               {
                Console.WriteLine("Elenco Materie prime:");
                Console.WriteLine(g.Materie_Prime());
                
               }
                else{Console.WriteLine("La lista dei prodotti è vuota");}break;
        
        case 4:
               string tipo = "";
               while(tipo != "M" && tipo != "A" )
               {
               Console.WriteLine("Inserire il tipo di prodotto da inserire(M.Materiale; A.Alimentare)");
               tipo = Console.ReadLine();
               }
               int CodM = 256, CodC = 256;
               String nome, scadenza;
               double prezzo;
               double perMC;
               string [] comp = new string[0];
               DateTime dob; 
               int o = 0;
               Tastiera t = new Tastiera();
               switch (tipo)
               {
                case "A":
                            while(CodM >= 256)
                            {
                            CodM =t.InserisciIntero("<inserire il codice del produttore>");
                            }
                            
                            while(CodC >= 256)
                            {
                            CodC =t.InserisciIntero("<inserire il codice della categoria>");
                            }
                            Console.WriteLine("Inserire il nome del prodotto:");
                            nome =Console.ReadLine();
                            prezzo = t.InserisciDouble("Inserire il prezzo del prodotto:");
                            dob = DateTime.Now;
                            while(o != -1)
                            {
                            Menu();
                            o = Convert.ToInt32(t.InserisciIntero("Inserire il tipo di materiale che desideri utilizzare:(-1 per uscire)"));
                            if(o != -1)
                            {
                            Array.Resize(ref comp, comp.Length + 1);
                            comp[comp.Length - 1] = ((Materia.Materie)o).ToString();
                            }
                            }
                            int meseInc = Convert.ToInt32(dob.ToString().Split('-')[1])+1;
                            string[] dobC =  dob.ToString().Split('-');
                            dobC[1] = meseInc.ToString();
                            scadenza = string.Join("-",dobC);
                            Alimentare pA = new Alimentare(CodM,CodC,nome,prezzo,dob,comp,scadenza);
                            g.AddAlimento(pA);

                        break;
                case "M":
                            CodM =t.InserisciIntero("<inserire il codice del produttore>");
                            CodC =t.InserisciIntero("<inserire il codice della categoria>");
                            Console.WriteLine("Inserire il nome del prodotto:");
                            nome =Console.ReadLine();
                            prezzo = t.InserisciDouble("Inserire il prezzo del prodotto:");
                            dob = DateTime.Now;
                            while(o != -1)
                            {
                            Menu();
                            o = Convert.ToInt32(t.InserisciIntero("Inserire il tipo di materiale che desideri utilizzare:(-1 per uscire)"));
                            if(o != -1)
                            {
                            Array.Resize(ref comp, comp.Length + 1);
                            comp[comp.Length - 1] = ((Materia.Materie)o).ToString();
                            }
                            }
                            perMC = t.InserisciDouble("Inserire percentuale componente Principale:");
                            Materiale pM = new Materiale(CodM,CodC,nome,prezzo,dob,comp,perMC);
                            g.AddMateriale(pM);
                        break;
               }

               break;
        case 5: Console.WriteLine("FINE!");break;
        default:Console.WriteLine("Scelta non valida!");break;
     }
    }
    while(scelta != 5);

        }
         catch (NotImplementedException e) {
                Console.WriteLine("Errore!");
                Console.WriteLine(e.Message);
            }
    }
}
}