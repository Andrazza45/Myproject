﻿namespace VenditaProdotti
{
public class GestioneProdotti

{
 List<Alimentare> Prodotti = new List<Alimentare>(); 
 
 public GestioneProdotti()
 {
 }
public void Add(Alimentare o)
{
    this.Prodotti.Add(o);
}
public String ElencoProdotti()
{
 String str = "";
  for(int i = 0; i < this.Prodotti.Count;i++)
 {
    str += (this.Prodotti[i]).ToString(); 
 }
  return str;
}
public String  Prodotti_in_scadenza()
{
 String str = "";
 int day = Convert.ToInt32(((DateTime.Now).ToString()).Split('/')[0]);
 int M = Convert.ToInt32(((DateTime.Now).ToString()).Split('/')[1]);
 int dayS;
 int Ms;
 for(int i = 0; i < this.Prodotti.Count;i++)
 {  
    int GG;
    Ms = Convert.ToInt32(((this.Prodotti[i].Get_scadenza()).ToString()).Split('/')[1]);
    dayS = Convert.ToInt32((this.Prodotti[i].Get_scadenza()).Split('/')[0]); 
    if(Ms - M < 2  && Ms - 1 >=  M )
    {
       int deltaM = Ms - M;
       if(deltaM == 0)
       {
        if(dayS - day < 10)
        {   
            GG = dayS - day;
            str += (this.Prodotti[i]).ToString()+". Mancano "+GG+" giorni alla scadenza." + "\n";
        }
       }
       else{
        if(dayS + day - 30 < 10)
        {
          GG = dayS + day - 30;
          str += (this.Prodotti[i]).ToString()+". Mancano "+GG+" giorni alla scadenza."+ "\n";
        }
        }
    }
 }
 return str;
}
public String Materie_Prime()
{
 String str = "";
 for(int i = 0; i < this.Prodotti.Count;i++)
 {
    str += this.Prodotti[i].Get_Nome()+": ";
   for(int j = 0; j < this.Prodotti[i].Get_MateriePrime().Length;j++)
   {
    str += "|"+this.Prodotti[i].Get_MateriePrime()[j]+"|";
   }
str += "\n";
 }
 return str;
}


    static void Main(string[] args)
    { 
        try{
        GestioneProdotti g = new GestioneProdotti();
        string [] comp ={(Materia.Materie.CARBONIO).ToString(), (Materia.Materie.POTASSIO).ToString()}; 
        Alimentare p = new Alimentare(1,"banana", 1.0,(DateTime.Now),comp, new DateTime(2023,5,9));
        g.Add(p);
        Console.WriteLine();
        Console.WriteLine("Elenco Prodotti:");
        Console.WriteLine(g.ElencoProdotti());
        Console.WriteLine("Elenco Prodotti in scadenza:");
        Console.WriteLine(g.Prodotti_in_scadenza());
        Console.WriteLine("Elenco Materie prime:");
        Console.WriteLine(g.Materie_Prime());
        }
         catch (NotImplementedException e) {
                Console.WriteLine("Errore!");
                Console.WriteLine(e.Message);
            }
    }
}
}