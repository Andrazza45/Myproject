namespace VenditaProdotti
{
    public abstract class VenditaProdotti

    {
    protected int Cod { get; set; }
    protected String Nome { get; set; }
    protected double prezzo { get; set; }
    protected String dob { get; set; }
    protected string []MateriePrime { get; set;}
    // public VenditaProdotti(int Cod, String Nome, double prezzo, DateTime dob, string[] MateriePrime)
    // {
    // this.Cod = Cod;
    // this.Nome = Nome;
    // this.prezzo = prezzo;
    // this.dob = (dob).ToString();
    // this.MateriePrime = MateriePrime;
    // }

    public override abstract String ToString();
    }
}