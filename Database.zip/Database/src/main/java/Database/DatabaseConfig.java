package _2023_04_04_JDBC;

public class DatabaseConfig {

    protected static final String USER = "administrator";
    protected static final String PASS = "mariadbDocker";
    protected static final String DB_URL = "jdbc:mysql://localhost:7703/farm?createDatabaseIfNotExist=true&autoReconnect=true&useSLL=false&useLegacyDatetimeCode=false";

    // XAMPP
    //protected static final String USER = "root";
    //protected static final String PASS = "";
}
