/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author icts22-24.230
 */
public class Employee {
   private int id;
   private String firstname;
   private String lastname;
   private String dob;
   private String hiredate;
   private String JobDescription;
   private int jobid;
   private float salary;
   

   public Employee(int id, String firstname, String lastname,String dob, String hiredate, String JobDDescription,int jobid, float salary )
   {   
       this.id = id;
       this.firstname = firstname;
       this.lastname = lastname;
       this.dob = dob;
       this.hiredate = hiredate;
       this.JobDescription = JobDescription ;
       this.jobid = jobid;
       this.salary = salary;
   }
   public String Get_firstname()
   {
       return this.firstname;
   }
   public void Set_firstname(String name)
   {
       this.firstname = name;
   }
   public String Get_lastname()
   {
       return this.lastname;
   }
   public void Set_lastname(String name)
   {
       this.lastname = name;
   }
   public String Get_dob()
   {
       return this.dob;
   }
   public void Set_dob(String dob)
   {
       this.dob = dob;
   }
   public String Get_hiredate()
   {
       return this.hiredate;
   }
   public void Set_hiredate(String hiredate)
   {
       this.hiredate = hiredate;
   }
   @Override
   public String toString()
   {
       return this.id + this.firstname + this.lastname+this.dob+this.hiredate +this.JobDescription+ this.jobid+ this.salary ;
   }
   public static void main(String args[]) {
       
   //Stringhe di connessione
   //DatabaseInit db =
   
   Connection conn = new Connection();
   String JobDescription = "Programmatore";
   Statement stat;
   try
   {
       stat = conn.createStatament();
   
   String query = "select e.id, e.firstname, e.lastname , e.dob, e.hire_date,j.id as jobId,j.descrizione as JobDescription, s.salary" +
           "From employment e, job j"+
           "where j.id = e.job"+JobDescription+"='' "+
           "AND e.end_date is null"+
           "order by lastname";
   prepStatament prepstat = prepareStatement(query);
   prepStat.setString(1, JobDescription);
   ResultSet rs =stat.executeQuery(query);
   List<Employee> employees = new ArrayList<>();
   while(rs.next())
   {
       Employee e = new Employee(
       rs.getInt("id"),
       rs.getString("firstname"),
       rs.getString("Lastname"),
       rs.getDate("dob"),
       rs.getDate("hire_date"),
       rs.getString("JobDescription")
       );
    System.out.println(e.toString());
    employees.add(e);
       //commment
   }
   catch(exception e){System.err.println("Errore nell' esecuzione della query"+findEmployeeMaxId+":"+ e.getMessage());}
   }
   }
}
