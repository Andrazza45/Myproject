/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;
import Database.Employee;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

/**
 *
 * @author icts22-24.230
 */
public class UpdateExample //implements Employee
{
    public static void main(String args[]){
    DatabaseInit db = new DatabaseInit();
    Connection conn = db.connecionToDo();//apertuta connessione al db
    String FindEmployeeMaxId = "select Max(id)as id from employee";
    String FindJobIdByDescription = "select id as jobid from job where description = ''";
    String FindJobMaxId = "";
    String InsertEmployeeQuery = "Insert into employee(id, firstname,lastname, dob, hire_date, job)"
    + "VALUES(?,?,?,?,?,?)";
    String insertJob = "Insert into job(id,description) values (?,?)";
    int maxEmployeeId = 0;
    int JobID = 0 ;
    String JobDescription = "Linux admin";
    //insert
    try{
    Employee emp = new Employee(1,"Freancesca","Ferraris",LocalDate.of(1999,6,24).toString(),"22/12/1222","",22,(float)21.21);
    PreparedStatement prepStat = conn.prepareStatement(InsertEmployeeQuery);
    prepStat.setInt(1,maxEmployeeId);
    prepStat.SetString(2,emp.getFirstname());
    prepStat.SetString(3,emp.getLastname());
    prepStat.SetString(4,emp.Date.valueOf(emp.getDob()));
    prepStat.SetString(5,emp.Date.valueOf(emp.gt));
    prepStat.SetString(6,JobID);
    ResultSet rs = prepStat.executeQuery();
    
    while(rs.next())
    {
      System.out.println(rs);
    }
    db.closeConnection(conn);
    }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+FindEmployeeMaxId+":"+ e.getMessage());}
    
    try
    {
    Employee e = new Employee(1,"Freancesca","Ferraris",LocalDate.of(1999,6,24).toString(),"22/12/1222","",22,(float)21.21);
    Statement stat = conn.createStatement();
    }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+FindEmployeeMaxId+":"+ e.getMessage());
    }
    db.closeConnection(conn);
    //select
    try{
    PreparedStatement prepStat = conn.prepareStatement(FindJobIdByDescription);
    prepStat.setString(1, JobDescription);
          Statement stat =  conn.createStatement();
      ResultSet rs1 = stat.executeQuery(FindJobMaxId);
    if(JobID == 8)
    {
    while(rs1.next())
    {
        JobID = rs1.getInt("id");
    }
    }

    System.out.println("Job vale"+ JobID);
    //Update
    PreparedStatement prepStat2 = conn.prepareStatement(insertJob);
    prepStat2.setInt(0, JobID);
    prepStat2.setInt(1, JobID);
    prepStat.setString(2, JobDescription);
    prepStat2.executeUpdate();
    }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+FindEmployeeMaxId+":"+ e.getMessage());
    db.closeConnection(conn);
    }
  } 
}