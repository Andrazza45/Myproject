# Titolo: Most>specific
## author
**Andrea Azzalin**

##exercise requirements:
Indicare la specificità per ogni selettore
##approach to solution 
>0-0-1 
>0-0-1
>1-1-1
>0-0-1
>0-1-0
>0-1-0
>0-1-0
>0-1-1
>0-1-1
>0-1-1
>0-1-0
>1-1-0
>1-0-1
>1-1-1
>0-1-1
