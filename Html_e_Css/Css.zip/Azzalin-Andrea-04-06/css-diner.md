# Titolo: Css-diner
## author
**Andrea Azzalin**

##exercise requirements:
Risolvere tutti i 32 livelli

##approach to solution 
-plate
-bento
-#fancy
-plate apple
-#fancy pickle
-.small
-orange.small
-bento orange.small
-plate, bento 
-*
-plate *
-plate + apple
-bento  ~ pickle
-plate > apple
-orange:first-child
-plate apple:only-child,plate pickle:only-child
-#fancy apple:last-child, pickle:last-child
-plate:nth-child(3)
-bento:nth-last-child(3)
-apple:first-of-type
-plate:nth-of-type(even)
-plate:nth-of-type(2n+3)
-orange:last-of-type,apple:last-of-type
-bento:empty
-apple:not(.small)
-apple[for ="Ethan"],plate[for ="Alice"],bento[for ="Clara"]
-plate[for = "Sarah"], plate[for = "Luke"]
-bento[for = "Vitaly"]
-*[for ^="S" ]
-*[for$= "to"]
-*[for*="obb"]

