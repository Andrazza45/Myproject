localStorage.setItem("id",0);
var id = localStorage.getItem("id");
var sec = 30;

if(localStorage.getItem("r") == "0-0-0")
{
 localStorage.setItem("r","0-0-0");
 localStorage.setItem("medaglie1",null);
 localStorage.setItem("medaglie2",null);
 localStorage.setItem("medaglie3",null);
}
  
class player
{
	constructor(tag)
	{
	this.tag = tag;
	this.avatar = "./immagini";
	this.reward = new Array();
	}
	
	Get_tag()
	{
	 return this.tag;
	}
	
	Set_avatar(avatar)
	{
		this.avatar = avatar;
	}
	
	Set_reward()
	{
		var med;
		switch (this.tag)
		{
			case 'Josh':
			 med = JSON.parse(localStorage.getItem("medaglie1"));
			break;
			case 'Ron':
			 med = JSON.parse(localStorage.getItem("medaglie2"));
			break;
			case 'Denny':
			 med = JSON.parse(localStorage.getItem("medaglie3"));
			break;
		}
		for(var i = 0; i<3;i++)
		{
			if(this.reward[i] != med[i])
			{this.reward[i] = med[i];}
		     
		}
	}
	
	Add_reward(reward,tag)
	{   var ris;
	    var other;
		var myreward = new Array();
		if(localStorage.getItem("r") == "0-0-0")
		 {
		  myreward[0] = null;
		  localStorage.setItem("medaglie1",JSON.stringify(myreward));
		  localStorage.setItem("medaglie2",JSON.stringify(myreward));
		  localStorage.setItem("medaglie3",JSON.stringify(myreward));
		 }
		 var str  = localStorage.getItem("r");
		switch(tag) 
		{
			case 'Josh':
			var med = JSON.parse(localStorage.getItem("medaglie1"));
			other = str.substr(2,3);
			ris = parseInt(str.split("-")[0]);
		
			if(reward != med[ris -1] && reward != med[ris -2] || ris == 0)
			{
			med[ris] = reward;
			localStorage.setItem("medaglie1",JSON.stringify(med));
			localStorage.setItem("r",(ris + 1).toString()+'-'+other);
			}
			else{return -1;}
			break;
			case 'Ron':
			var med = JSON.parse(localStorage.getItem("medaglie2"));
			ris = parseInt(str.split("-")[1]);
			other = str.substr(0,2);
			if(reward != med[ris -1] && reward != med[ris -2] || ris == 0)
			{
			med[ris] = reward;
			localStorage.setItem("medaglie2",JSON.stringify(med));
			
			localStorage.setItem("r",other+(ris + 1).toString());
			other = str.substr(3,2);
			localStorage.setItem("r",localStorage.getItem("r") + other);
			}
			else{return -1;}
			break;
			case 'Denny':
			var med = JSON.parse(localStorage.getItem("medaglie3"));
			other = str.substr(0,4);
			ris = parseInt(str.split("-")[2]);
	
			if(reward != med[ris -1] && reward != med[ris -2] || ris == 0)
			{
			med[ris] = reward;
			localStorage.setItem("medaglie3",JSON.stringify(med));
			
			localStorage.setItem("r",other+'-'+(ris + 1).toString());
			}
			else{return -1;}
			break;
		}
	}
	
	
	Get_str()
	{   
	    var div = document.getElementById('profilo');
		var str = "&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;"+this.tag+'<br/>'+ "<ul id = 'reward'>";
		for(var i = 0; i < (this.reward).length;i ++)
		{	
			if(this.reward[i] != undefined)
			{
			str += '<li>'+'<img id = "med" src = "'+this.reward[i]+'"/>'+'</li>'+'<br/>';
			}
		}
		str += "</ul>"+"<img id = 'avatar' src ='"+this.avatar+"'/>";
		div.style.display="block";
		div.innerHTML = str;
		return str ;
	}
}

class Game
{   
    constructor(nome)
	{
	this.players = new Array();
	this.players = JSON.parse(localStorage.getItem('Players'));//Vengono privati dei loro metodi con stringify(alternativa AddPlayer)
	
	for(var i = 0; i < this.players.length; i++)
	{
		this.players[i].prototype = player.prototype;//intende la classe
	}
	
    this.player = "Ron";
	this.nome = nome;
	this.creatore = "Azzalin Andrea";
	this.obiettivo = "L'obiettivo del gioco è aprire il cancello posizionando la palla sul piedistallo raggiungibile solo seguendo un preciso percorso e uscire dal labirinto.";
	
	this.percorso = new Array();
	this.percorso[0] = new Array();
	this.percorso[1] = new Array();
	this.percorso[2] = new Array();
	this.percorso[3] = new Array();
	this.percorso[4] = new Array();
	this.percorso[5] = new Array();
	this.percorso[6] = new Array();
	this.percorso[7] = new Array();
	this.percorso[8] = new Array();
	
	this.achiv = new Array();
	this.achiv[0] = "./immagini/bronzo.jpg";
	this.achiv[1] = "./immagini/argento.jpg" ;
	this.achiv[2] = "./immagini/oro.jpg";
	
	this.difficolta = "Facile";
	this.diff = new Array();
	this.diff[0] = "Facile";
	this.diff[1] = "Media";
	this.diff[2] = "Difficile";
	this.diff[3] = "Ardua";
	this.color = "blue";
	this.errori = 0;
	this.liv = "";
	var conta = document.getElementById("Livelli").children;
	
	var c = 0;
	for(var i=0; i < conta.length; i++)
	{
		if(conta[i].localName == "br")
		{c += 1;}
	}
	
	this.livelli = document.getElementById("Livelli").children.length - c;
	localStorage.setItem("id",parseInt(id) + 1);
	id = localStorage.getItem("id");
	this.id = parseInt(id);
	
	   for(var i = 0; i < 9; i++)
	   {
		for(var j = 0; j < 9; j++)
		{
	     this.percorso [i][j] = "";
		}
	   }
	}
	
	Get_player()
	{
	 	return this.player;
	}
	Set_player(id)
	{
		var p = document.getElementsByClassName('player');
		var index = id.split("-")[1];
		var name =  p[parseInt(index)].innerHTML;
	 	this.player = name;
	}
    Get_nome()
	{
	 	return this.nome;
	}
	Set_nome(name)
	{
	  this.nome = name;
	}
	Get_creatore()
	{
		return this.creatore;
	}
    Get_id()
	{
		return this.id;
	}
	Get_obiettivo()
	{
		return this.obiettivo;
	}
    Get_achiv(a)
	{	
	    if(a >= 0 && a < (this.achiv).length)
		{return this.achiv[a];}
	    else{return -1;}
	}
	Imposta_difficolta(id)
	{	
	   var indice = id.split("-")[1];
	   switch (parseInt(indice))
	   {
		 case 0:
		 for(var i = 0; i < cells.length; i++)
		 {
		    if (cells[i].innerHTML == "*")
			{
				cells[i].innerHTML = "";
			}
		 }
		 break;
		 
         case 1:
		 this.carica_trappole();
		 break;
         case 2:
         this.carica_trappole();
		 alert("Timer Partito! 30 sec da ora.")
		 var timer = setInterval(function(){
		 sec-=1;
         if (sec < 0)
         {
		  w = true;
		  alert("Hai perso! Tempo scaduto!!");
		  clearInterval(timer);
		  reset();
		  }
		 },1000);
		 break;
         case 3: this.carica_trappole();break; 
	   }
	   this.difficolta = this.diff[parseInt(indice)];
	}
	Get_difficolta()
	{
		return this.difficolta;
	}
	Get_errori(id)
	{
		var e = document.getElementById(id);
		e.innerHTML = this.errori;
		return this.errori;
	}
	errore()
	{
		this.errori += 1;
	}
	corretto()
	{

		this.errori -= 1;
	}
	currentlevel(id)
	{
	 var lv = document.getElementById(id);
	 lv.innerHTML = this.liv;
	 return this.liv;
	}
    Get_liv(liv)
	{
	 this.Mat_clear()
	 this.Carica(liv)
	 this.liv = liv;
	 this.errori = 0;
	 return liv;
	}
    Get_cella(riga, colonna)
	{
	 	return this.percorso[parseInt(riga)][parseInt(colonna)];
	}
	Mat_clear()
	{
	   for(var i = 0; i < 9; i++)
	   {
		for(var j = 0; j < 9; j++)
		{
	     this.percorso [i][j] = "";
		}
	   }		
	}
	carica_trappole()
	{
	 	 switch(this.liv)
		 {
		 case 'Livello1':
		 cells[19].innerHTML = "*";
		 cells[28].innerHTML = "*";
		 cells[37].innerHTML = "*";
		 cells[40].innerHTML = "*";
		 cells[49].innerHTML = "*";
		 cells[58].innerHTML = "*";
		 cells[69].innerHTML = "*";
		 break;
		 case 'Livello2':
		 cells[73].innerHTML = "*";
		 cells[74].innerHTML = "*";
		 cells[75].innerHTML = "*";
		 cells[76].innerHTML = "*";
		 cells[77].innerHTML = "*";
		 cells[78].innerHTML = "*";
		 cells[79].innerHTML = "*";
		 cells[59].innerHTML = "*";
		 cells[51].innerHTML = "*";
		 cells[48].innerHTML = "*";
		 cells[41].innerHTML = "*";
		 cells[33].innerHTML = "*";
		 cells[16].innerHTML = "*";
		 cells[17].innerHTML = "*";
		 
		 break;
		 case 'Livello3':
		 cells[66].innerHTML = "*";
		 cells[67].innerHTML = "*";
		 cells[71].innerHTML = "*";
		 cells[57].innerHTML = "*";
		 cells[58].innerHTML = "*";
		 cells[60].innerHTML = "*";
		 cells[62].innerHTML = "*";
		 cells[42].innerHTML = "*";
		 cells[43].innerHTML = "*";
		 cells[44].innerHTML = "*";
		 cells[10].innerHTML = "*";
		 cells[18].innerHTML = "*";
		 cells[19].innerHTML = "*";
		 cells[22].innerHTML = "*";
		 cells[23].innerHTML = "*";
		 cells[24].innerHTML = "*";	 
		 break;
		 }
	}
	
    Carica(liv)
	   {
		  var dim = document.getElementById("dimostrazione");     
		  switch (liv)
		  {
			case 'Livello1':
			       dim.style.backgroundImage = "url(./immagini/Livello1.png)";
			       for(var i = 0; i < 9; i++)
	               {
					 switch(i)
					 {
					  case 0:
					  for(var j = 2; j < 9; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  break;
					  case 1:
					  for(var j = 2; j < 9; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  break;					  
					  case 2:
					  for(var j = 2; j < 6; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  this.percorso [i][7] = this.color;
					  this.percorso [i][8] = this.color;
					  break;					  
					  case 3:
					  this.percorso [i][0] = this.color;
					  this.percorso [i][2] = this.color;
					  this.percorso [i][5] = this.color;
					  this.percorso [i][7] = this.color;
					  break;						  
					  case 4:
					  this.percorso [i][0] = this.color;
					  this.percorso [i][2] = this.color;
					  this.percorso [i][3] = this.color;
					  this.percorso [i][5] = this.color;
					  this.percorso [i][7] = this.color;
					  break;					  
					  case 5:
					  this.percorso [i][0] = this.color;
					  this.percorso [i][3] = this.color;
					  this.percorso [i][5] = this.color;
					  this.percorso [i][7] = this.color;
					  break;					  
					  case 6:
					  for(var j = 0; j < 4; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  this.percorso [i][5] = this.color;
					  this.percorso [i][7] = this.color;
					  break;					  
					  case 7:
					  for(var j = 0; j < 6; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  this.percorso [i][7] = this.color;
					  break;					  
					  case 8:	 
				      for(var j = 0; j < 8; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  break;					  
					}
				   }
				   	  break;

			case 'Livello2':
			       dim.style.backgroundImage = "url(./immagini/Livello2.png)";
			       for(var i = 0; i < 9; i++)
	               {
					 switch(i)
					 {
					  case 0:
					  for(var j = 0; j < 4; j++)
					  {
						this.percorso [j][i] = this.color;
					  }
					  break;
					  case 1:
					  for(var j = 0; j < 8; j++)
					  {
						this.percorso [j][i] = this.color;
					  }
					  break;					  
					  case 2:
					  for(var j = 0; j < 2; j++)
					  {
						this.percorso [j][i] = this.color;
					  }
					  for(var j = 4; j < 8; j++)
					  {
						this.percorso [j][i] = this.color;
					  }
					  break;					  
					  case 3:

					  for(var j = 0; j < 5; j++)
					  {
						this.percorso [j][i] = this.color;
					  }
					  this.percorso [6][i] = this.color;
					  this.percorso [7][i] = this.color;
					  break;						  
					  case 4:
					  this.percorso [0][i] = this.color;
					  for(var j = 2; j < 8; j++)
					  {
						this.percorso [j][i] = this.color;
					  }
					  break;					  
					  case 5:
					  this.percorso [0][i] = this.color;
					  this.percorso [2][i] = this.color;
					  this.percorso [7][i] = this.color;
					  break;					  
					  case 6:
					  this.percorso [0][i] = this.color;
					  this.percorso [1][i] = this.color;
					  this.percorso [2][i] = this.color;
					  this.percorso [7][i] = this.color;
					  break;					  
					  case 7:
					  for(var j = 2; j < 8; j++)
					  {
						this.percorso [j][i] = this.color;
					  }
					  break;					  
					  case 8:	 
					  this.percorso [2][i] = this.color;
					  this.percorso [3][i] = this.color;
					  this.percorso [4][i] = this.color;
					  break;					  
					}
				   }
					  break;
			
			case 'Livello3':
			       dim.style.backgroundImage = "url(./immagini/Livello3.png)";
			       for(var i = 0; i < 9; i++)
	               {
					 switch(i)
					 {
					  case 0:
					  for(var j = 2; j < 9; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  break;
					  case 1:
					  for(var j = 2; j < 9; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  break;					  
					  case 2:
					  for(var j = 2; j < 4; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  this.percorso [i][7] = this.color;
					  this.percorso [i][8] = this.color;
					  break;					  
					  case 3:
					  this.percorso [i][0] = this.color;
					  this.percorso [i][5] = this.color;
					  this.percorso [i][6] = this.color;
					  this.percorso [i][7] = this.color;
					  break;						  
					  case 4:
					  this.percorso [i][0] = this.color;
					  this.percorso [i][5] = this.color;
					  break;					  
					  case 5:
					  this.percorso [i][0] = this.color;
					  this.percorso [i][1] = this.color;
					  this.percorso [i][2] = this.color;
					  this.percorso [i][5] = this.color;
					  this.percorso [i][6] = this.color;
					  this.percorso [i][7] = this.color;	  
					  break;					  
					  case 6:
					  this.percorso [i][2] = this.color;
					  this.percorso [i][7] = this.color;
					  break;					  
					  case 7:
					  this.percorso [i][2] = this.color;
					  this.percorso [i][6] = this.color;
					  this.percorso [i][7] = this.color;						  
					  break;					  
					  case 8:	 
				      for(var j = 2; j < 7; j++)
					  {
						this.percorso [i][j] = this.color;
					  }
					  break;					  
					}
				   }
				      break;
		  }
	   }
	   Get_color()
	   {
		 return this.color;
	   }
       Set_color(color)
	   {
		   this.color = color;
	   }
       Premia(giocatore,reward)
       {
		 switch(giocatore)
		 {
			case 'Josh':
			this.players[0].prototype.Add_reward(reward, giocatore);
			break;
			case 'Ron':
			this.players[1].prototype.Add_reward(reward,giocatore);
			break;
			case 'Denny':
			this.players[2].prototype.Add_reward(reward, giocatore);
			break;
		 }
	   }
	   
	   Get_str()
	   {
		var dif = "Difficoltà:\n"; 
		for(let i = 0; i < this.diff.length; i++)
		{
		 dif += (i + 1).toString()+". "+this.diff[i] + "\n";
		}
		return "ID: "+this.id+"\n" +"Nome: "+ this.nome+"\n" +"Totale Livelli: "+this.livelli+ "\n" + dif;   
	   }
}



//Varibili del gioco
var p = new Array();
var p1 = new player('Josh');
if(JSON.parse(localStorage.getItem("medaglie1")) != null)
{p1.Set_reward();}
p1.Set_avatar('./immagini/avatar1.png');
p[0] = p1;
var p2 = new player('Ron');
p[1] = p2;
if(JSON.parse(localStorage.getItem("medaglie2")) != null)
{p2.Set_reward();}
p2.Set_avatar('./immagini/avatar2.png');
var p3 = new player('Denny');
p[2] = p3;
if(JSON.parse(localStorage.getItem("medaglie3")) != null)
{p3.Set_reward();}
p3.Set_avatar('./immagini/avatar3.png');

localStorage.setItem("Players",JSON.stringify(p));//Importantissimo

var g = new Game("apri_il_cancello");
//Varibili d'appoggio per la funzione cammino
var isclosed = false;
var sfera = "";
var passi = 0;
var r = false;
var end = false;
var cells;
var prec;
var w = false;
var body  = document.getElementById('body'); 
body.style.cursor = "url(./immagini/_Hallow.cur),auto";


function CreaTab()
{
cells = document.getElementsByTagName('td');
var j = 0;
var k = 0;
sfera = "";
r = false;
end = false;
for (let i = 0; i < cells.length;i ++)
{
	if(i % 9 == 0 && i != 0)
	{
	 j += 1;
	 k = 0;
	}
	cells[i].innerHTML = "";
	cells[i].style.backgroundColor = "gray";
	cells[i].id = i.toString()+'-'+j.toString()+'-'+k.toString();
	k += 1;
}
cells[11].innerHTML = "[x]";
cells[26].innerHTML = "<div class ='porta'></div><div class ='porta'></div>";
cells[27].innerHTML = "°";
}
function trappola(cella,diff)
{   
    switch (diff)
	{
		case 'Media':
	    if(cella.innerHTML == "*")
	    {return 0;}else{return -1;}
	    break;
		case 'Difficile':
	    if(cella.innerHTML == "*")
	    {return 1;}else{return -1;}
	    break;
		case 'Ardua':
		if(cella.innerHTML == "*")
	    {return 2;}else{return -1;}
	    break;
		default: return -1;
	}

}
function cammino(id)
{
 var str = "<div class=\"porta\"></div><div class=\"porta\"></div>";
 var porte = document.getElementsByClassName("porta");
 var cell = document.getElementById(id);
 var riga = id.split("-")[1];
 var colonna = id.split("-")[2];
 var cod = trappola(cell, g.Get_difficolta());
 var richiesti;
 switch(g.currentlevel('currentlevel'))
 {
	case 'Livello1':
	richiesti = 54;
	break;
	case 'Livello2':
	richiesti = 48;
	break;
	case 'Livello3':
	richiesti = 40;
	break;
 }
 switch(cod)
 {
	case 0:
	if(porte[0].style.transform == "rotate(90deg)")
	   {porte[0].style.transform = "rotate(" + 0 + "deg)";porte[1].style.transform = "rotate(" + 0 + "deg)"} 
	break;
	case 1:  sec-= 2; break;
	case 2: w = true; alert("Hai perso!");reset(); break;
	default: break;
 }

 if(cell.style.backgroundColor != g.Get_color())
 {
  cell.style.backgroundColor = g.Get_color();
  passi += 1;
  if(g.Get_cella(riga, colonna) != g.Get_color())
  {g.errore();}
 }
 else{cell.style.backgroundColor = "gray"; passi -= 1; if(g.Get_cella(riga, colonna) != g.Get_color()){g.corretto();}}
 
 
 if (sfera != "°")
 {
 if(cell.innerHTML == "°")
	{
	 sfera = "°";
	 prec = parseInt(id);
	}
 }
 
if (sfera == "°" && cells[parseInt(id)].innerHTML != "°")
{
if(cell.innerHTML == "[x]" && g.Get_errori('ERRORI') == 0 )
{
r = true; 
for(i = 0; i < porte.length;i++)
{porte[i].style.transform = "rotate(" + 90 + "deg)";}
}

if(cell.id == "26-2-8")
{
 end = true;
 }
 
if(cell.innerHTML != "[x]" || cell.innerHTML == "[x]" && g.Get_errori('ERRORI') == 0)
{
	
if (cell.innerHTML != str && cell.innerHTML != "*")
{
cell.innerHTML = "°";
cells[prec].innerHTML = "";
prec = parseInt(id);
}

}
}

if(g.Get_errori('ERRORI') == 0 && r == true && end == true && passi == richiesti)
{
w = true;alert("Hai vinto!!");
var reward = "";
switch(g.Get_difficolta())
{
	case 'Facile':
	reset();
	break;
	case 'Media':
	reward = g.Get_achiv(0);
	break;
	case 'Difficile':
	reward = g.Get_achiv(1);
	break;
	case 'Ardua':
	reward = g.Get_achiv(2);
	break;
}

g.Premia(g.Get_player(),reward);
if(g.Get_player() == 'Josh')
{
	p1.Set_reward();reset();
}
else if(g.Get_player() == 'Ron'){p2.Set_reward();reset();}
else{p3.Set_reward();reset();}

}
}

function toggle(id)
{
	var indice;
	var sx;
	var navbars = document.getElementsByClassName("navbar");
	switch(id)
	{
		case 'scheda1':
		indice = 0;
		sx = '100px';
		break;
		case 'scheda2':
		indice = 1;
		sx = '300px';
		break;
		case 'scheda3':
		indice = 2;
		sx = '500px';
		break;
		case 'scheda5':
		indice = 3;
		sx = '900px';
		break;
	}
    if (navbars[indice].style.display == "" || navbars[indice].style.display == "none")
	{
	 navbars[indice].style.display = "block";
	 navbars[indice].style.position = 'relative';
	 navbars[indice].style.left = sx;
	 navbars[indice].style.top = '70px';
	 navbars[indice].style.width = '100px';
	 navbars[indice].style.zIndex = '100';
     navbars[indice].style.backgroundColor='unset'; 	 
	}
}
function chiudi(id)
{
	var nv = false;
 	switch(id)
	{
		case 'scheda1':
		indice = 0;
		break;
		case 'scheda2':
		indice = 1;
		break;
		case 'scheda3':
		indice = 2;
		break;
		case 'scheda5':
		indice = 3;
		break;
		case 'N0':
		indice = 0;
		nv = true;
		break;
		case 'N1':
		indice = 1;
		nv = true;
		break;
		case 'N2':
		indice = 2;
		nv = true;
		break;
		case 'N3':
		indice = 3;
		nv = true;
		break;
	}
 var navbars = document.getElementsByClassName("navbar");
 for (i = 0; i < 4;i ++)
 {
 if(i != indice)
 {navbars[i].style.display = "none";}
 if(nv == true)
 {
  navbars[indice].style.display = "none";i = 4;
 }
 }

}
function reset()
{
 window.location.reload();
}

function pause()
{
 play = document.getElementById("offuscamento");
 play.style.backgroundColor = 'black';
 play.style.zIndex = '1000';
 play.style.display = 'block';
 window.open("Pausa.html","","width = 700,top = 100,left = 200, height = 400, scrollbars=no, resize = none");
}

function pauseclose(isclosed)
{
  isclosed = true;
  localStorage.setItem("close",isclosed);
  window.close();
}
function resume(isclosed)
{   
    isclosed = localStorage.getItem("close");
    if(isclosed == "true")
	{
	var play = document.getElementById("offuscamento");
	play.style.display = 'none';
	localStorage.clear();
	}
}
function ChangeColor()
{
 var color = "";
 var r = Math.floor(Math.random() * (5 - 0) + 1);
 switch (r)
 {
	 case 1:color = "blue";g.Set_color(color);break;
	 case 2:color = "red";g.Set_color(color);break;
	 case 3:color = "green";g.Set_color(color);break;
	 case 4:color = "purple";g.Set_color(color);break;
	 case 5:color = "orange";g.Set_color(color);break;
 }
 
 for (let i = 0; i < cells.length;i ++)
 {
	if(cells[i].style.backgroundColor != "gray")
	{
	 cells[i].style.backgroundColor = g.Get_color();
	}		
 }
 
 g.Carica(g.currentlevel('currentlevel'));
 return color;
}
function show()
{    
     var div = document.getElementById('profilo');
     var achiv = document.getElementById('Achivement');
	 if(achiv.style.display == 'none')
	 {achiv.style.display = 'block';div.style.top = '-560px';}
      
     else{achiv.style.display = 'none';div.style.top = '20px';}
  
}
function Cancella_salvataggi()
{
	localStorage.setItem("r","0-0-0");
	reset();
}