var scontrino = new Array();
scontrino =['','','','',''];
var count = 1;

var correct = 0;
var full = 0;
var contenitore = "";

var x = 0,y = 0,n = 0,rotINT,rotYINT;

function crea_Scontrino(id,scontrino)
{
var nome = document.getElementById(id.toString()).name;
var div3 = document.getElementById('div3');
var p = new Array();
p = ['','','','',''];
var fiore = "";
var index = 0;
 switch (nome)
 {
	 case 'Chk1':
	 fiore = "Tulipano";
	 index = 0;
	 p = check(nome, index, p, fiore);
	 break;
	 case 'Chk2':
	 fiore = "Rosa";
	 index = 1;
	 p = check(nome, index, p, fiore);
	 break;
	 case 'Chk3':
	 fiore = "Gardenia";
	 index = 2;
	 p = check(nome, index, p, fiore);
	 break;
	 case 'Chk4':
	 fiore = "Stella alpina";
	 index = 3;
	 p = check(nome, index, p, fiore);
	 break;
	 case 'Chk5':
	 fiore = "Garofano";
	 index = 4;
	 p = check(nome, index, p, fiore);
	 break;
 }
 	if(p[index] != "")
	{
	   scontrino[index]  = scontrino[index] + p[index];
	}
	else{scontrino[index]  = p[index];}
	var stampa = "";
	for(i = 0; i < 5;i++)
		stampa = stampa+scontrino[i];
	div3.innerHTML = '<strong>Scontrino:</strong> <br/>'+stampa+'<br/><button id = "BtnTotale" name = "BtnTotale" onclick ="tot = stampa_totale();">Totale</button><div id = "divtot"></div>';
	return scontrino;
}


function check(nome, index, p, fiore)
{
  var checkbox = document.querySelector("input[name="+nome.toString()+"]");
  if (checkbox.checked == true) {
    p[index] = fiore +'<input type="number" id="quantity'+index.toString()+'"'+'value=1 name="quantity"min="1" max="30" onchange="update(id);"><br/>';
  } else {
    p[index] = "";
  }
  return p;
}
function update(id)
{
 let value = document.getElementById(id).value;
 let index = parseInt(id.split("y")[1]);
 scontrino[index] = scontrino[index].split(id)[0]+id+"\" value="+value+" name"+scontrino[index].split(id)[1].split("name")[1]; 
 
}
function stampa_totale()
{
	var tot = 0;
	var qtot = 0;
	var pz1 = document.getElementById('pz1');
	var pz2 = document.getElementById('pz2');
	var pz3 = document.getElementById('pz3');
	var img = document.getElementById('chainsaw');
	var pianta = document.getElementById('pianta');
	var divtot = document.getElementById('divtot');
	var checkbox1 = document.querySelector("input[name="+"Chk1".toString()+"]");
	var checkbox2= document.querySelector("input[name="+"Chk2".toString()+"]");
	var checkbox3= document.querySelector("input[name="+"Chk3".toString()+"]");
	var checkbox4= document.querySelector("input[name="+"Chk4".toString()+"]");
	var checkbox5 = document.querySelector("input[name="+"Chk5".toString()+"]");
	
	if(checkbox1.checked == true)
	{
	var updown1 = document.getElementById("quantity0").value;
	qtot = qtot + parseInt(updown1);
	tot += 1.70 *parseInt(updown1);
	}
	if(checkbox2.checked == true)
	{
	var updown2 = document.getElementById("quantity1").value;
	qtot = qtot + parseInt(updown2);
	tot +=1.50 *parseInt(updown2);
	}
	if(checkbox3.checked == true)
	{
	var updown3 = document.getElementById("quantity2").value;
	qtot = qtot + parseInt(updown3);
	tot +=2.00 *parseInt(updown3);
	}
	if(checkbox4.checked == true)
	{
	var updown4 = document.getElementById("quantity3").value;
	qtot = qtot + parseInt(updown4);
	tot += 11.00*parseInt(updown4);
	}
	if(checkbox5.checked == true)
	{
	var updown5 = document.getElementById("quantity4").value;
	qtot = qtot + parseInt(updown5);
	tot += 3.00*parseInt(updown5);
	}
	if (qtot >= 10 && count == 1)
	{
	  pz1.style.display = 'block';
	  count += 1;
	  divtot.innerHTML = '<span>'+"Il tuo totale è: "+tot.toFixed(2).toString()+"€"+'</span>';
	}
	else if(qtot >= 10 && count == 2)
	{
	  pz2.style.display = 'block';
	  count += 1;
	  divtot.innerHTML = '<span>'+"Il tuo totale è: "+tot.toFixed(2).toString()+"€"+'</span>';
	}
	else if (qtot >= 10 && count == 3)
	{	  
	  pz3.style.display = 'block';
	  count += 1;
	  divtot.innerHTML = '<span>'+"Il tuo totale è: "+tot.toFixed(2).toString()+"€"+'</span>';
	}
	else{
		 
		 if (qtot >= 10 && count == 4)
		 {
		 img.style.display = 'block';
		 img.style.animationName = 'taglia';
		 img.style.right = '190px';
		 
		 pianta.style.animationName = 'sx';
		 setTimeout(function(){
		 pianta.style.left = '860px';
		 pianta.style.animationName = 'dx';
		 },1000);
		 setTimeout(function(){
		 pianta.style.left = '860px';
		 pianta.style.animationName = 'sx';
		 },2000);
		 setTimeout(function(){
		 pianta.style.left = '860px';
		 pianta.style.animationName = 'dx';
		 },3000);
		 setTimeout(function(){
		 pianta.style.left = '860px';
		 pianta.style.animationName = 'sx';
		 },4000);
		 setTimeout(function(){
		 pianta.style.left = '860px';
		 pianta.style.animationName = 'dx';
		 },5000);
		 setTimeout(function(){
		 pianta.style.top = '1100px';
		 },6000);
		 setTimeout(function(){
		 abbatti();
		 },7000);
		 setTimeout(function(){
		 img.style.animationName = 'ritirata';
		 },8000);
		 setTimeout(function(){ 
		 img.style.display = 'none';
		 pz1.style.display = 'none';
		 pz2.style.display = 'none';
		 pz3.style.display = 'none';
		 pianta.style.transform="rotate(" + 360 + "deg)";
         pianta.style.OTransform="rotate(" + 360 + "deg)";
         pianta.style.MozTransform="rotate(" + 360 + "deg)";
		 },10000);
		 count = 1;
		 tot = tot - (tot * 0.15);
		 divtot.innerHTML = '<span>'+"Il tuo totale scontato è: "+tot.toFixed(2).toString()+"€"+'</span>';
		 }
		 else{divtot.innerHTML = '<span>'+"Il tuo totale è: "+tot.toFixed(2).toString()+"€"+'</span>';}
		}
	
}


function mostra_Ricetta()
{	
	var div4 = document.getElementById('div4');
	var p = "";
	switch (document.getElementById("Cmb1").value)
	{
	 case 'Gardenia': 
	 p = "Nothing";
	 break;
	 case 'Garofano':
	 p ="<span class=\"ingr\">Ravioli di Garofani e Viole</span> <br/>\
	 In una ciotola, unire la ricotta con il parmigiano e i petali dei garofani e delle viole e qualche fiore essiccato. Mescolare con delicatezza.Impastare la farina e le uova fino ad ottenere un panetto liscio e compatto. Lasciare riposare per 30 minuti. Stendere sottilmente e formare dei ravioli quadrati inserendo l’impasto della ricotta con i fiori.\
	Lessare il cavolo viola, scolarlo e frullarlo in un cutter. Poi saltarlo in padella con il burro. Porre un fondo di crema di cavolo viola su ogni piatto. Cuocere i ravioli in abbondante acqua salata, scolarli e sistemarli sulle fondine. Sistemare su ogni piatto delle foglie di nasturzio, fiori essiccati e petali freschi.";
	break;
	 case 'Rosa':p ="Nothing";
	 break;
	 case 'Stella alpina':
	 p ="<span class=\"ingr\">Liquore fior di roccia</span> <br/>\
	Per iniziare questo liquore fior di roccia, prendiamo i fiori, mi raccomando, fateli prima seccare qualche giorno e metteteli a macerare nella grappa del Trentino per un mese ed il miele. Metteteli in un vaso con chiusura ermetica.\
	Agitate di tanto in tanto.\
	Questo passaggio, conferirà il colore al liquore e sapore.\
	Successivamente, fate uno sciroppo, in un pentolino, mettete acqua e zucchero, portate ad ebollizione e togliete subito dal fuoco, non appena lo zucchero sarà sciolto. Fate freddare completamente.\
	Unite la grappa aromatizzata alle stelle alpine e lo sciroppo, mescolate bene e filtrate. Mentre filtrate, schiacciate, con un mestolo di legno i fiori.\
	Imbottigliate e fate riposare due mesi prima di servirlo.";
	break;
 	case 'Tulipano':
	p = "<span class=\"ingr\">Macedonia al Tulipano</span> <br/>\
	Ingredienti:\
	1 piccolo melone, 2/3 grosse fette d'anguria, 2 arance, 2 limoni, 2 cucchiai di vodka o di kirsch, 5 cucchiaiate di zucchero, 10 amaretti, 1 manciata di petali di tulipano.\
	Sbucciate un piccolo melone maturo, eliminate i semi e i filamenti e, con l'apposito utensile, ricavate dalla polpa tante palline.\
	Mettetele in una capace ciotola.\
	Dalle fette d'anguria, sbucciate e liberate dei semi, ricavate, con lo stesso utensile, altrettante palline e aggiungetele al melone.\
	Spremete due arance e due limoni, versate sulla frutta il succo ottenuto e aggiungete due cucchiai di vodka o di kirsch; unite 5 cucchiaiate di zucchero.\
	Sbriciolate una decina di amaretti e aggiungeteli alla macedonia; mescolate bene e quindi riponete la ciotola in frigorifero per qualche ora.\
	Al momento di portare in tavola cospargete la macedonia con una manciata di petali di tulipano di colore assortito.";
	break;
    } 
	 div4.innerHTML = '<p id ="ricetta">' + p +'</p>';
	 
}

function mostra_Utensile()
{
	var immagine = document.getElementById('immagine');
	var prez = document.getElementById('prezzo');
	var p = "";
	var prezzo = "";
	switch (document.getElementById("Cmb2").value)
	{
		case 'Aratro':
		     p = "<img id =\"img1\" src = \"01-variables/immagini/Aratro.jpg\">";
			 prezzo = "743.00€";
			 break;
		case 'Innaffiatoio':
			 p = "<img id =\"img1\" src = \"01-variables/immagini/Innaffiatoio.jpg\">";
			 prezzo = "11.00€";
			 break;
		case 'Pala':
			 p = "<img id =\"img1\" src = \"01-variables/immagini/pala.jpg\">";
			 prezzo = "7.00€";
			 break;
		case 'Paletta':
			 p = "<img id =\"img1\" src = \"01-variables/immagini/paletta.jpg\">";
			 prezzo = "3.00€";
			 break;
		case 'Vanga':
			 p = "<img id =\"img1\" src = \"01-variables/immagini/vanga.jpg\">";
			 prezzo = "6.00€";
			 break;
		case 'Piccone':
			 p = "<img id =\"img1\" src = \"01-variables/immagini/piccone.jpg\">";
			 prezzo = "13.00€";
			 break;
		case 'Rastrello':
		     p = "<img id =\"img1\" src = \"01-variables/immagini/rastrello.jpg\">";
			 prezzo = "9.00€";
			 break;
		case 'Soffiatore':
			 p = "<img id =\"img1\" src = \"01-variables/immagini/soffiatore.jpg\">";
			 prezzo = "51.00€";
			 break;
		case 'Zappa':
			 p = "<img id =\"img1\" src = \"01-variables/immagini/zappa.jpg\">";
			 prezzo = "8.00€";
			 break;
	}
	immagine.innerHTML = p +'</img>';
	prez.innerHTML = prezzo;
}

function toggle(id)
{
 if (id == "option")
  {
	if(document.getElementById("Aikido").style.display == "none")
	{
		document.getElementById("Aikido").style.display = "block";
	}else{document.getElementById("Aikido").style.display = "none";}
  }
   else
   {
	if(document.getElementById("navbar").style.display == "none")
	{
	   document.getElementById("navbar").style.display = "block";
	   document.getElementById("testo").style.top = "870px";
	   document.getElementById("articles").style.top = "1550px";
	}else{
	document.getElementById("navbar").style.display = "none";
	document.getElementById("testo").style.top = "870px";
	}
   }
}


function closef()
{
 document.getElementById("foot").style.display = "none";
 
}
function menuclose()
{
	document.getElementById("navbar").style.display = "none";
	document.getElementById("testo").style.top = "870px";
}
function apri(id)
{
  switch (id)
  {
  case 'Facebook':
	    window.open("https://www.facebook.com/andrea.azzalin.7","height=400,width=400");
		break;
  case 'Instagram':
	    window.open("https://instagram.com/andrea.4398?igshid=ZDdkNTZiNTM=","height=400,width=400");
		break;
  case 'Telegram':
	    window.open("https://t.me/+vF394aWPMtgxZGM0","height=400,width=400");
	    break;
  }

}

  function iframe()
  {
	var iframe = document.getElementById('iframe');
	var articles = document.getElementById('articles');
    iframe.style.top ="-330px";
	articles.style.top = "1550px";
	iframe.innerHTML = '<iframe id = "iframe" src = "Vasi.html"></iframe>';
  }


function allowDrop(ev) {
	ev.preventDefault();
  }
  
  function drag(ev) {
	ev.dataTransfer.setData("text", ev.target.id);
    contenitore = ev.srcElement.parentElement.className;
  }
  
  function drop(ev) {
	var coriandoli = document.getElementById('Coriandoli');
	ev.preventDefault();
	var div = document.getElementById('tasselli');
	var data = ev.dataTransfer.getData("text");
    var obj = document.getElementById(data);
	obj.style.left = "0px";

	if (ev.target.lastChild == null)
	{
	ev.target.appendChild(obj);
	target = ev.target;
	if (contenitore != "drop-zone")
	{
	full += 1;
	}
	correct = Verifica(correct, target, data, full);
	}
	else{
		if (contenitore == "drop-zone")
		{
		full -= 1;
		}
		lastCh = ev.target.lastChild;
		lastCh.style.left ="160px";
		ev.target.replaceChild(obj,ev.target.lastChild);
		div.appendChild(lastCh);
		correct = Verifica(correct, target, data, full);
		
	}
	if (full == 9)
    {
	if(correct == 9)
		{
	  setTimeout(function(){
	  coriandoli.style.display = 'block';
	  },20);
	  setTimeout(function(){
      alert("Hai Indovinato!!"); window.location.reload();
	  },10000);
		}
   else{alert("Hai Perso!!"); window.location.reload();}
	}
  }
  function verifica(correct, target, data, full,contenitore)
  {
    var div = document.getElementById('tasselli');
	if (target.id == 'campo0' && data == "1")
	{correct += 1;}
	else if (target.id == 'campo1' && data == "2")
	{correct += 1;}
	else if (target.id == 'campo2' && data == "6")
	{correct += 1;}
	else if (target.id == 'campo3' && data == "4")
	{correct += 1;}
	else if (target.id == 'campo4' && data == "3")
	{correct += 1;}
	else if (target.id == 'campo5' && data == "5")
	{correct += 1;}
	else if (target.id == 'campo6' && data == "7")
	{correct += 1;}
	else if (target.id == 'campo7' && data == "9")
	{correct += 1;}
	else if(target.id == 'campo8' && data == "8")
	{correct += 1;}
	else{if (correct != 0 && contenitore == "drop-zone"){correct -= 1;}}
    return correct;
  }

  function checkConnection() {
	var astronauta = document.getElementById('form');
		astronauta.action = "404.html";
}

function nascondi(id)
{	

	var div = document.getElementById('div1');
	if (id == "scheda1")
	{
	 div1.style.bottom = '22px';
	 p = '<h1>MOJITO</h1><p>  Per preparare il mojito iniziate versando in un bicchiere da long drink (tumbler alto) le foglie di menta e lo zucchero di canna; servendovi di un pestello schiacciatele contro il lato del bicchiere così da sprigionare l’aroma della menta. Aggiungete il succo di lime (circa 1/5 della bibita) e pestate ancora per qualche secondo, poi riempite il bicchiere di ghiaccio (a cubetti o tritato), aggiungete il rum, l’angostura e in ultimo uno spruzzo di acqua gassata (o soda); mescolate in modo circolare e servite decorando con un rametto di menta.Ecco pronto il vostro mojito, salute!</p><br/>';
	 p+='<h1>Smoothie di cetriolo, ananas e menta</h1>'
     +'<p>Lo smoothie di cetriolo, ananas e menta rappresenta una combinazione gustativa equilibrata e nutriente, ampiamente apprezzata per le sue proprietà rinfrescanti e idratanti. Il cetriolo, originario delle regioni dell’Himalaya, è stato storicamente utilizzato per le sue proprietà idratanti e rinfrescanti. Contiene molta acqua, vitamine e minerali, diventando un ingrediente chiave per bevande rinfrescanti e salutari. L’ananas, nativo delle regioni tropicali dell’America del Sud, è noto per il suo sapore dolce e la ricchezza di enzimi come la bromelina, che favorisce la digestione.'
     +'La menta, una pianta aromatica diffusa in molte parti del mondo, invece, offre una nota fresca e tonificante, offrendo proprietà digestive e antisettiche. La combinazione di questi tre ingredienti nel frullato idrante di cui oggi proponiamo la ricetta crea una bevanda fresca e rivitalizzante. Pertanto, la preparazione risulta particolarmente apprezzata nelle giornate calde o come bevanda rigenerante dopo l’attività fisica. Inoltre, la sua realizzazione è semplice e veloce. Gli ingredienti vengono frullati insieme fino a ottenere una consistenza liscia e omogenea. A seconda delle preferenze personali, è possibile aggiungere altri ingredienti come yogurt, latte di cocco o miele per variarne la consistenza e il sapore. Regalatevi una pausa di gusto e di relax e preparate con noi lo smoothie di cetriolo, ananas e menta. Vi conquisterà!</p>';
	 
	}
	else{ div1.style.bottom = '0px'; p = '<a href ="https://www.google.it">google</a>';}
	div.innerHTML = p;
}
function reload()
{
	window.location.reload();
}

function rotateIMG()
{
x = document.getElementsByClassName("img1");
clearInterval(rotINT);
rotINT=setInterval("startRotate()",10);
}

function startRotate()
{
 n = n + 1;
for (i = 0; i < 5; i++) 
{
x[i].style.transform="rotate(" + n + "deg)";
x[i].style.OTransform="rotate(" + n + "deg)";
x[i].style.MozTransform="rotate(" + n + "deg)";
}
if (n==180 || n==360)
{
clearInterval(rotINT)
if (n==360){n=0;}
}
}

function abbatti()
{
 clearInterval(rotINT);
 rotINT=setInterval("abbattimento()",10);
}
function abbattimento()
{
	n = n - 1;
	pianta.style.transform="rotate(" + n + "deg)";
    pianta.style.OTransform="rotate(" + n + "deg)";
    pianta.style.MozTransform="rotate(" + n + "deg)";
	if (n== -90)
	{
	clearInterval(rotINT)
	if (n== -90){n=0}
	}
}

function comparsa()
{
	var div = document.getElementById('Golf');
	var articles = document.getElementById('articles');
	var iframe = document.getElementById('iframe');
	var serre = document.getElementById('Serre');
	var slidebar = document.getElementsByClassName('slidecontainer');
	var img = document.getElementById('chainsaw');
	var pianta = document.getElementById('pianta');
	articles.style.top = '1550px';
	slidebar[0].style.top = '0px';
	div.style.display = 'block'; 
	serre.style.display = 'none'; 
	iframe.style.top = '-40px';
	img.style.top = '740px';
	pianta.style.top = '960px';
	div.innerHTML ='<p style = "position:absolute; float:left; top:400px; width: 50px;"class = "box" onclick = "chiusura();">></p><div id = "Golfista"></div><div id = "pallina" onclick = "lancia();">';
    div.style.animationName = 'comparsa';
	
}
function lancia()
{
	var div = document.getElementById('Golf');
	var golfista = document.getElementById('Golfista');
	var pallina = document.getElementById('pallina');
	golfista.style.display = "block";
	setTimeout(function(){
	golfista.style.display = "none";},2500);
	setTimeout(function(){
	pallina.style.animationDelay = '1s';
	pallina.style.animationName = 'sinistra';
	setTimeout(function(){
	pallina.style.right = '445px';
    },1000);
	},90);
	
	setTimeout(function(){
    // pallina.style.animationDelay = '0.1s';
	// pallina.style.animationName = 'su';
	pallina.style.right = '445px';
	pallina.style.top = '600px';
	for(let i = 0; i < 90;i++)
	{
	 setTimeout(function(){
	 
	 if(i<10)
	 {
	  pallina.style.top= parseInt(pallina.style.top.split('px')[0])-10+"px";
	 }
	 
	 if(i%2==0)
	 {
	   pallina.style.right= parseInt(pallina.style.right.split('px')[0])-10+"px";
	 }else{
	  pallina.style.top= parseInt(pallina.style.top.split('px')[0])-10+"px";
	 }
	 },i*50);
	} 
	},1450);
    // setTimeout(function(){
	// pallina.style.animationDelay = '0.1s';
	// pallina.style.animationName = 'destra';
	// setTimeout(function(){
	// pallina.style.left = '0px';
	// },1000);
	// },3900);
	setTimeout(function(){
	pallina.style.animationDelay = '1s';
	pallina.style.animationName = 'giù';
    },5000);

	setTimeout(function(){
	pallina.style.top = '562px';
	pallina.style.left = '-11px';
	pallina.style.width = '30px';
	pallina.style.height = '30px';
	pallina.style.backgroundImage = "url(./01-variables/js/pallinamini.png)";
	pallina.onclick = null;
    },6700);
}

function chiusura()
{
	var div = document.getElementById('Golf');
	var articles = document.getElementById('articles');
	var iframe = document.getElementById('iframe');
	var serre = document.getElementById('Serre');
	var slidebar = document.getElementsByClassName('slidecontainer');
	var section = document.getElementById('articles');
	var img = document.getElementById('chainsaw');
	var pianta = document.getElementById('pianta');
	articles.style.top = '900px';
	div.style.display = 'none'; 
	serre.style.display = 'block'; 
	section.style.bottom = '1000px';
	img.style.top = '0px';
	pianta.style.top = '200px';
	iframe.style.top = "-390px";
	slidebar[0].style.top = "-300px";
	div.style.animationName = '';
	
}

