function play(id)
{
	canzone = document.getElementById('Canzone');
	switch(id)
	{
	case 'Luffy':
	canzone.title = "Luffy";
	canzone.src = "../04-variables/audio/Luffy.ogg";
	break;
	case 'Sabo':
	canzone.title = "Sabo";
    canzone.src = "../04-variables/audio/Sabo.ogg"; 
	break;
	case 'Zoro':
	canzone.title = "Zoro";
	canzone.src = "../04-variables/audio/Zoro.ogg";
	break;
	case 'Brook':
	canzone.title = "Brook";
	canzone.src = "../04-variables/audio/Brook.ogg"; 
	break;
	}
}
function Visualizza()
{
	canzone = document.getElementById('Canzone');
	acc = document.getElementById('accompagnamento');
	scena = document.getElementById('scena');
	artista = document.getElementById('artista');
	div = document.getElementById('Spartito');
	var titolo = canzone.title;
		switch(titolo)
	{
	case 'Luffy':
	div.style.width = '950px';
	div.style.backgroundImage = "Url(../04-variables/immagini/LuffyS.png)";
	div.innerHTML = '';
	acc.innerHTML = '<p>Piano</p>';
	scena.innerHTML = '<p>Colosseum di Desserosa</p>';
	artista.innerHTML = '<p>Raùl Jimènez</p>';	
	break;
	case 'Sabo':
    div.innerHTML = '<p style = "left:35px; position:relative;">Nothing</p>';
	div.style.backgroundImage = '';
	acc.innerHTML = '<p>Violino, batteria, Piano, Sax</p>';
	scena.innerHTML = '<p>Isola Fuschia</p>';
	artista.innerHTML = '<p>?</p>';	
	
	break;
	case 'Zoro':
	div.style.width = '1600px';
	div.style.backgroundImage = '';
	div.innerHTML = '<img id = "S" src = "../04-variables/immagini/zoroS.png"><img id = "S" style = "position:absolute;"src = "../04-variables/immagini/zoroS1.png"><img id = "S" style = "position:relative;" src = "../04-variables/immagini/zoroS2.png">';
	acc.innerHTML = '<p>Piano, flauto traverso,Shakuhachi, legnetti, Tamburo, Viola </p>';
	scena.innerHTML = '<p>Nei pressi di Ebisu, Isola di Wano</p>';
	artista.innerHTML = '<p>Shirò Hamaguchi</p>';
	break;
	case 'Brook':
	div.style.width = '1600px';
    div.style.backgroundImage = '';
	div.innerHTML = '<img id = "S" src = "../04-variables/immagini/BrookS.png"><img id = "S" style = "position:absolute;" src = "../04-variables/immagini/BrookS1.png"><img id = "S" style = "position:relative;" src = "../04-variables/immagini/BrookS2.png">';
	acc.innerHTML = '<p>Piano, flauto dolce, Batteria, Violino, Tromba</p>';
	scena.innerHTML = '<p>Isola degli uomini Pesce</p>';
	artista.innerHTML = '<p>Lippi91</p>';
	break;
	}
}
