function estrai()
{
 var n;
 div = document.getElementById('Dado');
 n = Math.floor(Math.random()*(6-0)+1);
 switch(n)
 {
 case 1:
 div.style.backgroundImage ="url(Dado1.png)";
 break;
 case 2:
 div.style.backgroundImage ="url(Dado2.png)";
 break;
 case 3:
 div.style.backgroundImage ="url(Dado3.png)";
 break;
 case 4:
 div.style.backgroundImage ="url(Dado4.png)";
 break;
 case 5:
 div.style.backgroundImage ="url(Dado5.png)";
 break;
 case 6:
 div.style.backgroundImage ="url(Dado6.png)";
 break;
 }

}