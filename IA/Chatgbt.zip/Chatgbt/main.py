name = ""
if name == " main ":
   print('hello')

from getpass import getpass
import os
import openai


OPENAI_API_KEY = getpass()
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY
openai.api_key = os.getenv('OPENAI_API_KEY')
   

def prompt_1(user_content: str = "",
             temperature: int = 1,
             top_p: int = 1) -> str:
  messages = [
    {
      "role": "user",
      "content": f"{user_content}"
    }
  ]
  response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=messages,
    temperature=temperature,
    top_p=top_p,
  )

  return response.choices[0].message.content.strip()


     

display(prompt_1("le rose sono"), 0, 0)