package Database;

public class DatabaseConfig {

    protected static final String USER = "root";
    protected static final String PASS = "";
    protected static final String DB_URL = "jdbc:mysql://localhost:3306/its_2023_frase?serverTimezone=America/New_York ";

    // XAMPP
    //protected static final String USER = "root";
    //protected static final String PASS = "";
}
