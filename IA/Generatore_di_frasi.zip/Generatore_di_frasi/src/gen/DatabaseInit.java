package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseInit {

    // CREAZIONE CONNESSIONE AL DB
    public Connection connectionToDb(){
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DatabaseConfig.DB_URL, DatabaseConfig.USER, DatabaseConfig.PASS);
            conn.setAutoCommit(true);
            System.out.println("CONNESSIONE AL DB RIUSCITA");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("ERRORE DI CONNESSIONE: "+e.getMessage());
        }
        return conn;
    }

    // CHIUSURA CONNESSIONE AL DB
    public void closeConnection(Connection conn){
        try {
            conn.close();
            System.out.println("CHIUSURA CONNESSIONE RIUSCITA");
        } catch (SQLException e) {
            System.err.println("ERRORE DI CHIUSURA DI CONNESSIONE: "+e.getMessage());
        }
    }
}
