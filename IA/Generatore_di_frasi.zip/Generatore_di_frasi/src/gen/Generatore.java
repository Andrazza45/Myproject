/*package gen;*/
import Database.DatabaseInit;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;



public class Generatore
{
 private String frase = "";
public Generatore() throws IOException
{nuova_frase();}
public void nuova_frase() throws IOException
{
String sostantivo = "";
String sostantivo1 = "";
String predicato = "";
DatabaseInit db = new DatabaseInit();
Connection conn = db.connectionToDb();//apertuta connessione al db
    for(int i = 1; i <= 3; i++)
    {
    Random rand = new Random();
    int n = rand.nextInt(15) + 1;
    String query1 = " Select p.sostantivo from parola p where p.id ="+n;
    String query2 = " Select v.predicato from verbo v where v.id ="+n;
    switch (i)
    {
        case 1:

    try{

        Statement stat = conn.createStatement();
        ResultSet rs = stat.executeQuery(query1);
         while(rs.next())
        {
         sostantivo = rs.getString("sostantivo");
        }

        }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+":"+ e.getMessage());}
        System.out.println('\n');
        break;
        case 2:
    try{

        Statement stat = conn.createStatement();
        ResultSet rs = stat.executeQuery(query2);
         while(rs.next())
        {
        predicato = rs.getString("predicato");
        }

        }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+":"+ e.getMessage());}
        System.out.println('\n');
        break;
        case 3:
    try{

        Statement stat = conn.createStatement();
        ResultSet rs = stat.executeQuery(query1);
         while(rs.next())
        {
         sostantivo1 = rs.getString("sostantivo");
        }
         if(sostantivo == sostantivo1)
         {
             i -=1;
         }
        }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+":"+ e.getMessage());}
        System.out.println('\n');
    break;
    }

    }

    String art1 = "";
    String art2 = "";
    if(sostantivo.toCharArray()[sostantivo.length() -1] == 'a')
    {
        art1 = "una";
    }
    else{art1 = "un";}
    if(sostantivo1.toCharArray()[sostantivo.length() -1] == 'a')
    {
        art2 = "una";
    }
    else{art2 = "un";}
    this.frase = art1+sostantivo + predicato +art2+ sostantivo1+"\n";

    String queryfrase ="select * from frase f";
    boolean presente = false;
    try{
        String fc = "";
        Statement stat = conn.createStatement();
        ResultSet rs = stat.executeQuery(queryfrase);
         while(rs.next())
        {
         String soggetto = rs.getString("soggetto");
         String verbo = rs.getString("verbo");
         String co = rs.getString("complemento_oggetto");
         String art3 = "";
         String art4 = "";
    if(soggetto.toCharArray()[soggetto.length() -1] == 'a')
    {
        art3 = "una";
    }
    else{art3 = "un";}
    if(co.toCharArray()[co.length() -1] == 'a')
    {
        art4 = "una";
    }
    else{art4 = "un";}
    fc = art3+soggetto + verbo +art4+ co+"\n";
         if(fc == this.frase)
         {
             presente = true;
         }
        }

        }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+":"+ e.getMessage());}
        System.out.println('\n');
    if (presente == false)
    {
    this.frase = leggiStringaDaFile("file.txt")+art1+sostantivo + predicato +art2+ sostantivo1+"\n";
    this.FileWriter(this.frase);
    String insertFrase = "Insert into frase(soggetto,verbo,complemento_oggetto) values ("+ sostantivo+","+predicato+","+sostantivo1+")";
    }
    else{System.out.println("Frase gi� presente nel db!");}


}









    public static String leggiStringaDaFile(String percorsoFile) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(percorsoFile));
        StringBuilder stringBuilder = new StringBuilder();
        String line = null;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
        }
        reader.close();
        return stringBuilder.toString();
    }



public void FileWriter(String frase)
{

  try {
     FileWriter fileWriter = new FileWriter("file.txt"); // Inserisci il percorso e il nome del file nel quale vuoi salvare la stringa
     fileWriter.write(frase);
     fileWriter.close();
     System.out.println("La stringa � stata salvata con successo nel file.");
  } catch (IOException e) {
     System.out.println("Si � verificato un errore durante il salvataggio della stringa nel file.");
     e.printStackTrace();
  }
}
}


