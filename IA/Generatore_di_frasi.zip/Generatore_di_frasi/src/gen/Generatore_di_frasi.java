import gen.Generatore;
import java.util.Scanner;
public class Generatore_di_frasi {

	public static void main(String[] args) {
            Scanner tastiera = new Scanner (System.in);
            String a = "";
            while(a != "NO")
            {
                a = tastiera.nextLine();
                if(a == "SI")
                {
                   Generatore frase = new Generatore();
                }
            }
	}

}
