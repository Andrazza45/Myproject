import chromadb;
if name == " main ":
   print("test.db")
   client  = chromadb.PersistentClient(path = "/db")
   collection = client.create_collection(name = "test collection")
   collection.add(
   documents =["this is a document", "this is another document"],
   id = ["id1", "id2"]
   )








   #load the document and slpit it into chars:


   loader = TextLoader("../file.txt")
   document = loader.load()
   text_spitter =CharacterToUpLetter(char_size = 19, char_overlap = 8)
   #docs = text_spitter.

   #load it into chroma
   db = Chroma.from_documentations(document,embedding_functions)

   #query it
   query = "Quali sono le specifiche di un formato txt?"
   docs = db.similiraty_search(query)

   #print results
   print("===================")
   print(docs[0].page_content)

import os
from dotenv import load_dotenv

# class Collection:

PROMPT SYSTEM = /
'''
CONNESSIONE,
runtime chat
'''
#costruire un contesto su argomento di cui si vuole parlare 
