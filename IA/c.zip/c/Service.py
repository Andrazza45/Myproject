from fastapi import FastAPI
from cycle_db import DocumentType
import os
class CycleData(Basedata):
   tipo:str
   nome:str

PDF_type = "PDF"
Json_type ="JSON" 

app = FastAPI()
#JSON
# json =
def encode_cycle_data(type:str)
    if type == PDF_type:
        return DocumentType.PDF
        
apt_get("*/Items__object/{item.id}")
async def root(item_id):
       return("item":item_id)




# apt_post()



