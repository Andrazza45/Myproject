import os

from dotenv import load_dotenv
load_dotenv(dotenv_path=os.getcwd() + "./openai.env")


from langchain.utilities import SQLDatabase
from langchain.llms import OpenAI
from langchain.agents import create_sql_agent
from langchain.agents.agent_toolkits import SQLDatabaseToolkit
from langchain.agents.agent_types import AgentType



if __name__ == "__main__":

    # get current directory
    crnt_dir = os.path.dirname(__file__)


    # importa un database di esempio di sqlite
    # https://www.sqlitetutorial.net/sqlite-sample-database/
    db_path = "sqlite:///" + crnt_dir + "/db/chinook.db"
    db = SQLDatabase.from_uri(db_path)
    for d in db.get_usable_table_names():
        print(d)


    # inizializa OpenaAi
    llm = OpenAI(temperature=0, verbose=True)


    # inizializzazione Agent
    agent_executor = create_sql_agent(
        llm=llm,
        toolkit=SQLDatabaseToolkit(db=db, llm=llm),
        verbose=True,
        agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    )


    # testa una query sul database
    resp_1 = agent_executor.run(
    "Dimmi quanti impiegati sono presenti nel database"
    )
    
    print(resp_1)

# import os

# from dotenv import load_dotenv
# load_dotenv(dotenv_path=os.getcwd() + "./openai.env")

# from langchain.llms import OpenAI
# from langchain.chat_models import ChatOpenAI
# from langchain.agents.agent_types import AgentType

# from langchain_experimental.agents.agent_toolkits import create_csv_agent


# CSV_SRC = "/data/Arrivi-nei-campeggi-e-villaggi-turistici-in-italia-per-regione.csv"

# if __name__ == "__main__":

#     # get current directory
#     crnt_dir = os.path.dirname(__file__)

#     # inizializza agente
#     agent = create_csv_agent(
#         ChatOpenAI(temperature=0, model="gpt-3.5-turbo"),
#         crnt_dir  + CSV_SRC,
#         verbose=True,
#         agent_type=AgentType.OPENAI_FUNCTIONS,
#     )

#     # query
#     print(agent.run("Elenca tutti i dati relativi al 2008"))