import os
from dotenv import load_dotenv
load_dotenv(dotenv_path=os.getcwd() + "/openai.env")



# DB
import chromadb as cdb
from langchain.vectorstores import Chroma
# load & split
from langchain.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter
# openai embeddings
from langchain.embeddings import OpenAIEmbeddings
# model language
from langchain.llms import OpenAI

# "chain"
# da questi moduli, è possibile  recuperare le funzionalità
# di langchain per gestire le varie tipologie di prompt e chat
from langchain.chains import ConversationalRetrievalChain
from langchain.chat_models import ChatOpenAI



# ===================
# VECTOR DATABASE
# ===================
MONOPATTINI_NAME = "monopattini"
class Vdb:
    def __init__(self,
                text_path: str,
                db_path: str) -> None:

        loader = TextLoader(text_path)
        text_splitter = CharacterTextSplitter(chunk_size=1000, 
                                              chunk_overlap=10)
        documents = text_splitter.split_documents(loader.load())

        self.vectordb = Chroma.from_documents(documents,
                                              embedding=OpenAIEmbeddings(),
                                              persist_directory=db_path)
        self.vectordb.persist()
        pass


    def as_retriever(self):
        return self.vectordb.as_retriever(search_kwargs={'k': 5})


# ========
# MAIN
# ========
if __name__ == "__main__":
    crnt_dir = os.path.dirname(__file__)

    db = Vdb(text_path=crnt_dir + "/docs/monopattini.txt", 
            db_path=crnt_dir + "/db" )

    chain = ConversationalRetrievalChain.from_llm(
        ChatOpenAI(temperature=0.9, model_name="gpt-3.5-turbo"),
        db.as_retriever(),
        return_source_documents=True,
        verbose=False
    )

    chat_history = []
    run: bool = True
    while run == True:
        query = input('User: ')
        if query == "exit" or query == "quit" or query == "q":
            print('Exiting')
            run = False
        else:
            result = chain({'question': query, 'chat_history': chat_history})
            print('Ai: ' + result['answer'])
            chat_history.append((query, result['answer']))
