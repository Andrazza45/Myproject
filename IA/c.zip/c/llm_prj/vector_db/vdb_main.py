import os

# CHROMADB
import chromadb as cdb


# LANGCHAIN
# "vectorsores"
# modulo per la gestione dei collegamenti ai diversi database vettoriali
from langchain.vectorstores import Chroma

# "document_loaders"
#  modulo per il caricamento di documenti di diverso formato e provenienza.
from langchain.document_loaders import TextLoader

# "text_splitter"
# questo modulo contiene diversi approcci alla divisione di un documento
# in parti di testo più piccole.
from langchain.text_splitter import RecursiveCharacterTextSplitter

# "embeddings
# modulo che raccoglie le modalità di accesso alle funzionalità
# di embedding messa a disposizione da vari progetti (OpenAi ad esempio).
# In qusto caso viene richiamato 
from langchain.embeddings import SentenceTransformerEmbeddings

# visualizza  un vectordb
from chromaviz import visualize_collection


# ========
# MAIN
# ========
if __name__ == "__main__":


    # --------------------------------------------------------
    # Restituisce il path corretto alla directory corrente
    # --------------------------------------------------------
    crnt_dir = os.path.dirname(__file__)
    print(crnt_dir)

    # [1] DB 
    # -------------------------------------------------------------------------
    # Restituisce un riferimento (client) al database su disco.
    # Se il db non esiste, lo crea
    # IMPORTANTE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    
    # UTILIZZA UN SOLO CLIENT ALLA VOLTA
    # Avere molti client che caricano e salvano sullo stesso percorso 
    # può causare comportamenti strani,inclusa la cancellazione dei dati. 
    # Come pratica generale: 
    # crea un client Chroma una volta nella tua applicazione
    # e passalo in giro invece di creare molti client
    # -------------------------------------------------------------------------

    client = cdb.PersistentClient(crnt_dir + "/db")

    # crea un oggetto collecition attraverso il quale è possibile
    # gestire i documenti vettorializzati 
    collection_name = "doc_zip"
    collection = client.get_or_create_collection(collection_name)
    visualize_collection(collection)

    # [2] LOAD - SPLIT - SAVE 
    # -----------------------------------------------------------------------------------------------
    # Dividere un documento molto lungo in pezzi più piccoli è utile sia a bypassare
    # i limite di token computabili da un llm, sia per ottimizzare il loavoro della rente neurale
    # chunk_size: parametro che definise il numero di token per partizione
    # chunk_overlap: tra due partizioni determina una zona di sovrapposizione di n-token
    # -----------------------------------------------------------------------------------------------
    
    loader = TextLoader(crnt_dir + "/docs/doc_zip.txt")    
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=10)
    splits = text_splitter.split_documents(loader.load())
    
    # salva nel database vettoriale tutti i pezzi di testo
    # assegna ad ogni porzione un id incrementale a partire dal nome
    # della collection (es. doc_zip_0)
    docs = []
    ids = []
    counter = 0
    for s in splits:
        docs.append(s.page_content)
        ids.append(collection_name + "_" + str(counter))
        counter += 1
    collection.add(documents=docs, ids=ids)
    

    # [3] EMBEDDING
    # -------------------------------------------------------------------------
    # genera un processo di trasformazione da testo a vettori.
    # -------------------------------------------------------------------------
    embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")


    # [4] DB RETREIVER
    # -------------------------------------------------------------------------
    # collega il database vettoriale al resto delle funzionalità di langchain
    # -------------------------------------------------------------------------
    zip_db = Chroma(client=client,
                    collection_name=collection_name,
                    embedding_function=embeddings)
    
    # [4] SEMANTIC SEARCH
    # -------------------------------------------------------------------------
    # recupara nel testo le parti più "vicine" alla nostra richiesta
    # -------------------------------------------------------------------------
    query = "quali svantaggi potrei incontrare nell'uso di un file zip?"
    response = zip_db.similarity_search(query)
    print("================RISPOSTA==================")
    print(response)