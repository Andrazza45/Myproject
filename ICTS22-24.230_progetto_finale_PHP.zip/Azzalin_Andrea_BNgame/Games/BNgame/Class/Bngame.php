<head>
<script type="text/javascript">
window.addEventListener('load',function(){
window.location.hash = 'no-back';
});
</script>

<?php
require '../../../Services/_composer/vendor/autoload.php';
session_start();

$database='battle_ship';
$collection1='player';
$collection2='session';
$collection3='layout';
$collection4='coords';

if(isset($_GET['init']))
{
$player = $_GET['init'];
}
if(isset($_SESSION["Msg"]))
{
$email =trim(explode('homepage',$_SESSION["Msg"],20)[1]);
}else{header("location: ../../../Login/Login.php");}
?>
<style>
body
{
 background-image:url(../Files/img/sfondo.jpg);
 height:900px;
}
#msg
{
position:relative;
height:1200px;
width:1200px;
top:600px;
display:none;
border:2px solid;
z-index:200;
margin: 0 auto;
}

#container
{
 position:relative;
 width:620px;
 height:1280px;
 background-color:#03C03C;
 // background-image:url(../Files/img/mare.gif);
 border:3px solid;
 left:600px;
 bottom:750px;
 perspective:1000px;
 transform:translate(100px,-350px) rotatex(60deg) rotate(28deg);
}

#numbers,#alphabet
{
 position:relative;
 display:block;
}
#numbers
{
 height:20px;
 width:490px;
 left:50px;
 top:40px;
}
#alphabet
{
 height:490px;
 width:0px;
 left:20px;
 top:26px;
}
#numbers li,#alphabet li
{
 position:relative;
 display:inline-block;
 font-family:fantasy;
 font-size:19px;
 border:1px solid red;
 background-color:#CCCCFF;
 text-align:center;
 color:#FF0000;
 text-shadow:2px 2px 2px #000;
}
#numbers li
{
 height:18px;
 width:46px;
 bottom:2px;
 left:-35px;
}
#alphabet li
{
 height:46px;
 width:22px;
 font-weight:bold;
 writing-mode:vertical-rl; 
 text-orientation:upright;
 left:-35px;
 bottom:-3px;
}

.Pz
{
width:42px;
height:45px;
display:inline-block;
	
}

.Nave
{
 perspective:1000px;
 transform:rotatex(60deg) rotate(28deg);	
 position:relative;
 left:20px;
}

.Porto *:not(#banchina)
{
 top:10px;
}


.Nave .Pz:first-of-type
{
 border-radius:4px;
}
.Nave .Pz:last-of-type
{
 border-radius:4px;
}

#banchina
{
	background-color:brown;
	width:40px;
	height:700px;
	position:absolute;
	left:200px;
	bottom:50px;
	border:1px solid;
	font-family:calibri;
	font-size:28px;
	font-weight:bold;
	align-items:center;
	writing-mode:vertical-rl; 
    text-orientation:upright;
	color:blue;	
	text-align:center;
}

.Porto
{
	position:relative;
	width:250px;
	height:800px;
	left:100px;
	top:-10px;
    display:block;
    border:3px solid;
	border-radius:4px;
    background-color:#003399;	
}
.Comandi
{
 width:40px;
 height:40px;
}
.Gira
{
 position:relative;
 width:20px;
 height:20px;
 bottom:20px;
 border:1px solid;
 color:red;
}
.Gradi
{
 position:relative;
 top:-50px;
 width:20px;
 height:20px;
 z-index:100;
}
.Campo
{
 width:500px;
 height:500px;
 top:80px;
 position:absolute;
 left:55px;
 border:3px solid black;
 z-index:100;
}

.Campo th
{
	position:absolute;
	width:490px;
	text-align: center;
	background-color:#FFD700;
}

.Campo:last-of-type
{
	top:660px;
}

.Campo tr .Acqua
{
 background-color:blue;
 width:42px;
 height:45px;
}
#coords
{
 position:relative;
 width:200px;
 height:200px;
 border:2px solid;
 background-color:yellow;
 display:none;
 bottom:1620px;
 left:1550px;
 text-align:center;
 font-size:32px;
 font-family:roboto;
 line-height:210px;
}
</style>
</head>
<body>
<?php 
//creazione classe gioco

// class Battle_ship
// {
// private $player;
// private $email;
// private $database;
// private $collection1;
// private $collection2;
// private $collection3;
// private $collection4;

//require '../../Services/_composer/vendor/autoload.php';
//private $manager = new MongoDB\Driver\Manager("mongodb+srv://andre:Biblioteca09@cluster0.56nbas3.mongodb.net/");
//private $man = new MongoDB\Client("mongodb+srv://andre:Biblioteca09@cluster0.56nbas3.mongodb.net/");
	
// public function Battle_ship()
// {	
//    $this->player = $_GET['init'];
//    if(isset($_SESSION["Msg"]))
//	  {
//    $this->email = $email =trim(explode('homepage',$_SESSION["Msg"],20)[1]);
//    $this->$database='battle_ship';
//    $this->$collection1='player';
//    $this->$collection2='session';
//    $this->$collection3='layout';
//    $this->$collection4='coords';
//    }
// }

// private function generateRandomCode()
// {
	// $characters = array_merge(range('a', 'z'), range(0, 9));
    // $cod = '';
    
    // for ($i = 0; $i < 8; $i++) {
        // $cod .= $characters[rand(0,36)];
	// }
	// return $cod;

// }

// private function loadGame()
// {
    // $alphabet =['a','b','c','d','e','f','g','h','i','j'];
	// $str = "";
	// $str.='<audio hidden id = "song" controls autoplay loop src="../Files/Sound/PiratiDeiCaraibi.ogg"></audio>'.
	// '<div id = "msg"></div><div class="Porto">';
    // for ($i = 1; $i <= 3; $i++){
        // $str.= '<div class="Nave" ondragstart="setSail(event);" draggable="true";>';
        // for ($j = 1; $j <= $i+1; $j++){
			// if($j == $i+1)
			// {
			 // $img = "background-image:url(../Files/Pieces/prua.jpg);";
			// }
			// else{
				// switch($j)
				// {
					// case 1:
					// $img ="background-image:url(../Files/Pieces/poppa.jpg);";
					// break;
					// case 2:
					// $img ="background-image:url(../Files/Pieces/ponte.jpg);";
					// break;
					// case 3:
					// $img = "background-image:url(../Files/Pieces/vela.jpg);";
					// break;
				// }
			// }
            // $piece = '<div class="Pz" id="'.$alphabet[$i-1].($j-1).'" style="'.$img.'"onmousedown="getElement(id);"></div>';
            // $str.= $piece;
        // }
        // $str.= '</div><div class ="Comandi"><input type ="button" class = "Gira" style="background-image:url(../Files/img/ruota90.png)"onclick="turn('.($i-1).');"><p class="Gradi"></p></div>';
    // }
    // $str.='<div id="banchina">Porto</div></div>';
	
    // $str.= '<div id="container">';
	
	
	// $str.= '<ol id="numbers">';
	// for($i=1;$i<=10;$i++)
	// {
	 // $str.='<li>'.$i.'</li>';
	// }
	// $str.='</ol>';
	
	// $str.= '<ol id="alphabet">';
	// for($i=0;$i<10;$i++)
	// {
	 // $str.='<li>'.chr(ord($alphabet[$i])-32).'</li>';
	// }
	// $str.='</ol>';
	
	// $str.= '<table class ="Campo">';
	// $str.='<th>Campo Avversario</th>';
    // for ($i = 0; $i < 10; $i++){
        // $str.= '<tr>';
        // for ($j = 0; $j < 10; $j++){
            // $str.= '<td class="Acqua"></td>';
        // }
        // $str.= '</tr>';
    // }
    // $str.= '</table>';
	
	
	 
    // $str.= '<table class ="Campo" ondragover="handle(data,event);">';
	// $str.='<th>Mio campo</th>';
    // for ($i = 0; $i < 10; $i++){
        // $str.= '<tr>';
        // for ($j = 0; $j < 10; $j++){
            // $str.= '<td class="Acqua" id="'.$i.'-'.$j.'" ondrop="anchor(event);" ondragover="allowDrop(event);"></td>';
        // }
        // $str.= '</tr>';
    // }
    // $str.= '</table>';
    // $str.= '</div>';
	// $str.='<div id="coords"></div>';
	// return $str;	
// }

// function find_error($giocatore)
// {
// $errore = 0;
// $player = intval($player);
// if($player %2 == 0)
// {
  // if($email == $giocatore->email and intval($giocatore->id) % 2 == 0)
  // {
   // $errore = -1;
  // }
  
// }else{
 // if($email == $giocatore->email and intval($giocatore->id) % 2 != 0)
 // {
  // $errore = -1;
 // }
// }
 // return $errore;
// }

//miss prepare e save_player
// }

function generateRandomCode() {
    $characters = array_merge(range('a', 'z'), range(0, 9));
    $cod = '';
    
    for($i=0;$i < 8;$i++) {
    $cod .= $characters[rand(0,36)];
	}
	return $cod;
}

function loadGame() {
	$alphabet =['a','b','c','d','e','f','g','h','i','j'];
	$str = "";
	$str.='<audio hidden id = "song" controls autoplay loop src="../Files/Sound/PiratiDeiCaraibi.ogg"></audio>'.
	'<div id = "msg"></div><div class="Porto">';
	$shipsxtype=4;
    for ($i = 1; $i <= 3; $i++){
		for($k=0;$k<$shipsxtype;$k++)
		{
		$s=0;
		switch($i)
		{
		 case 1:$s=0;break;
		 case 2:$s=4;break;
		 case 3:$s=7;break;
		}
        $str.= '<div class="Nave" slot="'.($k+$s).'" ondragstart="setSail(event);" draggable="true";>';
        for ($j = 1; $j <= $i+1; $j++){
			if($j == $i+1)
			{
			 $img = "background-image:url(../Files/Pieces/prua.jpg);";
			}
			else{
				switch($j)
				{
					case 1:
					$img ="background-image:url(../Files/Pieces/poppa.jpg);";
					break;
					case 2:
					$img ="background-image:url(../Files/Pieces/ponte.jpg);";
					break;
					case 3:
					$img = "background-image:url(../Files/Pieces/vela.jpg);";
					break;
				}
			}
            $piece = '<div class="Pz" slot="'.($s+$k).'" id="'.$alphabet[$i-1].($j-1).'" style="'.$img.'"onmousedown="getElement(id);"></div>';
            $str.= $piece;
        }
        $str.= '</div><div class ="Comandi"><input type ="button" class = "Gira" style="background-image:url(../Files/img/ruota90.png)"onclick="turn('.($s+$k).');"><p class="Gradi"></p></div>';
		}
		$shipsxtype--;
    }
    $str.='<div id="banchina">Porto</div></div>';
	
    $str.= '<div id="container">';
	
	
	$str.= '<ol id="numbers">';
	for($i=1;$i<=10;$i++)
	{
	 $str.='<li>'.$i.'</li>';
	}
	$str.='</ol>';
	
	$str.= '<ol id="alphabet">';
	for($i=0;$i<10;$i++)
	{
	 $str.='<li>'.chr(ord($alphabet[$i])-32).'</li>';
	}
	$str.='</ol>';
	
	$str.= '<table class ="Campo">';
	$str.='<th>Campo Avversario</th>';
    for ($i = 0; $i < 10; $i++){
        $str.= '<tr>';
        for ($j = 0; $j < 10; $j++){
            $str.= '<td class="Acqua"></td>';
        }
        $str.= '</tr>';
    }
    $str.= '</table>';
	
	
	 
    $str.= '<table class ="Campo" ondragover="handle(data,event);">';
	$str.='<th>Mio campo</th>';
    for ($i = 0; $i < 10; $i++){
        $str.= '<tr>';
        for ($j = 0; $j < 10; $j++){
            $str.= '<td class="Acqua" id="'.$i.'-'.$j.'" ondrop="anchor(event);" ondragover="allowDrop(event);"></td>';
        }
        $str.= '</tr>';
    }
    $str.= '</table>';
    $str.= '</div>';
	$str.='<div id="coords"></div>';
	return $str;
}

function Save_player($manager,$document,$p,$update)
{
 global $database;
 global $collection1;
 global $collection2;
 global $collection3;
 global $collection4;
 global $player;
 global $email;
 $str ="";
 switch($p)
 {
  case 0:
  $cod = generateRandomCode();
  $str.='<p style = "color:red;">'.$email.'</p><br/>';
  $codsess = '<p style="color:red;font-size:22px;">Session: '.$cod.'</p>';
  $str.= $codsess;				
  $str.=loadGame();
				
  $data = [
  [
  'email' => $email,
  'id' => $player,
  'stat' => $p,
  'active' => true
  ],
  [
  'email' => $email,
  'id' => $player,
  'session' => $cod,
  'Idate' => date("Y-m-d"),
  'Fdate' => null,
  'score' => 0,
  'lucky' => null
  ],
  [
  'email' => $email,
  'id' => $player,
  'page' => '<p style = "color:red;" id="email">'.$email.'</p>'.'<br/>'.$codsess.loadGame(),
  'ready'=>false,
  'ships' =>[[2,2,2,2],[3,3,3],[4,4]],
  'lucky' => null
  ]  
  ];
  //inserisco nel documento un pò per volta
  if($update == false)
  {
	$document = new MongoDB\Driver\BulkWrite();
	$document->insert($data[0]);
	$manager->executeBulkWrite($database . '.' . $collection1,$document);
	unset($document);
  }
  $document = new MongoDB\Driver\BulkWrite();
  $document->insert($data[1]);
  $manager->executeBulkWrite($database . '.' . $collection2,$document);
  unset($document);
  $document = new MongoDB\Driver\BulkWrite();
  $document->insert($data[2]);
  $manager->executeBulkWrite($database . '.' . $collection3,$document);
  break;
  case 1:
  $str.='<p style = "color:red;">'.$email.'</p>';
  //Voglio la sessione!
  $options = [
  "projection" => ['id' => 0,'dataI'=>0,'dataF'=>0,'score'=>0]
  ];
  $origin = intval($player);
  $origin--;
  $origin = strval($origin);
				
  $query = ["id" => $origin];
  $res = $manager->executeQuery($database.'.'.$collection2, new MongoDB\Driver\Query($query,$options));
				
  foreach ($res as $document){
  $row = $document;
  }
  $codsess = '<p style="color:red;font-size:22px;">Session: '.$row->session.'</p>';
  $str.=$codsess;
  $str.=loadGame();
						
  $data = [
  [
  'email' => $email,
  'id' => $player,
  'stat' => $p,
  'active' => true
  ],
  [
  'email' => $email,
  'id' => $player,
  'session' =>$row->session,
  'Idate' => date("Y-m-d"),
  'Fdate' => null,
  'score' => 0,
  'lucky' => null
  ],
  [
  'id' => $player,
  'session' => $row->session,
  'page' => '<p style = "color:red;" id="email">'.$email.'</p>'.'<br/>'.$codsess.'</br/>'.loadGame(),
  'ready'=>false,
  'ships' =>[[2,2,2,2],[3,3,3],[4,4]],
  'lucky' => null
  ]	
  ];
  if($update == false)
  {
	$document = new MongoDB\Driver\BulkWrite();
	$document->insert($data[0]);
	$manager->executeBulkWrite($database . '.' . $collection1,$document);
	unset($document);
  }
  $document = new MongoDB\Driver\BulkWrite();
  $document->insert($data[1]);
  $manager->executeBulkWrite($database . '.' . $collection2,$document);
  unset($document);
  $document = new MongoDB\Driver\BulkWrite();
  $document->insert($data[2]);
  $manager->executeBulkWrite($database . '.' . $collection3,$document);
  break;
  }
  return $str;
}

function find_error($giocatore,$player,$email)
{
$errore = 0;
$player = intval($player);
if($player %2 == 0)
{
  if($email == $giocatore->email and intval($giocatore->id) % 2 == 0)
  {
   $errore = -1;
  }
  
}else{
 if($email == $giocatore->email and intval($giocatore->id) % 2 != 0)
 {
  $errore = -1;
 }
}
 return $errore;
}

function prepare($player,$email)
{
	
	//connessione con mongodb
    $manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");
	$man = new MongoDB\Client("mongodb://localhost:27017");
	global $database;
    global $collection1;
    global $collection2;
    global $collection3;
	global $collection4;
	// Crea un documento BSON
	$document = new MongoDB\Driver\BulkWrite();
	
	//Script di creazione del db di gioco	
	$databases = $man->listDatabases();
	$databaseExists = false;

    foreach ($databases as $databaseInfo) {
    if ($databaseInfo['name'] === $database) {
        $databaseExists = true;
        break;
    }
	}
	if($databaseExists == false)
	{
	$command = new MongoDB\Driver\Command(['find'=>'BN']);
    $manager->executeCommand($database,$command);
	$db = $man->selectDatabase($database);
	$db->createCollection($collection1);
	$db->createCollection($collection2);
	$db->createCollection($collection3);
	$db->createCollection($collection4);
	echo "<br/>Database creato con successo!";
	}
	
	$row = null;

	$giocatore = null;
	
	$options = [
    "projection" => ['stat'=> 0,'active'=>0],
	'limit' => 1
    ];
	
	$query = ['email' => $email];
	
	$res = $manager->executeQuery($database.'.'.$collection1, new MongoDB\Driver\Query($query,$options));
	
	foreach ($res as $document){
    $row = $document;
	$giocatore = $row;
    }
	
	//Ricerca del player per inserirlo in db
	$row = null;
	$options = [
    "projection" => ['email'=>0,'stat'=> 0,'active'=>0]
    ];
	
	$query = ['id' => $player];
	
	$res = $manager->executeQuery($database.'.'.$collection1, new MongoDB\Driver\Query($query,$options));
	
	foreach ($res as $document){
    $row = $document;
    }

	if($row != null)
	{
	  
	  $options = [
      "projection" => ['email'=>0,'id' => 0,'ready'=>0,'ships'=>0]
      ];
	  $query = ['id' => $player];
	  
	  $res = $manager->executeQuery($database.'.'.$collection3, new MongoDB\Driver\Query($query,$options));
    
      foreach ($res as $document){
      $row = $document;
      }

   	  echo $row->page;

	  
	  $options = [
      "projection" => ['email'=>0,'id' => 0,'Idate'=>0,'Fdate'=>0]
      ];
	  $query = ['id' => $player, 'Fdate' => null];
	  
   	  $res = $manager->executeQuery($database.'.'.$collection2, new MongoDB\Driver\Query($query,$options));
	  
	  foreach ($res as $document){
      $row = $document;
      }
	  
	  $_SESSION['score'.$player] = $row->score;
	  
	  $options = [
	  "projection" => ['email'=> 0,'id'=> 0,'active'=>0]
	  ];
	  $query = ['id' => strval($player)];
	  $res = $manager->executeQuery($database.'.'.$collection1, new MongoDB\Driver\Query($query,$options));
	  foreach ($res as $document){
	  $row = $document;
	  }
	  $_SESSION['G'.strval($player)] = $row->stat;
	  
	  $collection = $man->selectCollection($database,$collection1);
      $collection->updateOne(
      ['id' =>$player],
      ['$set' => ['active'=>true]]
      );
	  
	}
	else//è NULL
	{
	 $p =intval($player) % 2;
	 if($giocatore != null)//Controlla se ci sono tracce del giocatore sul db
	 {
		if($giocatore->id != "-1")
		{
			$error =find_error($giocatore,$player,$email);
			
			if($error != -1)//Il limite di partite che il giocatore può aprire è stato superato
			{
		     echo Save_player($manager,$document,$p,false);
			}else{
			header('location: ../Functions/Save.php?path=../Files/Players.txt&error=e&add=-1&player='.$player);
			
			}
		}else{
		$mydb='battle_ship';
        $mycollect='player';
		$collection = $man->selectCollection($mydb,$mycollect);
		$collection->updateOne(
		['id' =>'-1'],
		['$set' => ['id' =>$player,'stat'=>$p]]
		);
		echo Save_player($manager,$document,$p,true);//fa update player e crea le tabelle che servono al gioco
	   }
	 }else{echo Save_player($manager,$document,$p,false);}//altrimenti lo inserisce
    }
}
?>
</body>
