<?php
require '../../../Services/_composer/vendor/autoload.php';
class Saving
{
public $mydb;
public $mycollect;
private $manager;
private $man;
private $player;
 public function Saving()
{
  $this->mydb ='battle_ship';
  $this->mycollect=['player','layout','session'];
  $this->manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");
  $this->man = new MongoDB\Client("mongodb://localhost:27017");
  if (!is_dir('../Files')){
  mkdir('../Files');
 }
if(!file_exists('../Files/Players.txt'))
{
file_put_contents('../Files/Players.txt','[]');
}
if(file_get_contents('../Files/Players.txt')=='')
{
file_put_contents('../Files/Players.txt','[]');
}
if(!file_exists('../Files/Ships.txt'))
{
file_put_contents('../Files/Ships.txt',"0-0");
}

if(isset($_GET['player']))
{
 $this->player = $_GET['player']; 	
}	 
}

public function getMan()
{
return $this->man;
}
public function getPlayer()
{
return $this->player;
}

private function addFirst($arr,$p)
{
 $index = -1;
 for($j=0;$j<count($arr);$j++)
 {
   if($arr[$j] == -1)
	{
	 $index=$j;
	 $j= count($arr);
	}
 }
 return $index;
}
private function remove($arr,$p)
{
 for($j=0;$j<count($arr);$j++)
 {
   if($arr[$j] == $p)
	{
	 $index=$j;
	 $j= count($arr);
	}
 }
 return $index;
}



public function savePage()
{
$html = file_get_contents('php://input'); 
$database = 'battle_ship';
$mycollect='layout';
$collection = $this->man->selectCollection($database,$mycollect);
$bulk = $collection->updateOne(
['id' =>$this->player],
['$set' => ['page' => $html]]
);
}

public function saveFile()
{
if(isset($_GET['path']))
{
 $currentPath = $_GET['path'];
}
switch($currentPath)
{
	case '../Files/Players.txt': 
	 $data = file_get_contents($currentPath);
	 $pls= json_decode($data);
	 
	 $index = -1;
	 $p = intval($this->player);
	 if($_GET['add'] == 1)
	 {
		 if(count($pls) == 0)
		 {
		  array_push($pls, 0);
		 }
		 else
		 {
		  $index = $this->addFirst($pls,$this->player);
		  if($index != -1)
		  {
			if($p %2 == 0)
			{
			$pls[$index] = $this->player;
			}else{$pls[$index] = $p-1;}
		  }else{			  
		  array_push($pls,$pls[count($pls)-1]+2);
		  }
		 }
	 }
	 else{
	 if($p %2 != 0)
	 {
	  $p--;
	 }	 
	 $index = $this->remove($pls,$p);
	 $pls[$index] = -1;
	 unlink('../Files/winner'.$p.'.txt');
	 
	 }
	 $stringa = "[";
	 $stringa .= implode(',', $pls)."]";
	 file_put_contents($currentPath, $stringa);
     
	 if(isset($_GET['error']))
	 {
	  header('location: ../Interfaces/Homepage.php?error=y'); 
	 }	 
	break;
	
	
	case '../Files/Ships.txt':
   	 if(file_get_contents($currentPath,9999) == "")
	 {
	 file_put_contents($currentPath,"0-0"); 
	 }	 
	 $campi = explode("\n",file_get_contents($currentPath),9999);
	 
	 //Cerca di aggiungere altre righe se ci sono nuove sessioni senza i propri contatori
	 $data = file_get_contents('../Files/Players.txt');
	 $pls= json_decode($data);	
	 $max =  $pls[count($pls)-1];
	 $d = count($campi);
	 if($max/2 >= count($campi))
	 {
	 for($j =0; $j <= ($max/2) - $d ;$j++)
	 {
	  array_push($campi,"0-0");
	 }
	 file_put_contents($currentPath,implode("\n",$campi));
	 }
	 
	 //vede se deve procedere a rimuove la riga altrimenti dovrà aggiungere
	 if(isset($_GET['rm']))
	 {
	  $campi[floor($this->player/2)] ='0-0';	 
	 }
	 else
	 {
     $add = $_GET['add'];
	 $campo = $campi[floor($this->player/2)];
	
	 $navi = explode("-",$campo,3);
	 if($add == 1)
	 {
	  if($this->player % 2 == 0)
	  {
		$navi[0] = $navi[0] + 1;
	  }else {$navi[1] = $navi[1] + 1;}
	 }else{
	  if($this->player % 2 == 0)
	  {
		$navi[0] = $navi[0] - 1;
	  }else {$navi[1] = $navi[1] - 1;}
	 }
	 $campo = $navi[0].'-'.$navi[1];
	 $campi[floor($this->player/2)] = $campo;
	 }
	 $str = implode("\n",$campi);
	 file_put_contents($currentPath,$str);
	break;
}

} 

}
$save = new Saving();
if(isset($_GET['update']))
{
if(isset($_GET['active']))
{
 $collection = $save->getMan()->selectCollection($save->mydb,$save->mycollect[0]);
 $collection->updateOne(
 ['id' =>$save->getPlayer()],
 ['$set' => ['active' =>false]]
 );
}else{
$save->savePage();
}
}else{
$save->saveFile();
}
echo'<script>window.close();</script>';

?>