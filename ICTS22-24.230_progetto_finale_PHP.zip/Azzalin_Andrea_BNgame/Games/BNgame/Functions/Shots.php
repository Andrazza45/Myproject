<?php
require '../../../Services/_composer/vendor/autoload.php';
interface IShots
{

 function get_round();
	 
 function Shots();
 
 function check();
 
 function update_sunk_ships($ships);
 function lucky_loot();
}

class Shots implements IShots
{
 private $database;
 private $mycollect;
 private $manager;
 private $man;
 private $round;
 private $session;
 public $coords;
 public $player;
 private $tabs;
 
 public function get_round()
 {
  return $this->round;
 }
 
 public function Shots(){
  session_start();
  $this->database='battle_ship';
  $this->manager=new MongoDB\Driver\Manager("mongodb://localhost:27017");
  $this->man=new MongoDB\Client("mongodb://localhost:27017");
  $document = new MongoDB\Driver\BulkWrite();
  $tab = null;
  if(!isset($_GET['coords']))
  {
   $this->player =json_decode(file_get_contents('php://input'),true)['init'];
   $tab =json_decode(file_get_contents('php://input'),true)["table"];
  }
  else{
  $this->coords = $_GET['coords'];
  $this->player = $_GET['init'];
  }
  
  $row = null;
  $options = [
  "projection" => ['id' => 0,'dataI'=>0,'dataF'=>0,'score'=>0]
  ];
  $query = ['id' => strval($this->player)];

  $res = $this->manager->executeQuery('battle_ship.session', new MongoDB\Driver\Query($query,$options));
		
  foreach ($res as $document){
  $row = $document;
  }
  
  $this->session = $row->session;
  
  if(!isset($_SESSION['G'.$this->player]))
  {	
   $row = null;
   $options = [
   "projection" => ['email' => 0,'id'=>0]
   ];
   $query = ["id" => strval($this->player)];

   $res = $this->manager->executeQuery('battle_ship.player', new MongoDB\Driver\Query($query,$options));
		
   foreach ($res as $document) {
   $row = $document;
   }
   $_SESSION['G'.$this->player]= $row->stat;
   $this->round = $_SESSION['G'.$this->player];
  }else{$this->round = $_SESSION['G'.$this->player];}

   if(isset($tab))
   {
    $_SESSION['G'.$this->player] =0;
	$this->round = $_SESSION['G'.$this->player];
    $_SESSION['score'.$this->player] = 0;
	
    if(!isset($_SESSION[$this->session]))
    {
     $_SESSION[$this->session] =[[],[]];
    }
    $index = 0;
    if(intval($this->player) % 2 == 0)
    {
     $index = 0;
     $_SESSION['G'.$this->player] = $index;	
    }	
    else
    {
     $index = 1;
     $_SESSION['G'.$this->player] = $index;
    }
    for($i = 0; $i < 10;$i++)
    {
     array_push($_SESSION[$this->session][$index],[]);
		
     for($j=0;$j <10;$j++)
     {
      array_push($_SESSION[$this->session][$index][$i],'');
     }
    }

    for($i = 0; $i < count($tab);$i++)
    {		
     for($j = 0; $j < count($tab[$i]);$j++)
     {
	  if($tab[$i][$j] != "")
	  {
	   $_SESSION[$this->session][$index][$i][$j] =$tab[$i][$j];
	  }
     }
    }
    $this->mycollect='layout';
    $collection = $this->man->selectCollection($this->database,$this->mycollect);
    $bulk = $collection->updateOne(
    ['id' =>strval($this->player)],
    ['$set' => ['ready' =>true]]
    );
   }
   
   $this->lucky_loot();  
   $this->tabs=$_SESSION[$this->session];
 }
 function update_sunk_ships($ships)
 {
  $this->mycollect ='layout';
  $collection = $this->man->selectCollection($this->database,$this->mycollect);
  $collection->updateOne(
  ['id' =>strval($this->player)],
  ['$set' => ['ships' =>$ships]]
  ); 
 }


 public function check(){
 $document = new MongoDB\Driver\BulkWrite();	
 $this->player =intval($this->player);
 $shoted ='n';
 $x = intval(explode('-',$this->coords,3)[0]);
 $y = intval(explode('-',$this->coords,3)[1]);
 $index=1;
 if($this->player % 2 == 0)
 {
  $index = 1;	
 }else{$index = 0;}
    
 $storage=0;
 if($index == 1)
 {
  $storage = $this->player+1;
 }else{$storage = $this->player-1;}
 
 if($this->tabs[$index][$x][$y] != '')
 {
  if($this->tabs[$index][$x][$y] == '||')
  {
	$shoted = 'L';
	$this->mycollect='session'; 
    $collection = $this->man->selectCollection($this->database,$this->mycollect);
    $bulk = $collection->updateOne(
    ['id' =>strval($this->player),'Fdate' => null],
    ['$set' =>['lucky' => 'lucky']]
    );
  }
  else{
  $shoted ='y';
  $_SESSION['score'.$this->player]++;
  $this->mycollect='session'; 
  $collection = $this->man->selectCollection($this->database,$this->mycollect);
  $bulk = $collection->updateOne(
  ['id' =>strval($this->player),'Fdate' => null],
  ['$set' => ['score' =>$_SESSION['score'.$this->player]]]
  );
  }
  
  file_put_contents('../Files/p'.$storage.'.txt',$this->coords.$this->tabs[$index][$x][$y]);
  }
  //End-phase
  $_SESSION['G'.$this->player] = 0;
 
  $this->mycollect='player';
	
  $collection = $this->man->selectCollection($this->database,$this->mycollect);
  $bulk = $collection->updateOne(
  ['id' =>strval($this->player)],
  ['$set' => ['stat' =>$_SESSION['G'.strval($this->player)]]]
  );
  //Chi parte? 
  $next = $this->player;
  $stat = 0;
	 
  if($this->player % 2 == 0)
  {
   $next = $this->player+1;
   $_SESSION['G'.strval($next)] = 1;
   $stat = $_SESSION['G'.strval($next)];
  }else{
  $next = $this->player-1;
  $_SESSION['G'.strval($next)] = 1;
  $stat = $_SESSION['G'.strval($next)];
  }
	 
  $collection = $this->man->selectCollection($this->database,$this->mycollect);
  $bulk = $collection->updateOne(
  ['id' =>strval($next)],
  ['$set' => ['stat' =>$stat]]
  );
  //Salvo le coordinate dell'impatto su db
  $row = null;
  $options = [
  "projection" => ['id' => 0,'Fdate'=>0,'score'=>0]
  ];
  $query = ['id' => strval($this->player), 'Fdate' => null];
	 
  $res = $this->manager->executeQuery('battle_ship'.'.'.'session', new MongoDB\Driver\Query($query,$options));
	  
  foreach ($res as $document){
  $row = $document;
  }
	
  $data =['email'=>$row->email,'player'=>strval($this->player),'Idate'=>$row->Idate,'coords'=>$this->coords,'shoted'=>$shoted,'time'=>date("Y-m-d H:i:s")];
  $document = new MongoDB\Driver\BulkWrite();
  $document->insert($data);
  $this->manager->executeBulkWrite('battle_ship'.'.'.'coords',$document);
  //controllo se il giocatore ha vinto
  if($_SESSION['score'.$this->player] == 25)
  {
   file_put_contents("../Files/winner".$this->player.".txt",'w');
   header('location: ../Interfaces/Program.php?init='.$this->player);
  }
  else{	
  $row =null;
  $options = [
  "projection" => ['email'=>0,'id' => 0,'ready'=>0,'page'=>0]
  ];
  $query = ['id' =>strval($this->player)];  
  $res = $this->manager->executeQuery('battle_ship'.'.'.'layout', new MongoDB\Driver\Query($query,$options));
    
  foreach ($res as $document) {
  $row = $document;
  }
  $sunkships = $row->ships;
  
  $found=false;
  if($shoted == 'y')
  {
  $type = explode(",",$this->tabs[$index][$x][$y],9)[0];
  $slot = explode(",",$this->tabs[$index][$x][$y],9)[2];
  
  if($slot >= 4 and $slot <= 6)
  {
   $slot-= 4;  
  }
  else if($slot >= 7)
  {$slot-= 7;}
  else{$slot = $slot;}
  
  switch($type)
  {
	case 'a':$sunkships[0][$slot]--;$i=0;break;
	case 'b':$sunkships[1][$slot]--;$i=1;break;
	case 'c':$sunkships[2][$slot]--;$i=2;break;
  }

  if($sunkships[$i][$slot] == 0)
  {
   $found = true;
   $sunkships[$i][$slot] = -1;
   $this->update_sunk_ships($sunkships,$this->player);
   header('location: ../Interfaces/Program.php?init='.$this->player.'&shoted='.$shoted.'&sunk=y&coords='.$this->coords);   
  }
  $this->update_sunk_ships($sunkships,$this->player);
  }
  if($found == false)
  {
   header('location: ../Interfaces/Program.php?init='.$this->player.'&shoted='.$shoted.'&sunk=n&coords='.$this->coords);
  }

 }	 
 }
 function lucky_loot()
 {
  $row = null;
  $options = [
  "projection" => ['email'=>0,'id' => 0,'page' =>0,'ready'=>0]
  ];
  
  $query = ['id' => strval($this->player)];

  $res = $this->manager->executeQuery('battle_ship.layout', new MongoDB\Driver\Query($query,$options));
		
  foreach ($res as $document){
  $row = $document;
  }
  $index = intval($this->player)%2;
  
  if($row->lucky == null)
  {
  $x=0;
  $y=0;
  $lucky="";
  while($_SESSION[$this->session][$x][$y] !="")
  {
  $x = rand(0,9);
  $y = rand(0,9);
  $lucky = strval($x)."-".strval($y);
  }
  $_SESSION[$this->session][$index][$x][$y] = "||";
  echo'<script>console.log('.$_SESSION[$this->session][$x][$y].');</script>';
 
  $this->mycollect='layout';
 
  $collection = $this->man->selectCollection($this->database,$this->mycollect);
  $collection->updateOne(
  ['id' =>strval($this->player)],
  ['$set' => ['lucky'=>$lucky]]
  );
  }else{
  $x = intval(explode("-",$row->lucky,3)[0]);
  $y = intval(explode("-",$row->lucky,3)[1]);
  $_SESSION[$this->session][$index][$x][$y] = "||";
  }
 }
 
}

if(isset($_GET['unlink']))
{
 $player = $_GET['init'];
 unlink('../Files/winner'.$player.'.txt');
}
else{
     $shots = new Shots();
     if(isset($shots->coords))
     {
      if($shots->get_round() == 1)
      {
       $shots->check();
      }
      else{header('location: ../Interfaces/Program.php?init='.$shots->player.'&coords='.$shots->coords.'&error=turno');}
     }
    }
?>