<html>
<head>
<style>
#codice
{
 position:absolute;
 top:24px;
 left:56px;
 background-color:blue;
 border:2px red dashed;
}
input[type = submit]
{
 position:absolute;
 top:24px;
 left:230px;
 background-color:yellow;
}
</style>
</head>
<body>
<form method="post" action ="Code.php?set=&quot;yes&quot;">
<input type ="text" id="codice" name ="Txtcod">
<input type = "submit" value ="Join">
</form>
<?php
include '../Class/BNgame.php';
function prepared($cod,$email)
{
	require '../../../Services/_composer/vendor/autoload.php';
	//connessione con mongodb
    $manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");
	$man = new MongoDB\Client("mongodb://localhost:27017");
	
	$row = null;
	
	$options = [
	"projection" => ['session'=>0,'dataF'=>0,'dataI' =>0,'score' => 0],
	"data" => [
       '$ne' => null
    ],
	'limit' => 1
	];
	$query = ["session" => strval($cod)];

	$res = $manager->executeQuery('battle_ship.session', new MongoDB\Driver\Query($query,$options));
		
	foreach ($res as $document) {
	$row = $document;
	}
	
	if($row != null)
	{
	echo '<script>window.open("Program.php?init='.strval(intval($row->id)+(1)).'")</script>';
	echo '<script>window.close();</script>';
	}
	else
		{
		 echo '<script>alert("Codice sessione non esistente!");</script>';
		}

}
if(isset($_GET['set']))
{
$email = trim(explode('homepage',$_SESSION["Msg"],20)[1]);
$cod = $_POST['Txtcod'];
prepared($cod,$email);
}
?>
</body>
</html>