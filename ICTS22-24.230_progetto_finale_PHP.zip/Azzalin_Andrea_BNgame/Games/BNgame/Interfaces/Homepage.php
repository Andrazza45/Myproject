<html>
<head>
<title>Homepage</title>
<script type="text/javascript">

var newplayer=0;
var email = '';

if(localStorage.getItem('stati') == null)
{
localStorage.setItem('stati','');
}

setInterval(function(){
let array = new Array();
if(localStorage.getItem('stati') != '')
{
array = localStorage.getItem('stati').split(',');
for(let j =0;j < array.length;j++)
{
 if(array[j].split('-')[0] == email)
 {
  window.open('../Functions/Save.php?update=ok&active=false&player='+array[j].split('-')[1]);
  array.splice(j,1);
  localStorage.setItem('stati',array.join(","));
 }	 
}
}
},1000);

function saveCredential()
{
  fetch('../../../Login/Cookie/File/session.txt')
  .then(response => response.text())
  .then(text => (window.open('../../../Services/Validazione.php?copia='+text+'&location='+window.location.href)));
}
function closef()
{
var pop = document.getElementById('pop-upPwd');
pop.style.display = 'none';
}
function setTimer()
{
 setTimeout(function() {
 window.open('../../../Services/Validazione.php?elimina=y');	
},10000);
}
function g1()
{
  return new Promise((resolve) =>{
  fetch('../Files/Players.txt', {cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
  .then(response => response.text())
  .then(text =>{
  var array = JSON.parse(text);
  //trova primo indice = -1
  let index = -1;
  for(let j=0;j<array.length;j++)
  {
	if(array[j] == -1)
	{
	 index=j;
	 j=array.length;
	}
  }
  
  if(index == -1)
  {
	if(array.length == 0)
	{
	 resolve(0);
	 newplayer=0;
	}else{
	 resolve(array[array.length - 1]+2);
	 newplayer =array[array.length - 1]+2;
	}
  }
  else{
  if(index == 0)
  {
   resolve(0);
   newplayer=0;
  }
  else{
  resolve((index+1)*2);newplayer=(index+1)*2;
  }
  }
  
  })
  });//delimita promessa
}
</script>
</head>
<style language ="text/css">
#pop-upPwd
{
 position: absolute;
 display:block;
 heigh:130px;
 width:280px;
 left:1390px;
 top:20px;
}
#pop-upPwd button
{
 heigh:35px;
 width:35px;
}
.game
{
	position:relative;
	left:60px;
	width:190px;
	height:140px;
	top:90px;
	border:4px solid;
	font-weight:bold;
	font-size:17px;
}
.game:nth-of-type(1n)
{
	background-color:#ACE1AF;
}
.game:nth-of-type(2n)
{
	left:65px;
	background-color:#6397D0;
}
#new-add
{
 position:relative;
 left:48px;
 width:500px;
 height:320px;
 background-color:#CE3018;
 border:5px solid;
 top:110px;
}
#continue
{
 position:relative;
 top:110px;
 left:228px;
 font-family:fantasy;
 font-size:35px;
 color:#DC143C;
 font-weight:bold;
 text-stroke:2px black;
 text-shadow: 2px 2px 2px #000;
}
#container
{
 position:relative;
 top:50px;
 width:600px;
 height:600px;
 margin: 0 auto;
 border:3px solid;
 background-color:#FFFACD;
}
header
{
 position: relative;
 width:1790px;
 height:100px;
 background-color:#FFFF00;
 border:3px solid;
}
#email
{
 font-family:roboto;
 color:red;
 font-size:18px;
}
#backup
{
 position:absolute;
 top:9px;
}
</style>
<header>
<?php
session_start();
if(isset($_SESSION["Msg"]))
{
$email =trim(explode('homepage',$_SESSION["Msg"],20)[1]);
}else{header("location: ../../../Login/Login.php");}

require '../../../Services/_composer/vendor/autoload.php';
$msg = $_SESSION["Msg"];
echo '<p id ="email">'.$msg.'</p>';
?>
<div id = "backup">
<br/><br/>Expot file<input type = "file" name = "CaricaFile">
<button>Copia</button>
</div>
<?php
//Controllare esistenza file session!
echo $_SESSION["save_pwd"];
?>
</header>
<body onload = "setTimer();" style ="background-color:#CCCCFF;">

<form method = "get" action = "../../../Services/ExportFile.php">
<br/><br/>
<div id = "container">
<div id="new-add">
<input type="button" class = "game" value="New Game" onclick = "g1().then(value =>{window.open('../Functions/Save.php?path=../Files/Players.txt&add=1&player='+value);});setTimeout(function(){window.open(&quot;Program.php?init=&quot;+newplayer);window.close();},6000);"><input type="button" value ="Join to Game" class = "game" onclick = "window.open('Code.php');window.close();">
</div>
<p id ="continue" onmouseenter="this.style.cursor = 'pointer';" onclick ="window.open('homepage.php?go=ok');window.close();">CONTINUE</p>
</div>
</form>
</body>
<?php

if(isset($_SESSION["Msg"]))
{
}else{header("location: ../../Login/Login.php");}

$email =trim(explode('homepage',$_SESSION["Msg"],20)[1]);
echo '<script>email ="'.trim(explode('homepage',$_SESSION["Msg"],20)[1]).'";console.log(1);</script>';

$database='battle_ship';
$collection1='player';
$manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");
// ----------------
$row =null;
$options = [
"projection" => ['email'=>0, 'stat'=> 0,'active'=>0]
];
$query = ['email' => $email];	
$res = $manager->executeQuery($database.'.'.$collection1, new MongoDB\Driver\Query($query,$options));
	
foreach ($res as $document){
$row = $document;
}
if($row != null)
{
$id = intval($row->id);
if($id != -1)
{
 if($id%2==0)
 {
  $id++;
 }
}

$row =null;
$options = [
"projection" => ['email'=>0, 'id'=> 0,'stat'=>0]
];
$query = ['id'=>strval($id),'active'=>true];//dispari
$res = $manager->executeQuery($database.'.'.$collection1, new MongoDB\Driver\Query($query,$options));
	
foreach ($res as $document){
$row = $document;
}
 if($row != null)
 {
 if($row->active == 1)
 {
  echo '<script>document.getElementsByClassName("game")[1].disabled = true;</script>';
 }
 }
}
// ----------------------------------------------------------------------------------------------
if(isset($_GET['go']))
{
$row =null;
$options = [
"projection" => ['email'=>0, 'stat'=> 0,'active'=>0],
'limit' =>1
];
$query = ['email' => $email,'active'=>false,'id'=>['$ne'=>'-1']];	
$res = $manager->executeQuery($database.'.'.$collection1, new MongoDB\Driver\Query($query,$options));
	
foreach ($res as $document){
$row = $document;
}

if($row != null)
{
echo'<script>window.open("Program.php?init="+'.$row->id .');window.close();</script>';
}else{echo'<script>alert("Sembra che il tuo avversario non abbia ancora fatto la sua mossa.\nAttendi...");</script>';}
}
?>
</html>