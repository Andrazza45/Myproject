<html>
<?php
include '../Class/BNgame.php';
$man = new MongoDB\Client("mongodb://localhost:27017");
$manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");
//$BNgame = new Battle_ship();
prepare($player,$email);
//$BNgame->prepare($player,$email);

if(file_exists('../Files/winner'.$player.'.txt'))
{
echo '<script>window.open(\'../Functions/Save.php?rm=y&path=../Files/Ships.txt&player=\'+'.$player.');</script>';

$mydb='battle_ship';
$mycollect=['player','layout','session'];
//Update e delete giocatore corrente
$collection = $man->selectCollection($mydb,$mycollect[0]);
$collection->updateOne(
['id' =>$player],
['$set' => ['id' =>'-1','stat'=>0,'active'=>false]]
);

$collection = $man->selectCollection($mydb,$mycollect[1]);
$collection->deleteOne(
['id' =>$player]
);

$collection = $man->selectCollection($mydb,$mycollect[2]);
$collection->updateOne(
['id' =>$player,'Fdate'=>null],
['$set' => ['Fdate' =>date("Y-m-d")]]
);
unlink('../Files/p'.$player.'.txt');
//-----------------------
$p = intval($player);
//Per avversario 
if(intval($player)%2==0)
{
$collection = $man->selectCollection($mydb,$mycollect[0]);
$collection->updateOne(
['id' =>strval($p+1)],
['$set' => ['id' =>'-1']]
);
$collection = $man->selectCollection($mydb,$mycollect[2]);
$collection->updateOne(
['id' =>strval($p+1),'Fdate'=>null],
['$set' => ['Fdate' =>date("Y-m-d")]]
);

$collection = $man->selectCollection($mydb,$mycollect[1]);
$collection->deleteOne(
['id' =>strval($p+1)]
);
unlink('../Files/p'.strval($p+1).'.txt');
}
else{
$collection = $man->selectCollection($mydb,$mycollect[0]);
$collection->updateOne(
['id' =>strval($p-1)],
['$set' => ['id' =>'-1','stat'=>0,'active'=>false]]
);
$collection = $man->selectCollection($mydb,$mycollect[2]);
$collection->updateOne(
['id' =>strval($p-1),'Fdate'=>null],
['$set' => ['Fdate' =>date("Y-m-d")]]
);

$collection = $man->selectCollection($mydb,$mycollect[1]);
$collection->deleteOne(
['id' =>strval($p-1)]
);
unlink('../Files/p'.strval($p-1).'.txt');
}

$collection = $man->selectCollection($mydb,$mycollect[0]);
$count = $collection->countDocuments(
['id' => '-1']
);
if($count > 1)
{
 $collection = $man->selectCollection($mydb,$mycollect[0]);
 $collection->deleteOne(
 ['id' => '-1']
 );
}

//display immagine winner con Timer
echo'<script>let div = document.getElementById("msg");div.style.display="block";div.style.backgroundImage =\'URL("../Files/img/Coriandoli.gif")\';</script>';
echo'<script>'.
'window.open(\'../Functions/Save.php?path=../Files/Players.txt&add=-1&player=\'+'.$player.');'.
'</script>';
echo'<script>setTimeout(function(){window.close();},8000);</script>';
}		
?>

<script type="text/javascript">
//creare classe gioco
// public class Battle_ship()
// {
// constructor()
// {
// // aggiunta ev per gestire refresh stati


// this.searchParam = new SearchParam();
// this.player = searchParam.getParam('init');
// this.navi = document.getElementsByClassName("Nave");
// this.song = document.getElementById('song');
// for(let i = 0; i< navi.length;i++)
// {
// this.navi[i].ondrag = function() {

// if(this.song.title != "PiratiDeiCaraibi")
// {
// this.song.title = "PiratiDeiCaraibi";
// this.song.src = "../Files/Sound/PiratiDeiCaraibi.ogg";
// this.song.play();
// }
// };
// }
// this.comandi = document.getElementsByClassName("Comandi");
// this.data;
// this.moved_object;

// this.el = 0;
// this.evento;

// this.m1=0,this.m2=0;
// this.angles = [0,0,0];
// this.message='';
// }


// reverse(array)
// {
	// for(let i = 1;i <= Math.floor(array.length/2); i++)
	// {
		// let s;
		// s = array[i-1];
		// array[i-1] = array[array.length - i];
		// array[array.length - i] = s;
	// }
    // return array;	
// }

// deepCopy(obj)
// {
	// return obj.cloneNode(true);
// }

// DWR(ori,x,y,i)
// {
	// if(ori == true)
	// {
	 // m1 = x + i;
	 // m2 = y;
	// }
	// else{
		 // m1 = x;
		 // m2 = y + i;
		// }
// }
// //-
// UPL(ori,x,y,i)
// {
	// if(ori == true)
	// {
	 // m1 = x - i;
	 // m2 = y;
	// }
	// else{		
         // m1 = x;	
		 // m2 = y - i;
		// }
// }
//...
// }

class SearchParam
{
 constructor()
 {
  this.URL = window.location.href.split('#')[0];  
 }
 getParam(param)
 {
   let params =  (this.URL).split("?")[1];
   if(params.split("").includes('&'))
   {
	   let vars = params.split("&");
	   for(let i = 0; i < vars.length; i++)
	   {
		   if(vars[i].split("=")[0] == param)
		   {
			   return vars[i].split("=")[1];
		   }
	   }
   }
   else{
       	if(params.split("=")[0] == param)
		  {
			return params.split("=")[1];
		  }
   }
   return '';
 }
	
}

//Global Variables
var errorMessage='';
var searchParam = new SearchParam();
var player = searchParam.getParam('init');
var email = "";
var navi = document.getElementsByClassName("Nave");
var song = document.getElementById('song');
song.title ="";
for(let i = 0; i< navi.length;i++)
{
navi[i].ondrag = function() {
if(song.title != "PiratiDeiCaraibi")
{
song.title = "PiratiDeiCaraibi";
song.src = "../Files/Sound/PiratiDeiCaraibi.ogg";
song.play();
}
};
}
var comandi = document.getElementsByClassName("Comandi");
var data;
var moved_object;

var el = 0;
var evento;

var m1=0,m2=0;
var angles = [0,0,0,0,0,0,0,0,0];

var message='';
setInterval(function(){
if(parseInt(player) % 2 == 0)
{
 fetch('../Files/winner'+(parseInt(player)+1)+'.txt',{cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
 .then(response => response.text())
 .then(text =>{
 if(text == 'w')
 {
  let div = document.getElementById("msg");
  div.style.display="block";
  div.style.backgroundImage ="URL('../Files/img/Lose.png')";
  setTimeout(function(){window.open('../Functions/Shots.php?unlink=ok&init='+(parseInt(player)+1));window.close();},10000);
 }
 });
 
}else{
fetch('../Files/winner'+(parseInt(player)-1)+'.txt',{cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
.then(response => response.text())
.then(text =>{
if(text == 'w')
{
 let div = document.getElementById("msg");
 div.style.display="block";
 div.style.backgroundImage ="URL('../Files/img/Lose.png')";
 setTimeout(function(){window.open('../Functions/Shots.php?unlink=ok&init='+(parseInt(player)-1));window.close();},10000); 
}
});
}
setTimeout(function(){
fetch('../Files/p'+player+'.txt',{cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
.then(response => response.text())
.then(text =>{
if(message != text && text.split("").length <= 12)
{
 let msg = document.getElementById('coords');
 text = text.split(",")[0];
 let textA=text.split("");
 textA.splice(textA.length-1,1);	
 text =textA.join("");
 msg.innerHTML=text;
 msg.style.display="block";
 setTimeout(function(){msg.style.display="none";},1000);
 // message= text;
}
});
},2000);

},5000);

//+
function DWR(ori,x,y,i)
{
	if(ori == true)
	{
	 m1 = x + i;
	 m2 = y;
	}
	else{
		 m1 = x;
		 m2 = y + i;
		}
}
//-
function UPL(ori,x,y,i)
{
	if(ori == true)
	{
	 m1 = x - i;
	 m2 = y;
	}
	else{		
         m1 = x;	
		 m2 = y - i;
		}
}

function gameToJson(player)
{
   	 let tab = document.getElementsByClassName("Campo")[1];
	 let rows = tab.rows;           
     let table = [];
     let ori = "false";
	 
     for (let i = 1; i < rows.length; i++){
         let rowData = [];
         let cells = rows[i].cells;
                
         for (let j = 0; j < cells.length; j++){
			 if(cells[j].lastChild != null)
			 {
			  if(cells[j].children[0].style.transform=="rotate(0deg)" || cells[j].children[0].style.transform=="rotate(180deg)")
			  {ori = "false";}else{ori ="true";}
              rowData.push(cells[j].children[0].id.split("")[0]+','+ori+','+cells[j].children[0].slot);
			 }else{rowData.push('');}
			}
         table.push(rowData);
         }
	let data ={'init':player,'table':table};//?
            
    let jsonData = JSON.stringify(data);
	var xhr = new XMLHttpRequest();
    xhr.open("POST", "../Functions/Shots.php", true);
    xhr.setRequestHeader("Content-Type", "application/json");
	xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
    // Risposta ricevuta dal server
    console.log(xhr.responseText);
     }
    };
    xhr.send(jsonData);
}

// function confirm(confirmationMessage)
// {
// var div = document.getElementById('msg');
// var container = document.getElementById('container');
// var harbor = document.getElementsByClassName('Porto')[0];
// container.style.bottom ="800px";
// harbor.style.bottom ="600px";
// div.style.display = 'block';

// let msg = document.createElement('p');
// msg.textContent = confirmationMessage;
// let btnY = document.createElement('button');
// btnY.id = "Y";
// btnY.addEventListener('onclick',stato);
// btnY.textContent ="YEs";
// let btnN = document.createElement('button');
// btnN.id = "N"; 
// btnN.textContent ="No";
// btnN.addEventListener('onclick',stato);
// div.append(msg);
// div.append(btnY);
// div.append(btnN);
// }
function turn_off()
{
 //disabilito tasto reload
 if(window.performance.navigation.type === 2)
 {return null;}else{localStorage.setItem('stati',localStorage.getItem('stati')+email+'-'+player+',');}
}
window.onbeforeunload = function(){turn_off();}

function getTargets(x,y,l,ori,verso)
{
	 let targets = new Array();
	 if(el > 0 && el < l -1)
	 {
		if(verso == true)
		{
			for(let i = 1; i <=el; i++)
			{
			 UPL(ori,x,y,i);
			 targets.push(document.getElementById(m1.toString()+"-"+m2.toString()));
			}
		}
		else{
		     for(let i = 1; i <= l-el-1; i++)
		     {
		      UPL(ori,x,y,i);
		      targets.push(document.getElementById(m1.toString()+"-"+m2.toString()));
		     }
		}
		targets = reverse(targets);
		targets.push(document.getElementById(x.toString()+"-"+y.toString()));
		if(verso == true)
		{
			for(let i = 1; i <= l-el-1; i++)
			{
			 DWR(ori,x,y,i);
			 targets.push(document.getElementById(m1.toString()+"-"+m2.toString()));
			}
		}
		else{
			 for(let i = 1; i <=el; i++)
			 {
			  DWR(ori,x,y,i);
			  targets.push(document.getElementById(m1.toString()+"-"+m2.toString()));
			 }		
		}
	 }
	 else{
		  switch(el)
		  {
		  case 0:
		  for(let i = 0; i < l; i++)
		  {	
	       if(verso == true)
		   {
           DWR(ori,x,y,i);
		   }else{UPL(ori,x,y,i);}		
		   
		   targets.push(document.getElementById(m1.toString()+"-"+m2.toString()));
		  }
		  break;
		  case l-1:
		  for(let i = 0; i < l; i++)
		  {
		   if(verso == true)
		   {
		   UPL(ori,x,y,i);
		   }else{DWR(ori,x,y,i);}
		   
		   targets.push(document.getElementById(m1.toString()+"-"+m2.toString()));
		  }
		  break;
		  }
		   if(el == l-1 && verso == true || el == 0 && verso == false)
		   {	   
			targets = reverse(targets);
		   }
	     }
	 return targets;
}

function reverse(array)
{
	for(let i = 1;i <= Math.floor(array.length/2); i++)
	{
		let s;
		s = array[i-1];
		array[i-1] = array[array.length - i];
		array[array.length - i] = s;
	}
    return array;	
}

function deepCopy(obj)
{
	return obj.cloneNode(true);
}

function is_blocked(water,o,ori,minus)
{
let count=1;
let type = '';
o = parseInt(o);
let oldo = o;
let move = 0;
let oldwater = deepCopy(water);
for(let k=0;count <= 2 && k < 2;k++)
{
water = oldwater;
for(let j = 0;water.id.split('-').includes('0') == false && water.id.split('-').includes('9') == false && count <= 2;j++)
{
count=1;
o = oldo;
if(j != 0)
{
 if(k == 0){move--;}else{move++;}
 if(ori == true)
 {
  water = document.getElementById(o+'-'+move);
 }else{water = document.getElementById(move+'-'+o);}
}
if(ori == true)
{
 let y = parseInt(water.id.split('-')[1]);
 move = y;
 if(minus == true)
 {
  for(let i = 1;water.lastChild != null && water.id.split('-').includes('0') ==false ;i++)
  {
   if(i == 1)
   {
	 type = water.children[0].id.split("")[0];
     count++;   
   }
   UPL(ori,o,y,i);
   water = document.getElementById(m1+'-'+m2);	
   if(water.lastChild != null)
   {   
    if(type != water.children[0].id.split("")[0])
    {
	 count++;
	 type = water.children[0].id.split("")[0];
    }
   }
  }
			
 }else{
    		
  for(let i = 1;water.lastChild != null && water.id.split('-').includes('9') ==false;i++)
  {
   if(i == 1)
   {
	type = water.children[0].id.split("")[0];
	count++;
   }
   DWR(ori,o,y,i);
   water = document.getElementById(m1+'-'+m2);            
   
   if(water.lastChild != null)
   {
    if(type != water.children[0].id.split("")[0])
    {
     count++;
	 type = water.children[0].id.split("")[0];
    }
   }   
  }			
 }
}
else
{
let x = parseInt(water.id.split('-')[0]);
move = x;
if(minus == true)
{
	for(let i = 1;water.lastChild != null && water.id.split('-').includes('0') ==false;i++)
	{
	 if(i == 1)
     {
	  type = water.children[0].id.split("")[0];
	  count++;
     }
	 UPL(ori,x,o,i);
	 water = document.getElementById(m1+'-'+m2);		 
	 if(water.lastChild != null)
     { 
	  if(type != water.children[0].id.split("")[0])
	  {
	   count++;
	   type = water.children[0].id.split("")[0];
	  }
	 }	 
	}
}else{
 for(let i = 1;water.lastChild != null && water.id.split('-').includes('9') ==false;i++)
 {
  if(i == 1)
  {
   type = water.children[0].id.split("")[0];
   count++;	
  }
  DWR(ori,x,o,i);
  water = document.getElementById(m1+'-'+m2);	
  
  if(water.lastChild != null)
  {
   if(type != water.children[0].id.split("")[0])
   {
	count++;
	type = water.children[0].id.split("")[0];
   }
  }		 
 }			
}
}
}
}

if(count <= 2)
{
 return false;
}else{return true;}

}

function sled_overshoot(water,o,ori,minus)
{
o = parseInt(o);
let type = water.children[0].id.split("")[0];
if(ori == true)
{
 let y = parseInt(water.id.split('-')[1]);
 if(minus == true)
 {
  for(let i = 1;water.lastChild != null;i++)
  {
   UPL(ori,o,y,i);
   water = document.getElementById(m1+'-'+m2);	
   if(water.id.split('-').includes('0') == true && water.lastChild != null)
   {
	if(type != water.children[0].id.split("")[0])
	{errorMessage="Sembra bloccata!";}

	return true;
   }
  }
			
 }else{
    		
  for(let i = 1;water.lastChild != null;i++)
  {
   DWR(ori,o,y,i);
   water = document.getElementById(m1+'-'+m2);            
   if(water.id.split('-').includes('9') == true && water.lastChild != null)
   {
	if(type != water.children[0].id.split("")[0])
	{errorMessage="Sembra bloccata!";}
    return true;
   }			 			 
  }			
 }
}
else
{
let x = parseInt(water.id.split('-')[0]);
if(minus == true)
{
	for(let i = 1;water.lastChild != null;i++)
	{
	 UPL(ori,x,o,i);
	 water = document.getElementById(m1+'-'+m2);		 
	 if(water.id.split('-').includes('0') == true && water.lastChild != null)
	 {
	  if(type != water.children[0].id.split("")[0])
	  {errorMessage="Sembra bloccata!";}
	  return true;
	 }		 
	}
}else{
 for(let i = 1;water.lastChild != null;i++)
 {
  DWR(ori,x,o,i);
  water = document.getElementById(m1+'-'+m2);	
  if(water.id.split('-').includes('9') == true && water.lastChild != null)
  {
    if(type != water.children[0].id.split("")[0])
    {errorMessage="Sembra bloccata!";}
	return true;
  }
			 
 }			
}
}
return false;
}

function overshoot(o,pzs, verso)
{
let error = 1;
if(o <=9 && o >=6)
{
   if(verso == true)
   {
	 if(o+1*(pzs.length-el-1)>9)
	 {
      error = 0;
	 }
   }
   else{
   if(o+el>9)
   {
	error = 0;			
   }
   }
}
else if(o >= 0 && o <=3)
{
   if(verso == true)
   {
	 if(o-el<0)
	 {
	   error = 0;			
	 }
   }
   else{
     if(o-1*(pzs.length-el-1)<0)
	 {
       error = 0;
	 }
   }	   
}
else{error = 1;}
return error;
}



function getElement(id)
{
 el = parseInt(id.split("")[1]);
}

function toX(verso,ori,l,target)
{
 let to0 = Math.abs(l-el-l);
 let toPzs = l-1-el;
 let x;
if(ori == true)
{
 if(verso == true)
 {  
    x = document.getElementById(parseInt(target.id.split('-')[0])+1*(toPzs)+'-'+target.id.split('-')[1]);               
	if(x.lastChild != null)
	{
	 return toPzs;
	}
	
	x = document.getElementById(parseInt(target.id.split('-')[0])-to0+'-'+target.id.split('-')[1]);               
	if(x.lastChild != null)
	{
	 return -1*(to0);
	}
 }else{
  x = document.getElementById(parseInt(target.id.split('-')[0])-toPzs+'-'+target.id.split('-')[1]);               
  if(x.lastChild != null)
  {
	return -1*(toPzs);
  }
  x = document.getElementById(parseInt(target.id.split('-')[0])+1*(to0)+'-'+target.id.split('-')[1]);               
  if(x.lastChild != null)
  {
	return to0;
  } 
 }
}else{
 if(verso == true)
 {  
    x = document.getElementById(target.id.split('-')[0]+'-'+(parseInt(target.id.split('-')[1])+toPzs));               
	if(x.lastChild != null)
	{
	 return toPzs;
	}
	
	x = document.getElementById(target.id.split('-')[0]+'-'+(parseInt(target.id.split('-')[1])-to0));               
	if(x.lastChild != null)
	{
	 return -1*(to0);
	}
 }else{
  x = document.getElementById(target.id.split('-')[0]+'-'+(parseInt(target.id.split('-')[1])-toPzs));               
  if(x.lastChild != null)
  {
	return -1*(toPzs);
  }
  x = document.getElementById(target.id.split('-')[0]+'-'+(parseInt(target.id.split('-')[1])+to0));               
  if(x.lastChild != null)
  {
	return to0;
  } 
 } 
}
return 4;
}

function indexApp(verso,ori,l,target,pzs)
{
 let p;
 p = toX(verso,ori,l,target);	
 
 if(p == 0)
 {
  if(pzs[el].style.transform =="rotate(180deg)" || pzs[el].style.transform =="rotate(270deg)")
  {
	if(pzs[pzs.length-1].id.split("")[1] == 0)
	{
	 p = l-1-el;
	}else{p = 0;}
	
  }else{
  if(pzs[el].id.split("")[1] == 0)
	{
	 p = 0;
	}else{p = l-1;}
  }
  return p;
 }
 
 if(p < 0)
 {
  p = 0;
  return p;
 }
 
 if(p == 4)
 {
  let to0 = el;
  let toPzs = l-1-el;
  if(to0 > toPzs)
  {p = Math.floor(to0/2);}
  else{p = Math.floor(toPzs/2);}
  return p;
 }
 return p+1;          
}


// function cast(array)
// {
	// let arrayDiv = array.map((oggetto) =>{
	// let div = document.createElement('div');div.id=${oggetto.id};
	// div.style.background-image=${oggetto.style.background-image};div.onmousedown=${oggetto.onmousedown};
	// return div;
	// });
// }

function adjuste()
{
 let gradi = document.getElementsByClassName("Gradi");
 let Btns = document.getElementsByClassName("Gira");
 let campi =document.getElementsByClassName("Campo");
 let container=document.getElementById('container');
 campi[1].ondragleave = restore; 
 container.ondragleave = restore;
 let s=0;
 let harbor = document.getElementsByClassName("Porto")[0];
 if(harbor.accessKey =="")
 {
	for(let i = 1; i <= navi.length;i++)
	{ 
		switch(navi[i-1].children[0].id.split("")[0])
		{
		 case 'a':s=2;break;
		 case 'b':s=3;break;
		 case 'c':s=4;break;
		}
		gradi[i-1].style.left = (s)*42+40;
		navi[i-1].style.height =45;
		navi[i-1].style.width =(s)*42;
		Btns[i-1].style.left =(s)*42;
	}
 }
}

function turn(e)
{
   let pzs = navi[e].children;
   let gradi = document.getElementsByClassName("Gradi");
   angles[e] = angles[e] + 90;

   if(angles[e] == 180 || angles[e] ==  270)
   {
	navi[e].style.transform= "rotatex(135deg) rotatey(200deg) rotate("+(0).toString()+"deg)";
    navi[e].style.perspective="1000px";
    navi[e].style.position="relative";
    navi[e].left="20px";
   }else{
	navi[e].style.transform= "rotatex(60deg) rotate("+(28).toString()+"deg)";
	navi[e].style.perspective="1000px";
    navi[e].style.position="relative";
    navi[e].left="20px";
	}
   
   if(angles[e] == 360)
   {
	  angles[e] = 0;
   }
   gradi[e].textContent = angles[e].toString()+"°";
}

function restore(evento){

data = parseInt(data);
if(evento.target.className == "Campo" || evento.target.id == "container" || evento.target.tagName == "BODY")//try
{
 navi[data].style.perspective="1000px";
 if(angles[data] == 0 || angles[data] == 90)
 {
 navi[data].style.transform="rotatex(60deg) rotate(28deg)";
 }else{navi[data].style.transform="rotatex(135deg) rotatey(200deg) rotate("+(0).toString()+"deg)";}
 
 navi[data].style.position="relative";
 navi[data].left="20px";
 
 for(let i=0; i < navi[data].children.length;i++)
 {
	navi[data].children[i].style.transform = "rotate(0deg)"; 
 }
 navi[data].style.display ="block";
}
}
function append(targets,pzs,len)
{
let c = 0;	
// Itero su tutti i target e appendendo i pzs

 for(let i = 0; i < targets.length; i++) {
	pzs[i-c].draggable = false;
	targets[i].appendChild(pzs[i-c]);
	if(pzs instanceof HTMLCollection)
	{
	c++;
	}
 }			
}

function accident(types)
{
	let v1=false, v2=false;
	if(types[0].split('-')[1] == 'rotate(180deg)' || types[0].split('-')[1] == 'rotate(0deg)')
	{
	v1 = true;	 
	}
	if(types[1].split('-')[1] == 'rotate(180deg)' || types[1].split('-')[1] == 'rotate(0deg)')
	{
	v2 = true;
	}
	if(v1 != v2)
	{
	return true;	 
	}else{return false;}
}
		

function handle(data,ev)
{
  // let img = new Image();
  // img.src = '';
  // ev.dataTransfer.setDragImage(img,0,0);

  let x = parseInt(data);
  let pzs = navi[x].children;  
  navi[x].style.display ="none";
  
  moved_object = deepCopy(navi[x]);
  navi[x].style.transform = "rotate("+angles[x].toString()+"deg)";
 
  for(let i = 0; i < pzs.length; i++)
  {
	pzs[i].style.transform = "rotate("+angles[x].toString()+"deg)"; 
  }
  
  switch(navi[x].style.transform)
  {
	case 'rotate(0deg)':
	pzs[0].accessKey = '-';
	pzs[pzs.length-1].accessKey = '+';
	break;
	case 'rotate(90deg)':
	pzs[0].accessKey = '-';
	pzs[pzs.length-1].accessKey = '+';			
	break;
	case 'rotate(180deg)':
	pzs[0].accessKey = '-';
	pzs[pzs.length-1].accessKey = '+';			
	break;
	case 'rotate(270deg)':
	pzs[0].accessKey = '-';
	pzs[pzs.length-1].accessKey = '+';			
	break;			 
  }
  // let nave = navi[x];
  // let canvas = document.createElement('canvas');
  // canvas.style.transform = nave.style.transform;
  // let context = canvas.getContext('2d');
  
  }
function getCell(id,cellIndex)
{
let cAvv = document.getElementsByClassName("campo")[0];
let rows = cAvv.rows;
let cells = new Array();
for(let i = 1;i<rows.length;i++)
{
 cells.push(rows[i].cells);
}
return cells[id][cellIndex];
}

function verify(id,cellIndex,player)
{
 fetch('../Files/Ships.txt',{cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
 .then(response => response.text())
 .then(text =>{
 let campo = text.split("\n")[Math.floor(parseInt(player)/2)];
 if(campo == "9-9")
 {
 id = parseInt(id);
 cellIndex = parseInt(cellIndex);
 let cell = getCell(id,cellIndex);
 if(cell.style.backgroundImage == "" && cell.style.backgroundColor == "")
 {
    cell.style.backgroundImage = "URL(../Files/img/Boom1.gif)";
	 
	if(song.title != "PiratiDeiCaraibi")
	{
	 song.title = "PiratiDeiCaraibi";
	 song.src = "../Files/Sound/PiratiDeiCaraibi.ogg";
	 song.play();	
	}
	
	//disabilitare cambiamento di stato
	window.onbeforeunload=null;
	
	setTimeout(function(){
	cell.style.backgroundImage = "";
	window.open('../Functions/Shots.php?coords='+id+'-'+cellIndex.toString()+'&init='+player);
	window.close();//chiude la corrente
	},5000); 
 }else{alert('Già colpito!');}
 }else{alert('Il tuo avversario non ha ancora ancorato le proprie navi.');}
 });
}

function setSail(ev)
{
 ev.dataTransfer.setData("text", ev.target.slot);
 data = ev.dataTransfer.getData("text");
 evento = ev;
}
function anchor(ev)
{
 	ev.preventDefault();
    data = ev.dataTransfer.getData("text");
	let nave = navi[parseInt(data)];
	let comando = comandi[parseInt(data)];
	let pzs = navi[parseInt(data)].children;
    let array = Array.from(pzs); 

	let a=0;
	let end =pzs.length;
	//Attention
	for(let i=0; i< end;i++)
	{
	 pzs[i-a].parentNode.removeChild(pzs[i-a].parentNode.firstChild);
	 a++;
	}
		
	pzs = array;//uguale non funziona su obj ma trattandosi di Array..[]
	     
	for(let i=0; i< pzs.length;i++)
	{
	 navi[parseInt(data)].appendChild(pzs[i]);
	}
	if(nave.style.transform == "rotate(180deg)" || nave.style.transform == "rotate(270deg)")
	{ 
	 pzs = reverse(pzs);
	}
	
	let target = event.currentTarget;
	let x; 
	let y;
	let ori = false;
    let verso = true;
    let rev = true;
	//Bisogna segnare error con -1
	let error = 0;
	let targets = new Array();
	 
	if(nave.style.transform == "rotate(90deg)" || nave.style.transform == "rotate(270deg)")
	{
	 ori = true;
	 x= parseInt(target.id.split("-")[0]);
	 y= parseInt(target.id.split("-")[1]);
	}
	else
	{
	  ori = false;
	  x= parseInt(target.id.split("-")[0]);
	  y= parseInt(target.id.split("-")[1]);
	}
	
	  let o;   
	  if(ori == false)
	  {
	   o = y;   
	  }else{o = x;}
	  
	  if(nave.style.transform == "rotate(270deg)" || nave.style.transform == "rotate(180deg)")
	  {
		verso = false;  
		rev = verso;
	  }
	  //calcolo sforamento
	  error = overshoot(o,pzs,verso);

	  if(error == 0)
	    {
		  errorMessage = "Precipitoooo!!";
		  for(let i=0;i < nave.children.length;i++)
		  {nave.children[i].style.transform="rotate(0deg)";}
		  navi[parseInt(data)].style.display = 'block';
		}
		// Ottengo tutti i target dell'evento ondrop
		else{targets = getTargets(x,y,pzs.length,ori,verso);}
	
	let c = targets.length;
	if(error != 0)
	{
		let types = new Array();
		types.push(pzs[el].id.split("")[0]+"-"+pzs[el].style.transform)
		let lastChs = new Array();
		for (let i = 0; i < targets.length; i++) {
		 if (targets[i].lastChild != null)
		 {
			lastChs.push(i);
			
			let currentType=targets[i].lastChild.id.split("")[0];
			if(i == 0){
			if(targets[i].lastChild != null){types.push(currentType+"-"+targets[i].lastChild.style.transform);}
			}
			//Verifico pz se diverso
			let found =false;
			for(let j=0; j < types.length;j++)
			{
			 if(currentType+"-"+targets[i].lastChild.style.transform == types[j])
			 {
			  found = true;
			  j = types.length;
			 }
			}
			if(found == false && targets[i].lastChild != null)
			{
			 types.push(currentType+"-"+targets[i].lastChild.style.transform);
			}
		 }
		}

        if(lastChs.length == 0)
		{
		  error = 1;
		  pzs[0].accessKey = '+';
          pzs[a-1].accessKey = '-';
		  append(targets,pzs,c);
		  nave.style.display = "none";
		  comando.style.display = "none";
		}
		else if(accident(types) == true || lastChs.length == 1)
		{
		  let spinta = false;
		  let out = false;
		  let x;
		  let l;
		  if(toX(verso,ori,pzs.length,target) != 4 && lastChs.length == 1)
		  {
		  if(ori == true)
		  {
		  x = document.getElementById(parseInt(target.id.split('-')[0])+1*(toX(verso,ori,pzs.length,target)).toString()+'-'+target.id.split('-')[1]);  
		  }else{x = document.getElementById(target.id.split('-')[0]+'-'+(parseInt(target.id.split('-')[1])+1*(toX(verso,ori,pzs.length,target))));}
		  
		  let type =x.children[0].id.split("")[0];
		  
		  switch(type)
		  {
			case 'a':l=2;break;
			case 'b':l=3;break;
			case 'c':l=4;break;
		  }
			
		  if(accident(types) == false)
		  {
		   if(ori == true)
		   {
		   o = parseInt(x.id.split('-')[0]);	
		   }				
		   else{
		   o = parseInt(x.id.split('-')[1]);
		   }
		
		   if(x.lastChild.style.transform =="rotate(90deg)" || x.lastChild.style.transform == "rotate(0deg)")
		   {
		    if(o+l > 9)
			{
			out = true;
			}
		   }else{
			if(o-l < 0)
			{
		     out = true;
			}
		   }
		  }else{
			  
		   if(ori == true)
		   {
			if(parseInt(x.id.split('-')[0])+1 > 9)
			{
			 out = true;
			}			 
			if(parseInt(x.id.split('-')[0])-1 < 0)
			{
			 out = true;
			}			 
			  
		   }else{
		   if(parseInt(x.id.split('-')[1])+1 > 9)
		   {
			out = true;
		   }			 
		   if(parseInt(x.id.split('-')[1])-1 < 0)
		   {
			out = true;
		   }			 
		   }
		  }
		  if(out != true)
		  {
		   spinta = true; 
		  }else{
		  error =0;errorMessage ="Precipitoooo!!";
		  for(let i=0;i < nave.children.length;i++)
		  {nave.children[i].style.transform="rotate(0deg)";}
		  }

		  }else{spinta = false;error =0;}
		  
		  if(spinta == true)
		  {
		    error = 1;	
			let targets1 = new Array();
			let c = new Array();
			let minus = false;
			let o;
			let o1;
			c.push(parseInt(x.id.split("-")[0]));
			c.push(parseInt(x.id.split("-")[1]));
            let hookup = el;						
			el = parseInt(x.children[0].id.split("")[1]);
			
			let towards = true;
			if(x.children[0].style.transform == "rotate(180deg)" || x.children[0].style.transform == "rotate(270deg)")
			{
			 towards = false;	
			}
			 
			let pzsT = new Array();
			let oldori = ori;
			if(accident(types) == true)
			{
			 if(ori == true)
			 {
			  ori = false;	
			 }else{ori = true;}
			 
			 targets1 = getTargets(c[0],c[1],l,ori,towards);
		     el = hookup;

			 if(!ori == true)
			 {
			  o = parseInt(x.id.split('-')[0]);
			  o1 = parseInt(target.id.split('-')[0]);
			  if(o < o1)
			  {
			   c[0] --;
			   minus = true;
			  }	else if(o > o1){
			   c[0] ++;
			  }else{
			  if(pzs[el].accessKey == '-')
			  {
			  c[0] --;
			  minus = true;
			  }else{
			  c[0] ++;
			  }
			  }
			  
			 }else{
			  o = parseInt(x.id.split('-')[1]);
			  o1 = parseInt(target.id.split('-')[1]);
			  if(o < o1)
			  {
			   c[1] --;
			   minus = true;
			  }else if(o > o1){
			   c[1] ++;
			  }else{
			  
			  if(pzs[el].accessKey == '-')
			  {
			   c[1] --;
			   minus = true;			   
			  }else{
			   c[1] ++;
			  }
			  }
			  			 
			 }
			  
			 
		    }else{ 
			targets1 = getTargets(c[0],c[1],l,ori,towards);
			el = hookup;
			
			if(pzs[Math.abs(toX(verso,oldori,pzs.length,target))].style.transform == "rotate(0deg)" || pzs[Math.abs(toX(verso,oldori,pzs.length,target))].style.transform == "rotate(180deg)")
			{
			 o = x.id.split('-')[1];
			 o1 = target.id.split('-')[1];
			}
			else{
			 o = x.id.split('-')[0];
			 o1 = target.id.split('-')[0];
			}

		    if(pzs[Math.abs(toX(verso,oldori,pzs.length,target))].style.transform == "rotate(0deg)" || pzs[Math.abs(toX(verso,oldori,pzs.length,target))].style.transform == "rotate(180deg)")
			{
			 if(o < o1)
			 {
			 c[1]--;
			 minus = true;
			 }else if(o > o1){
			 c[1]++;
			 }
			 else{
			 if(x.children[0].accessKey == '-')
			 {
			  c[1]--;
			  minus = true;			  
			 }else{c[1]++;}
			 }
			}
			else{
			if(o < o1)
			{
			 c[0]--;
			 minus = true;
			}else if(o > o1){
			c[0]++;
			}else{
			if(x.children[0].accessKey == '-')
			{
			 c[0]--;
			 minus = true;
			}else{c[0]++;}
			 
			}
			}
			
		    }
			
			el = parseInt(x.children[0].id.split("")[1]);
			
			let water = x;
			
			if(sled_overshoot(water,o,oldori,minus)==false)
			{
				if(is_blocked(water,o,oldori,minus)==false)
				{
				
				 for(let i = 0; i< targets1.length;i++)
				 {
				  pzsT.push(targets1[i].children[0]);	
				  targets1[i].removeChild(targets1[i].children[0]);
				 }
				 
				 let targetsT = new Array();
				 
				 targetsT = getTargets(c[0],c[1],l,ori,towards);
				 append(targetsT,pzsT,l);
				 append(targets,pzs,pzs.length);
				 nave.style.display = "none";
				 comando.style.display = "none";
				}else{
				error =0;errorMessage="Sembra bloccata!";
				
				for(let i=0;i < nave.children.length;i++)
				{nave.children[i].style.transform="rotate(0deg)";}
			
				}
			}else{
			error =0;if(errorMessage ==''){errorMessage="Precipitoooo!!"};
			for(let i=0;i < nave.children.length;i++)
			{nave.children[i].style.transform="rotate(0deg)";}			
			}
	      }
		  else{ 
		       if(errorMessage =='')//c'è già un alert
			   {
		       error = 0;
		       navi[parseInt(data)].style.display = "none";
			   for(let i = 0; i < targets.length; i++){
			   targets[i].style.backgroundColor= "red";
		       }
		       setTimeout(function(){
		       for(let i = 0; i < targets.length; i++){
		       targets[i].style.backgroundColor= "blue";
		       }
		       },1000);
			   
		       c = 0;
			   for(let i=0; i< pzs.length;i++)
		       {
		        navi[parseInt(data)].removeChild(navi[parseInt(data)].children[i-c]);
				c++;
		       }
			   if(verso == false)
		       {
			    pzs = reverse(pzs);
		       }
   			   for(let i=0; i< pzs.length;i++)
		       {
		        navi[parseInt(data)].appendChild(pzs[i]);
		       }
			   
			   for(let i=0; i < moved_object.children.length;i++)
		       {
		 	   navi[parseInt(data)].children[i].style.transform="rotate(0deg)";
		       }
			   if(verso == false)
			   {
				navi[parseInt(data)].style.transform ="rotatex(135deg) rotatey(200deg) rotate(0deg)";
			   }else{navi[parseInt(data)].style.transform = "rotatex(60deg) rotate(28deg)";}
			   
		       switch(c-1)
		       {
		 	    case 1:
		 	    navi[0].style.display = "block";
		 	    break;
			    case 2:
			    navi[1].style.display = "block";
			    break;
			    case 3:
			    navi[2].style.display = "block";
			    break;
		        }
		       }
		  }
		}
		else{
		   let rm = 0;
		   pzs[0].accessKey = '+';
           pzs[a-1].accessKey = '-';
		   let sovr = new Array();
		   let index;		 
		   //mi sono andato a complicare la vita
		   index = indexApp(verso,ori,c,target,pzs);
		   
		   if(index == targets.length){index--;}
		   
		   if(targets[index].children[0].style.transform =="rotate(270deg)" || targets[index].children[0].style.transform == "rotate(180deg)")
		   {
			verso = false;
		   }else{verso = true;}
		   
		   let end = 0;
		   let l;
		   switch(targets[index].children[0].id.split("")[0])
		   {
			 case 'a':l=2;break;
             case 'b':l=3;break;
		     case 'c':l=4;break;
		   }
		   if(types.length <= 2)
		   {
			   navi[parseInt(data)].style.display="none";
		       comando.style.display="none";
			   if(lastChs[0] == 0){end = -1;}else{end = lastChs[0]-1;}
			   
			   for (let i = lastChs[0]; i <= lastChs.length + end; i++) {
					if(targets[i].lastChild != null)
					{
					sovr.push(targets[i].lastChild);
					targets[i].removeChild(targets[i].lastChild);
					rm++;
					}
				}

				   append(targets, pzs,c);
				
			   //Ciò che eccede viene tolto
			   let children = new Array();
			   let e; 		
			   let stop = sovr[0].id.split("")[0];
			   
			   if(c >= sovr.length)
			   {
			   //-   
			   if(ori == false)
			   {
				o = y;   
			   }else{o = x;}
			   
			   if(o-1*(c-lastChs.length) >= 0)
			   {   
				   end = 0;
				   if(targets[0].id.split('-').includes('0') == false)
				   {
					end = 9;
				   }
			 
				   for (let i = 1; i <= end; i++) {

						if(ori == true)
						{
						if(verso == false)
						{	
						 if(rev == verso)
						 {	 
						 UPL(ori,x-1*(c-el-1),y,i);
						 }else{UPL(ori,x-1*(c-1*(c-el)),y,i);}					
						}else{
						 if(rev == verso)
						 {	 
						 UPL(ori,x-1*(c-1*(c-el)),y,i);
						 }else{UPL(ori,x-1*(c-el-1),y,i);}
						 e = document.getElementById(m1.toString()+"-"+m2.toString());
						 
						 if(e.lastChild != null)
						 {
						 if(e.children[0].id.split("")[0] == stop)
						 {						 
							 if(e.lastChild != null)
							 {
							  children.push(e.lastChild);
							  e.removeChild(e.lastChild);
							  rm++;
							 }
							 if(e.id.split('-').includes('0') == true)
							 {
							 i = end+1;
							 }
						 }else{i = end+1;}
						 }else{i = end+1;} 
						}
						}
						else
						{
						 if(verso == false)
						 {
						 if(rev == verso)
						 {	 
						 UPL(ori,x,y-1*(c-el-1),i);
						 }else{UPL(ori,x,y-1*(c-1*(c-el)),i);}
						 }else{
						 if(rev == verso)
						 {	 
						 UPL(ori,x,y-1*(c-1*(c-el)),i);
						 }else{UPL(ori,x,y-1*(c-el-1),i);}
						 }
						 e = document.getElementById(m1.toString()+"-"+m2.toString());
						 
						 if(e.lastChild != null)
						 {
						 if(e.children[0].id.split("")[0] == stop)
						 {						 
							 if(e.lastChild != null)
							 {
							  children.push(e.lastChild);
							  e.removeChild(e.lastChild);
							  rm++;
							 }
							 if(e.id.split('-').includes('0') == true)
							 {
							 i = end+1;
							 }
						 }else{i = end+1;}
						 }else{i = end+1;}
						}

						
					}
					
			   }
			   //pezzi che eccedono(UPL) + pz sovr
			   children = reverse(children).concat(sovr);
					
			   //+
			   if(o+1*(c-lastChs.length) <= 9)
			   { 
					end = 0;
					if(targets[targets.length-1].id.split('-').includes('9') == false)
					{
					end = 9;
					}
			 
					for (let i = 1; i <= end; i++) {

						if(ori == true)
						{
						 if(verso == false)
						 {
						 if(rev == verso)
						 {	 
						 DWR(ori,x+1*(c-1*(c-el)),y,i);
						 }else{DWR(ori,x+1*(c-el-1),y,i);}
						 }
						 else{
						 if(rev == verso)
						 {	 
						 DWR(ori,x+1*(c-el-1),y,i);
						 }else{DWR(ori,x+1*(c-1*(c-el)),y,i);}
						 }	 
						 e = document.getElementById(m1.toString()+"-"+m2.toString());
						 
						 if(e.lastChild != null)
						 {
						 if(e.children[0].id.split("")[0] == stop)
						 {						 
							 if(e.lastChild != null)
							 {
							  children.push(e.lastChild);
							  e.removeChild(e.lastChild);
							  rm++;
							 }
							 if(e.id.split('-').includes('9') == true)
							 {
							  i = end+1;
							 }
							 
						 }else{i = end+1;}		
						 }else{i = end+1;}
						}
						else
						{
						 if(verso == false)
						 {
						  if(rev == verso)
						 {	 
						  DWR(ori,x,y+1*(c-1*(c-el)),i);
						 }else{DWR(ori,x,y+1*(c-el-1),i);}
						 }
						 else{
						 if(rev == verso)
						 {	 
						  DWR(ori,x,y+1*(c-el-1),i);   
						 }else{DWR(ori,x,y+1*(c-1*(c-el)),i);}
						 }
						 e = document.getElementById(m1.toString()+"-"+m2.toString());
						 
						 if(e.lastChild != null)
						 {
						 if(e.children[0].id.split("")[0] == stop)
						 {						 
							 if(e.lastChild != null)
							 {
							  children.push(e.lastChild);
							  e.removeChild(e.lastChild);
							  rm++;
							 }
							 if(e.id.split('-').includes('9') == true)
							 {
							  i = end+1;
							 }
							 
						 }else{i = end+1;}
						 }else{i = end+1;}
						}
						
					}	
			   }
			   }
			   
			   if(verso == false)
			   {
				children = reverse(children);
			   }
			   
			   switch(rm)
			   {
					case 2:
					navi[0].style.display = "block";
					comandi[0].style.display = "block";
					for(let i=0; i< children.length;i++)
					{
					navi[0].appendChild(children[i]);
					navi[0].children[i].style.transform = "rotate(0deg)";
					}
					if(verso == false)
					{
					 navi[0].style.transform ="rotatex(135deg) rotatey(200deg) rotate(0deg)";
					}else{navi[0].style.transform = "rotatex(60deg) rotate(28deg)";}
					break;
					case 3:
					navi[1].style.display = "block";
					comandi[1].style.display = "block";
					for(let i=0; i< children.length;i++)
					{
					navi[1].appendChild(children[i]);
					navi[1].children[i].style.transform = "rotate(0deg)";
					}
					if(verso == false)
					{
					 navi[1].style.transform ="rotatex(135deg) rotatey(200deg) rotate(0deg)";
					}else{navi[1].style.transform = "rotatex(60deg) rotate(28deg)";}
					
					break;
					case 4:
					navi[2].style.display = "block";
					comandi[2].style.display = "block";
					for(let i=0; i< children.length;i++)
					{
					navi[2].appendChild(children[i]);
					navi[2].children[i].style.transform = "rotate(0deg)";
					}
					if(verso == false)
					{
					 navi[2].style.transform ="rotatex(135deg) rotatey(200deg) rotate(0deg)";
					}else{navi[2].style.transform = "rotatex(60deg) rotate(28deg)";}
					
					break;
			   }	 
		   }else{error = 0;errorMessage ="Non si capisce chi vuoi sostituire."}
		}
	}
	if(verso == false)
	{
	 navi[parseInt(data)].style.transform ="rotatex(135deg) rotatey(200deg) rotate(0deg)";
	}else{navi[parseInt(data)].style.transform = "rotatex(60deg) rotate(28deg)";}
	
	if(error == 1)
	{
	window.open('../Functions/Save.php?path=../Files/Ships.txt&add=1&player='+ player);
	
    var html = document.documentElement.innerHTML.split("</style>")[1];
    html = html.split("\x3Cscript type")[0];
    html = html.trim();

	var xhr = new XMLHttpRequest();
	xhr.open("POST", "../Functions/Save.php?player="+player+"&update="+"ok", true);
	xhr.setRequestHeader("Content-Type", "application/json");
	xhr.onreadystatechange = function(){
	if (xhr.readyState === 4 && xhr.status === 200){
	console.log(xhr.responseText);}
	};
	xhr.send(html); 
	}else if(error == -1)
	{
	window.open('../Functions/Save.php?path=../Files/Ships.txt&add=-1&player='+ player);
	}else{if(errorMessage !=''){alert(errorMessage);}navi[parseInt(data)].style.display="block";errorMessage='';}	
	
	setTimeout(function() {
    fetch('../Files/Ships.txt',{cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
    .then(response => response.text())
    .then(text =>{

	   let campo = text.split("\n")[Math.floor(player/2)];
	   let arr = campo.split('-');
	   if(arr[parseInt(player) % 2] == "9")
	   {
		   let harbor = document.getElementsByClassName("Porto")[0];
		   harbor.accessKey="ok";
		   let cAvv = document.getElementsByClassName("campo")[0];
		   let rows = cAvv.rows;
		   let tds = new Array();
		   for(let i = 0;i<rows.length;i++)
		   {
			 tds.push(rows[i].cells);
		   }
		   
		   for(let i = 1; i < tds.length;i++)
		   {
			for(let j = 0; j < tds[i].length;j++)
		    {
			 tds[i][j].id = (i-1).toString();
			 tds[i][j].outerHTML = tds[i][j].outerHTML.split('>')[0]+"onclick='verify(id,cellIndex,player);'"+"></td>";
			}      
		   }
		   gameToJson(player);
		   
           var html = document.documentElement.innerHTML.split("</style>")[1];
           html = html.split("\x3Cscript type")[0];
           html = html.trim();
	       var xhr = new XMLHttpRequest();
	       xhr.open("POST", "../Functions/Save.php?player="+player+"&update="+"ok", true);
	       xhr.setRequestHeader("Content-Type", "application/json");
	       xhr.onreadystatechange = function(){
	       if (xhr.readyState === 4 && xhr.status === 200){
	       console.log(xhr.responseText);}
	       };
	       xhr.send(html); 
	   }
      }
      );},3000);
}   
function allowDrop(ev) {
	ev.preventDefault();
}

// function find_alpha(array)
// {
//  let alpha=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];	
// } 

function hit_and_sunk(x,y)
{
 player=parseInt(player);
 let tab = document.getElementsByClassName("Campo")[0];
 let rows = tab.rows;           
 let targets= new Array();
 let cells = new Array();
 let ori='';
 let type='';
 
 if(player%2==0)
 {
  vshit = player+1;
 }else{vshit = player-1;}		 
 fetch('../Files/p'+vshit+'.txt',{cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
 .then(response => response.text())
 .then(text =>{
 let textA = text.split("");
 type=textA[3];
 ori=text.split(',')[1];
 });
 
 setTimeout(function(){
 let o=0;
 if(ori == 'false')
 {
  cells=rows[x+1].cells;
  o=y;
 }else{
 for(let i=1;i<rows.length;i++)
 {
  cells.push(rows[i][y]);
 }
 o=x; 
 }
 for(let i=0;o-i >=0;i++)
 {
  if(cells[o-i].accessKey == type)
  {
   targets.push(cells[o-i]);
  }
 }
 targets = reverse(targets);
 for(let i=1;o+i <=9;i++)
 {
  if(cells[o+i].accessKey == type)
  {
   targets.push(cells[o+i]); 
  }
 }
 
 for(let i = 0; i < targets.length; i++)
 {
   targets[i].style.backgroundImage = "";
   targets[i].style.backgroundColor = "red";
 } 
 },1000);
 setTimeout(function(){
 var html = document.documentElement.outerHTML.split("</style>")[1];
 html = html.split("\x3Cscript type")[0];
 html = html.trim();
 var xhr = new XMLHttpRequest();
 xhr.open("POST", "../Functions/Save.php?player="+player+"&update="+"ok", true);
 xhr.setRequestHeader("Content-Type", "application/json");
 xhr.onreadystatechange = function(){
 if (xhr.readyState === 4 && xhr.status === 200){
 console.log(xhr.responseText);}
 };
 xhr.send(html); 
 },5000);
}
  
function shoted()
{
 player = parseInt(player);
 let vshit=0;
 let coords = searchParam.getParam('coords');
 let x=parseInt(coords.split('-')[0]);
 let y=parseInt(coords.split('-')[1]);
 let msg = searchParam.getParam('shoted');
 if(coords != '')
 {
	 if(searchParam.getParam('error') != 'turno')
	 {	 
		let cell = getCell(x,y);
		if(msg == 'y')
		{
		 if(player%2==0)
         {
          vshit = player+1;
         }else{vshit = player-1;}
		 
         fetch('../Files/p'+vshit+'.txt',{cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
         .then(response => response.text())
         .then(text =>{
         let textA = text.split("");
         let type = textA[3];//ah ah
		 cell.style.backgroundImage = "URL(../Files/img/cross.png)";
		 cell.accessKey=type;
		 });	
		}	 
		else{
		cell.style.backgroundColor ="orange";
		}
		
		fetch('../Files/p'+player+'.txt',{cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
        .then(response => response.text())
        .then(text =>{
			
		text = text.split(",")[0];
		let textA=text.split("");
		textA.splice(textA.length-1,1);	
		text =textA.join("");
		
		let damage = document.getElementById(text);
		if(damage.style.backgroundImage =="")
		{
		damage.removeChild(damage.children[0]);
		damage.style.backgroundImage = "URL(../Files/img/Fumo.jpg)";
		}
		});

		setTimeout(function(){
        var html = document.documentElement.outerHTML.split("</style>")[1];
        html = html.split("\x3Cscript type")[0];
        html = html.trim();
	    var xhr = new XMLHttpRequest();
	    xhr.open("POST", "../Functions/Save.php?player="+player+"&update="+"ok", true);
	    xhr.setRequestHeader("Content-Type", "application/json");
	    xhr.onreadystatechange = function(){
	    if (xhr.readyState === 4 && xhr.status === 200){
	    console.log(xhr.responseText);}
	    };
	    xhr.send(html); 
		},8000);
		
		if(searchParam.getParam('sunk') == 'y')
		{
		hit_and_sunk(x,y);
		}
		
	  }else{alert("Aspetta il tuo turno!");}
 }
}

//var BNgame = new Battle_ship();
adjuste();
shoted();
</script>
<?php
//BNgame.adjuste();
//...
// echo '<script type ="text/javascript">adjuste();</script>';
// echo '<script type ="text/javascript">shoted();</script>';
echo '<script type ="text/javascript">email ="'.$email.'"</script>';

$options = [
"projection" => ['id' => 0,'Idate'=>0,'Fdate'=>0,'score'=>0]
];
$query = ["id" => $player, "Fdate" => null];
$res = $manager->executeQuery($database.'.'.$collection2, new MongoDB\Driver\Query($query,$options));
	  
foreach ($res as $document){
$row = $document;
}

$index = 0;

if(intval($player) % 2 == 0)
{
 $index = 0;	
}	
else
{
 $index = 1;
}

if(!isset($_SESSION[$row->session]))
{
 $options =[
 "projection" => ['id'=> 0,'email'=> 0,'page'=>0,'ships'=>0]
 ];
 $query = ['id' =>$player];
 $res = $manager->executeQuery($database.'.'.$collection3, new MongoDB\Driver\Query($query,$options));
 foreach ($res as $document){
 $row = $document;
 }
 if($row->ready == 1)
 {
  echo '<script type ="text/javascript">gameToJson('.$player.');</script>';
 }
}else{
 if(count($_SESSION[$row->session][$index])==0)
 {
  $options =[
  "projection" => ['id'=> 0,'email'=> 0,'page'=>0,'ships'=>0]
  ];
  $query = ['id' =>$player];
  $res = $manager->executeQuery($database.'.'.$collection3, new MongoDB\Driver\Query($query,$options));
  foreach ($res as $document){
  $row = $document;
  }
  if($row->ready == 1)
  {
	echo '<script type ="text/javascript">gameToJson('.$player.');</script>';
  }
 }
}
// echo var_dump($_SESSION[$row->session][0]);
// phpinfo();
?>
</html>