<?php
function firm()
{
 file_put_contents("./File/Privacy.txt",'f');
}

function checkfirm()
{
if (!is_dir('File')){
mkdir('File');
file_put_contents("./File/Privacy.txt",'');
echo 'Cartella creata con successo';
} 
$f = fopen("./File/Privacy.txt", "r");
 $str = "";
 while(($data = fgets($f)) !== false) {
      $str .= $data;
      }
 fclose($f);
 if($str == 'f')
 {
    return true;
 }else{
    return false;
 }

}


session_start();
$_SESSION['visible'] = true; 

if (!isset($_COOKIE['privacy']))
{
$str = 'I diritti dellʹinteressato\n'.
'In ogni momento, Lei potrà esercitare, ai sensi degli articoli dal 15 al 22 del Regolamento UE n. 2016/679, il diritto di:\n'.
'a) chiedere la conferma dell’esistenza o meno di propri dati personali;\n'.
'b) ottenere le indicazioni circa le finalità del trattamento, le categorie dei dati personali, i destinatari o le categorie di\n'.
'destinatari a cui i dati personali sono stati o saranno comunicati e, quando possibile, il periodo di conservazione;\n'.
'c) ottenere la rettifica e la cancellazione dei dati;\n'.
'd) ottenere la limitazione del trattamento;\n'.
'e) ottenere la portabilità dei dati, ossia riceverli da un titolare del trattamento, in un formato strutturato, di uso comune e\n'.
'leggibile da dispositivo automatico, e trasmetterli ad un altro titolare del trattamento senza impedimenti;\n'.
'f) opporsi al trattamento in qualsiasi momento ed anche nel caso di trattamento per finalità di marketing diretto;\n'.
'g) opporsi ad un processo decisionale automatizzato relativo alle persone fisiche, compresa la profilazione.\n'.
'h) chiedere al titolare del trattamento lʹaccesso ai dati personali e la rettifica o la cancellazione degli stessi o la limitazione\n'.
'del trattamento che lo riguardano o di opporsi al loro trattamento, oltre al diritto alla portabilità dei dati;\n'.
'i) revocare il consenso in qualsiasi momento senza pregiudicare la liceità del trattamento basata sul consenso prestato\n'.
'prima della revoca;\n'.
'j) proporre reclamo a unʹautorità di controllo.\n'.
'Può esercitare i Suoi diritti con richiesta scritta inviata a __, allʹindirizzo postale della sede legale o allʹindirizzo mail__\n'.
'Io sottoscritto/a dichiaro di aver ricevuto lʹinformativa che precede\n'.
'Luogo, lì __\n'.
'Io sottoscritto/a alla luce dellʹinformativa ricevuta\n'.
'◻esprimo il consenso ◻ NON esprimo il consenso al trattamento dei miei dati personali inclusi quelli considerati come\n'.
'categorie particolari di dati.\n'.
'◻esprimo il consenso ◻ NON esprimo il consenso alla comunicazione dei miei dati personali di enti pubblici e società di natura\n'.
'privata per le finalità indicate nellʹinformativa.\n'.
'◻esprimo il consenso ◻ NON esprimo il consenso al trattamento delle categorie particolari dei miei dati personali così come\n'.
'indicati nellʹinformativa che precede.';
$_COOKIE['privacy'] = ['testo' =>$str];
}
if(isset($_GET['firma']))
{
if($_GET['firma'] == 'y')
{
 firm();
}
}
if(checkfirm() == true)
{
 $_SESSION['visible'] = null;
 $_SESSION["Lavagna"] = "";
 header('location: ../Login.php');
}else{
  session_start();
  $_SESSION["content"] ='<a name = "Lnk_privacy" href ="#" onclick = '.'"'.'var p= document.createElement(\'p\');var b= document.createElement(\'button\');b.id =\'firma\';b.textContent=\'Firma\';p.textContent =\''.$_COOKIE['privacy']['testo'].'\''.';document.body.append(p);document.body.append(b);addEvent();"'.'>Show_privacy</a>';
  header('location: index.php');

}




?>