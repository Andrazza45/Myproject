<html>
<head>
<title>Index</title>
<script language = "javascript">
function trust()
{
window.open('cookie.php?firma=y');
window.close();
}
function addEvent()
{
	let l = document.getElementsByTagName('a');
	let b = document.getElementById('firma');
	l[0].style.display = 'none';
	b.addEventListener('click',trust);
}
</script>
</head>
<body>
<form method = "get" action = "cookie.php">
<button>Procedi</button>
<br/> 
<?php
session_start();
if(isset($_SESSION["visible"]))
{	
	$link = $_SESSION["content"];
	echo $link;
}
?>

</form>
</body>
</html>