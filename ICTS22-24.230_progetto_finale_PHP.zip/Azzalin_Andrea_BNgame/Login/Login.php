<html>
<head>
<title>Login</title>
<head>
<script language = "javascript">
function fill(id)
{
 let ol = document.getElementById(id);
 let txt = document.querySelector("input[name="+"TxtPassword"+"]");  
 txt.value = ol.textContent; 
}

function getpasswords()
{
  fetch('./Cookie/File/Credentials.txt',{cache: 'no-cache', headers: {'Cache-Control': 'no-cache'}})
  .then(response => response.text())
  .then(text =>{
  var list = document.getElementById("passwords");

  while (list.firstChild) {
   list.removeChild(list.firstChild);
  }
  var crds = text.split("\n");
  for(let i = 0; i < crds.length;i++)
  {
	  if(crds[i].split('-')[0] == "andrea.azzalin@edu.itspiemonte.it" && crds[i].split('-')[2] == "127.0.0.1:8080/Homepage.php")
	  {
		  let li = document.createElement('li');
		  li.id = "L"+i.toString();
		  li.addEventListener('click',function(){fill(this.id);});
		  li.textContent = crds[i].split('-')[1];
		  list.appendChild(li);
	  }
  }
  list.style.display = "block";
  }
  );
  
}
function showPassword() {
  var passwordInput = document.querySelector("input[name="+"TxtPassword"+"]");
  
  if (passwordInput.type === "password") {
    passwordInput.type = "text";
  } else {
    passwordInput.type = "password";
  }
}
</script>
<style language ="text/css">
body
{
max-width:1100px;
max-height:800px;
}
#email
{
 position:absolute;
 top:5px;
 left:50px;
 width:240px;
 height:20px;
}
#password
{
 position:relative;
 top:-20px;
 left:40px;
 width:100px;
 height:20px;
}
#password #passwords
{
 position:absolute;
 top:20px;
 left:0px;
 width:172px;
 height:20px;
 overflow-y:scroll;
 display:none;
 border: 2px solid;
}
#passwords li
{
 display:block;
 border: 1px solid;
}
.show
{
 position:relative;
 top:-21;
 left:155px;	 
}
</style>
<body>
<form method = "post" action = "../Services/Validazione.php?pop_up=<div id = &quot;pop-upPwd&quot; >Vuoi salvare la tua password? <button name = &quot;BtnYes&quot; onclick = &quot;saveCredential();closef();&quot;>Yes</button> <button name = &quot;BtnNo&quot; onclick = &quot;closef();&quot;>No</button> </div>
" enctype="multipart/form-data">
Email<input  id = "email"type = "text" name ="TxtUser"><br/><br/>
Pwd<div id = "password">
<input class = "All" type = "password" name ="TxtPassword" onclick = "getpasswords();">
<input type="button" class = "show" onclick="showPassword()" value='●'>
<li id = "passwords">
</li>
</div>
<br/>
<input type = "submit" value = "Submit"><br/>
<?php
session_start();
if(isset($_SESSION["Lavagna"]))
{
if($_SESSION["Lavagna"] == "ok")
{
echo $_SESSION["Correzioni"];
$_SESSION["Correzioni"] ='';
}
}
?>

</form>

</body> 
</html>