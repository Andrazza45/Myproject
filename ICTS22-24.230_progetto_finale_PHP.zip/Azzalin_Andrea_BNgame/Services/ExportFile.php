<?php
$generic ="../Games/BNgame/Files/"; 
$_FILE = $_GET["CaricaFile"];
$filew = fopen($generic.$_FILE,"r");
$str = "";
while(($data = fgets($filew)) !== false) {
$str.= $data;
}
file_put_contents("../Login/Cookie/File/Copia_Navi.txt",$str);
echo("File salvato correttamente!!");
?>