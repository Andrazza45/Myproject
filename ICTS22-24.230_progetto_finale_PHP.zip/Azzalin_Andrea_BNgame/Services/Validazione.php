<?php
 // class Validazione
 // {
	// private $username;
	// private $pwd;
	// private $users;
	// public function Validazione()
	// {
	 // $this->pwd = $_POST["TxtPassword"];
	 // $this->usr = $_POST["TxtUser"];
	 // $data = file_get_contents('../Login/cookie/File/Crypto.txt');
	 // $this->users = json_decode($data);
	// }
	
	// public function login()
	// {
	// session_start();
    // for($i = -1; $i < count($this->users);$i = $i + 2)
	// {
    // if( $errore == 0 and $this->username == $this->users[$i - 1])
    // {
		// if(MD5($this->pwd) == $this->users[$i])
		// {
		// file_put_contents("../Login/Cookie/File/session.txt",$usr.'-'.$pwd.'-'.$_SERVER['HTTP_HOST']."/Homepage.php");	
		// $_SESSION["save_pwd"] = $_GET["pop_up"];
		// $_SESSION["Msg"] = "Benvenuto nella tua homapage ".$this->username;
		// header('location: ../Games/BNgame/Interfaces/Homepage.php');	
		// }else{
	    // file_put_contents("../Login/Cookie/File/session.txt",$usr.'-'.$pwd.'-'.$_SERVER['HTTP_HOST']."/Homepage.php");	
		// $_SESSION["save_pwd"] = $_GET["pop_up"];
		 // throw new Exception('Password errata!');
		// }
		
    // }
	// }
         // throw new Exception('Utente non trovato!');
		
	// }
	
	
	// private function validateEmail() {
    // // Utilizziamo una funzione integrata di PHP per validare l'indirizzo email
    // if (!filter_var($this->username, FILTER_VALIDATE_EMAIL)) {
        // return false;
    // }
    
    // // Controlliamo l'esistenza del dominio nell'indirizzo email
    // $domain = explode('@', $this->username)[1];
    // if (!checkdnsrr($domain, 'MX')) {
        // return false;
    // }
    
    // return true;
// }
    // public function v_username()
	// {
    // if($this->validateEmail() == false)
    // {
		// $_SESSION["Lavagna"] = "ok";
		// $_SESSION["Correzioni"].= "-Email non valida\n";
        // throw new Exception('Email non valida');
    // }
	// }
	
	// public function v_password()
	// {
		// if(strlen($this->pwd) <= 4)
		// {
			// $_SESSION["Lavagna"] = "ok";
			// $_SESSION["Correzioni"].= "-Password non valida\n";
			// throw new Exception('Password non valida');
		// }
	// }
// public function save_credential($credential)
// {
 // $path = "./Cookie/File/Credentials.txt";
 // if(file_exists($path))
 // {
   // $str = ""; 
   // $fr = fopen($path,'r');
   // while(($data = fgets($fr)) !== false) {
        // $str .= $data;
   // }
   // fclose($fr);
   // file_put_contents($path,$str.$credential."\n");
	 
 // }
 // else
 // {
	 // file_put_contents($path,'');
 // }
// }
 // }
 
function save_credential($credential)
{
 $path = "../Login/Cookie/File/Credentials.txt";
 if(file_exists($path))
 {
   $str = ""; 
   $fr = fopen($path,'r');
   while(($data = fgets($fr)) !== false) {
        $str .= $data;
   }
   fclose($fr);
   file_put_contents($path,$str.$credential."\n");
	 
 }
 else
 {
	 file_put_contents($path,'');
 }
}


function validateEmail($usr){
    $regions=['au','co','com','ne','eu','it','jp','net','org','ru','uk','us'];
	$domains=['altervista','alice','biella','gmail','hotmail','itspiemonte','outlook'];
	$attr='edu';
	$count=0;
	$email = str_split($usr);
	
	if(ord($email[0])>=65 and ord($email[0])<=90)
	{return false;}

	for($i=0;$i<count($email);$i++)
	{
	 if(ord($email[$i])<35 and ord($email[$i])!=33 or ord($email[$i])>=39 and ord($email[$i])<=41 or ord($email[$i])==44 or ord($email[$i])>58 and ord($email[$i])<65 and ord($email[$i])!=63 and ord($email[$i])!=64 or ord($email[$i])>90 and ord($email[$i])<94 or ord($email[$i])>126)
	 {return false;}
 
     if(ord($email[$i])==46)
	 {
	  $count++;
	 }
	 if($count > 3)
	 {
	  return false;
	 }
	}
	$email=explode(".",$usr,32);
	if($count < 3)
	{	
     $count=0;
	 $domain = explode("@",$email[1],21)[1];
	 for($i=0;$i<count($domains);$i++)
	 {
	  if($domain == $domains[$i])
	  {
		$count++;
		$i = count($domains);
	  }
	 }
	 $region = $email[2];
	 for($i=0;$i<count($regions);$i++)
	 {
	  if($region == $regions[$i])
	  {
	   $count++;
	   $i = count($regions);
	  }
	 }
	}else{
	$count =0;
	$type=explode("@",$email[1],21)[1];

	if($type != $attr)
	{
	 return false;
	}
	$domain = $email[2];
	for($i=0;$i<count($domains);$i++)
	{
	  if($domain == $domains[$i])
	  {
		$count++;
		$i = count($domains);
	  }
	}
	$region = $email[3];
	for($i=0;$i<count($regions);$i++)
	{
	 if($region == $regions[$i])
	 {
		$count++;
		$i = count($regions);
	 }
	}
	 
	}
	if($count != 2)
	{
	 return false;
	}else{return true;}
	
	// Utilizziamo una funzione integrata di PHP per validare l'indirizzo email
    // if (!filter_var($usr, FILTER_VALIDATE_EMAIL)){
        // return false;
    // }
    
    // Controlliamo l'esistenza del dominio nell'indirizzo email
    // $domain = explode('@', $usr)[1];
    // if (!checkdnsrr($domain, 'MX')){
        // return false;
    // }
}
function Login($pwd,$usr,$_usrs)
{
    $msg = "";
    $errore = 0;
    if(strlen($pwd) <= 4 or !isset($pwd))
    {
        $errore = -1;
        $msg .= "<br/>-Lunghezza pwd errata <br/>";
    }
	
    if(validateEmail($usr) == false or !isset($usr) )
    {
        $errore = -1;
        $msg .= "<br/>-Email non valida! <br/>";
    }
	
    if($errore == -1)
    {
	 session_start();
	 $_SESSION["Lavagna"] = "ok";
	 $_SESSION["Correzioni"] = $msg;
     http_response_code (401);
	 header('location: ../Login/Login.php');
	}
	else
	{
	session_start();
	for($i = -1; $i <= count($_usrs) - 1;$i = $i + 2)
	{
		if($i > 0)
		{
			if($usr == $_usrs[$i - 1])
			{
				if(MD5($pwd) == $_usrs[$i])
				{
				//Per averla temporaneamente
				file_put_contents("../Login/Cookie/File/session.txt",$usr.'-'.$pwd.'-'.$_SERVER['HTTP_HOST']."/Homepage.php");	
				$_SESSION["save_pwd"] = $_GET["pop_up"];
				$_SESSION["Msg"] = "Benvenuto nella tua homepage ".$usr;
				header('location: ../Games/BNgame/Interfaces/Homepage.php');	
				}else{
				//Per averla temporaneamente
				file_put_contents("../Login/Cookie/File/session.txt",$usr.'-'.$pwd.'-'.$_SERVER['HTTP_HOST']."/400.php");
				$_SESSION["save_pwd"] = $_GET["pop_up"];
				$_SESSION["Msg"] = "Password Errata!";
				header('location: ../Login/400.php');	
				}
				
			}
		}
	}

	}
}

 $data = file_get_contents('../Login/cookie/File/Crypto.txt');
 $_usrs = json_decode($data);
 if(!isset($_POST["TxtPassword"]))
 {
  $pwd = null;
 }else{
       $pwd = $_POST["TxtPassword"];
      }
 		  
 if(!isset($_POST["TxtUser"]))
 {
  $usr = null;
 }else{
 $usr = $_POST["TxtUser"];
 }
 
 
 
 //$v = new Validazione();
 
 if(isset($_GET["copia"]))
 {
   unlink('../Login/Cookie/File/session.txt');
   //v->save_credential($_GET["copia"]);
   save_credential($_GET["copia"]);
   echo '<script>window.close();</script>';
   
 }
 else
 {
	 if(isset($_GET["elimina"]))
	 {
	  unlink('../Login/Cookie/File/session.txt');
	  echo '<script>window.close();</script>';
	 }
	 else
	 {
		 // try {
		 // v->v_username();
		// } catch (Exception $e) {
		 // echo printf("Errore: %s\n", $e->getMessage());
		 //http_response_code(401);
		// }

		 // try {
		 // v->v_password();
		// } catch (Exception $e) {
		 // echo printf("Errore: %s\n", $e->getMessage());
		 //http_response_code(401);

		// }
		
		//if($_SERVER['REDIRECT_STATUS'] == 401)
		//{
		//header('location: ../Login/Login.php');
	 //   }else{
		 // try {
		 // v->login();
		// }catch(Exception $e){
		   //if($e->getMessage() == "Password errata!")
		   //{
			  // $_SESSION["Msg"] = "Password Errata!";
			  // header('location: ../Login/400.php');	 
		//   }
		   //else
		   //{
			 //$_SESSION["Msg"] = "Utente non trovato!";
			 //header('location: ../Login/400.php');	
		   //}
		// }
	  //}
		Login($pwd,$usr,$_usrs);
    }
 }


//Se si vuole utilizzare db per effettuare accesso
// $conn = "localhost";
// creazione oggetto
// $myconn = mysqli_connect($conn, 'root', '', 'User');

// $query = "Select pwd, user from users where users.pwd ='$pwd' and users.user ='$usr'";
// $result1= mysqli_query($myconn, $query);
// while($row = mysqli_fetch_assoc($result1))
// {
	// if($row->usr == $usr)
	// {
	// if($row->pwd == $pwd)
	// {....}
	// }
// }
// ...
?>