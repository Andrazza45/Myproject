/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;
import Database.*;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author icts22-24.230
 */
public class Employee  {
   private int id;
   private String firstname;
   private String lastname;
   private String dob;
   private String hiredate;
   private String JobDescription;
   private int jobid;
   private float salary;
   

   public Employee(int id, String firstname, String lastname,String dob, String hiredate, String JobDescription,int jobid, float salary )
   {   
       this.id = id;
       this.firstname = firstname;
       this.lastname = lastname;
       this.dob = dob;
       this.hiredate = hiredate;
       this.JobDescription = JobDescription ;
       this.jobid = jobid;
       this.salary = salary;
   }
   public String Get_firstname()
   {
       return this.firstname;
   }
   public void Set_firstname(String name)
   {
       this.firstname = name;
   }
   public String Get_lastname()
   {
       return this.lastname;
   }
   public void Set_lastname(String name)
   {
       this.lastname = name;
   }
   public String Get_dob()
   {
       return this.dob;
   }
   public void Set_dob(String dob)
   {
       this.dob = dob;
   }
   public String Get_hiredate()
   {
       return this.hiredate;
   }
   public void Set_hiredate(String hiredate)
   {
       this.hiredate = hiredate;
   }
   @Override
   public String toString()
   {
       return "ID: "+ this.id +" Nome: "+ this.firstname+" Cognome: " + this.lastname+" Data nascita: "+this.dob+" Data prima assunzione: "+this.hiredate+" Lavoro: " +this.JobDescription+" JobID: "+ this.jobid+" Salario: "+ this.salary+" €" ;
   }
   public static void main(String args[]) throws SQLException {
       
   //Stringhe di connessione
   DatabaseInit db = new DatabaseInit();
   Connection conn = db.connectionToDb();
   String JobDescription = "programmatore";
   String query = " select e.id, e.firstname, e.lastname , e.dob, e.hire_date,j.id as jobId,j.description as JobDescription, s.salary "+
           "From employee e, job j,salary s "+
           "where j.id = e.job AND j.description = "+ "'"+JobDescription+"'"+
           " AND j.id = s.job AND s.end_date is null"+ " order by e.lastname";
   
   
   
   try
   {
   Statement stat =  conn.createStatement();
   ResultSet rs =stat.executeQuery(query);
   List<Employee> employees = new ArrayList<>();
   while(rs.next())
   {
       Employee e = new Employee(
       rs.getInt("id"),
       rs.getString("firstname"),
       rs.getString("lastname"),
       rs.getDate("dob").toString(),
       rs.getDate("hire_date").toString(),
       rs.getString("JobDescription"),
       rs.getInt("jobId"),
       rs.getFloat("salary")
       );
    System.out.println(e.toString());
    employees.add(e);
       //commment
   }
   }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+query+":"+ e.getMessage());}
   }
}
