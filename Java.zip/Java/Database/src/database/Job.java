/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

/**
 *
 * @author icts22-24.230
 */
public class Job {
    
    private int id;
    private String Descr;
    private float Salary;
    public Job(int id, String Descr, float salary)
       {
         this.id = id;
         this.Descr = Descr;
         this.Salary = salary;
       } 
    public int GetJobId()
    {
       return this.id;
    }
    public String GetDescr()
    {
       return this.Descr;
    }
        public float GetSalary()
    {
       return this.Salary;
    }
    public float SetSalary()
    {
       return this.Salary;
    }
}
