/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;
import Database.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

/**
 *
 * @author icts22-24.230
 */
public class UpdateExample //implements Employee
{   
    static int  maxid;
    static String str ="";
    public static void main(String args[]){
    DatabaseInit db = new DatabaseInit();
    Connection conn = db.connectionToDb();//apertuta connessione al db
    String query = " Select * from employee";
    String FindEmployeeMaxId = " select Max(id)as id from employee";
    String FindJobMaxId = " select Max(id)as id from job";
    String InsertEmployeeQuery = "Insert into employee(id, firstname,lastname, dob,job, hire_date)"
    + "VALUES(?,?,?,?,?,?)";
    String insertJob = "Insert into job(id,description) values (6,\"Muratore\")";
    int JobID = 6 ;
    String JobDescription = "'UX'";
    String FindJobIdByDescription = "select id from job where description ="+JobDescription;
    //insert
    try{
    Statement stat = conn.createStatement();
    ResultSet rs = stat.executeQuery(FindEmployeeMaxId);
     while(rs.next())
    {
     str = rs.getString("id");
    }
    Employee emp = new Employee(Integer.parseInt(str)+1,"Freancesca","Ferraris",LocalDate.of(1999,6,24).toString(),"2022-12-22","",22,(float)21.21);
    PreparedStatement prepStat = conn.prepareStatement(InsertEmployeeQuery);
    prepStat.setInt(1,Integer.parseInt(str)+1);
    prepStat.setString(2,emp.Get_firstname());
    prepStat.setString(3,emp.Get_lastname());
    prepStat.setString(4,emp.Get_dob());
    prepStat.setInt(5,JobID);
    prepStat.setString(6,emp.Get_hiredate());
    prepStat.executeUpdate();
    
    Statement stat1 =  conn.createStatement();
    ResultSet rs1 = stat1.executeQuery(query);//importante
    
    while(rs1.next())
    {
       String str = rs1.getInt("id")+" "+
       rs1.getString("firstname")+" "+
       rs1.getString("lastname")+" "+
       rs1.getDate("dob").toString()+" "+
       rs1.getInt("job")+" "+
       rs1.getDate("hire_date").toString();
      System.out.println(str);
    }
    }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+":"+ e.getMessage());}
    System.out.println('\n');
    
    try
    {
    Statement stat = conn.createStatement();
    ResultSet rs = stat.executeQuery(FindEmployeeMaxId);
     while(rs.next())
    {
      String str = rs.getString("id");

      System.out.println("L'id più grande è:"+str);
    }
    }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+FindEmployeeMaxId+":"+ e.getMessage());
    }
    //select
    try{
    Statement prepStat = conn.createStatement();
    ResultSet rs = prepStat.executeQuery(FindJobIdByDescription);
     str = "|";
     while(rs.next())
    {
     str += rs.getInt("id")+"|";
    }
     System.out.println(str);
    //Update
    Statement stat = conn.createStatement();
    ResultSet rs1 = stat.executeQuery(FindJobMaxId);
    
    while(rs1.next())
    {
       maxid = rs1.getInt("id");
    }
    if(maxid < JobID)
    {
    PreparedStatement prepStat2 = conn.prepareStatement(insertJob);
    prepStat2.executeUpdate();
    }
    }catch(SQLException e){System.err.println("Errore nell' esecuzione della query"+insertJob+":"+ e.getMessage());
    }
    db.closeConnection(conn);
  } 
}