
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esempio;
import java.util.Scanner;
/**
 *
 * @author andre
 */
public class Esempio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Tipi
        //byte
        byte b1; //dichiarazione
        b1 = 2; // assegno un valore
        System.out.println("La variabile bi vale:" + b1);
        byte b2 = 127; //dichiarazione e assegnazione
        //byte somma = b1 + b2  errore 23 di compatibilità lossy conversion, il numero generato è al di fuori del range accettato dal tipo byte;
        byte somma = (byte)(b1 + b2);
        int somma1 = b1 + b2;
        System.out.println("La somma vale:" + somma);
        System.out.println("La somma promossa vale:" + somma1);
        // tipo primitivo carattere 
        char a1 = 'F';//varchar tra ''
        char a2 = '\u0024';
        int i = 97;
        char a3 = (char)i;
        char acapo = '\n';
        char tab = '\t';
        System.out.println( a1+" - "+acapo+a2+"-"+tab +"-"+a3);
        //float
        //double
        float f = 7.123456f;
        double d = 7.123456d;
        float ff = f *2;
        double dd = d* 2;
        System.out.println("ff vale:"+ ff+ acapo+"dd vale"+ dd);
        //esempio circonferenza   
        String mx = "inserire val raggio:(cm)";
        char [] nome = {'M','A','R','I','O'};
        String nom = "Mario";
        String str = new String(nome); 
        float r;
        System.out.println(mx);
        Scanner tastiera = new Scanner (System.in);
        r = Float.parseFloat(tastiera.nextLine());
        float C;
        C = (float)(2 * (double)Math.PI * r);
        System.out.println("Circ vale con pi double"+ C+ "cm");
        System.out.println( nom+" - "+"Da char:"+str);
        System.out.println( str.equals(nom));
        //Lunghezza stringa: metodo lenght() --> int
        System.out.println("Stringa str è lunga"+ str.length()+"caratteri");
        //Stringa è immutabile
        String s = "ciao";
       //Posso cambiare valore stringa se re-inizializzata
       System.out.println(str.toUpperCase());
       System.out.println(str);
       
       String Cognome = "    Severio  Grazia  .";
       Cognome = Cognome.trim();
       System.out.println(Cognome);
       //Array
       char[] alfabeto1;
       char[] alfabeto2;
       //Inizializzo l'array vuoto
       alfabeto1 = new char[24];
       //Valorizzo l'array
       alfabeto1[0] = 'a';
       alfabeto1[1] = 'b';
       alfabeto1[2] = 'c';
       alfabeto1[3] = 'd';
       alfabeto1[4] = 'e';
       System.out.println(alfabeto1);
       int numeriTombola[] ={1,2,3,4,5,6,7,8,9,10}; 
       String nomi[] = {"Mario", "Luigi"};
       System.out.println(nomi[2]);
       int[][] mat ={
                     {1,2,3,4,5,6,7,8,9,10},
                     {1,2,3,4,5,6,7,8,9,10}
                    };
      }
    }   
    