/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author icts22-24.230
 */
public class Esempio1 {

    /**
     * @param args the command line arguments
     */
    public enum sett
    {LUNEDI,MARTEDI,MERCOLEDI,GIOVEDI,VENERDI,SABATO,DOMENICA;}
    public enum rosadeiventi
    {NORD,SUD,EST,OVEST,NORDEST,NORDOVEST,SUDOVEST,SUDEST;}
     public enum mesi
    {GENNAIO,FEBBRAIO,MARZO,APRILE,MAGGIO,GIUGNO,LUGLIO,AGOSTO,SETTEMBRE,OTTOBRE,NOVEMBRE,DICEMBRE;}
    private char abbreviazione;
    public char getabbreviazione()
    {
        return abbreviazione;
    }
    public static void main(String args[]) {
           System.out.print("Hello!"+"\n");
           System.out.print(sett.MARTEDI+"\n");
           for(sett s: sett.values())
           {
               System.out.println(s);
           }
           System.out.print("Verifico la presenza di un elemento all'interno di un enum --");
           sett.valueOf( "MARTEDI");
           
           System.out.println("ORDINA:"+sett.MARTEDI.ordinal());
           
           for(rosadeiventi rv: rosadeiventi.values())
           {
               System.out.println(rv);
           }
           
           
           for(mesi ms: mesi.values())
           {
                
                   
               System.out.println(ms);
           }
    }
}
