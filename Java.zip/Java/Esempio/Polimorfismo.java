/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author icts22-24.230
 */





public class Polimorfismo {

    /**
     * @param args the command line arguments
     */
    private int x;
    private float y;
    public Polimorfismo( int x, float y)
    {
        this. x  = x ;
        this.y = y;
    }
    public int Get_x()
    {
        return this.x;
    }
    public float Get_y()
    {
        return this.y;
    }
    
    public int somma()
    {
        int somma = 0;
        somma = this.x + (int)this.y;
        return somma;
    }
    
//    public  int equals( Obj a, class Polimorfismo)
//    {
//        if(a.Get_x() == this.x and a.Get_y() == this.y )
//          {return true}
//    }
    
    public static void main(String args[]) {
    Polimorfismo o = new Polimorfismo(3,5);
    System.out.print("La tua somma �: "+ (o.somma()));
    }
}
