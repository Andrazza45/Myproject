/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author icts22-24.230
 */
public class EsercizioBello {
    private String array1[] = {"Rosso", "Verde","Grigio", "Arancione", "Bianco"};
    private int array2[] = {3,3,4,7,6,4,8,5,2};
    public EsercizioBello()
    { 
    }
    public String[] Get_array1()
    {
     return array1;
    }
    public int[] Get_array2()
    {
     return array2;
    }
      public boolean find(String array[])
      {     
        boolean trovato = false;
        for (int i = 0; i < array.length;i ++)
        {
            if (array[i] == "nero")
            {
                trovato = true;
                break;
            }
           
        }
        return trovato;
      }

    public float Avg(int array [])
    {
     float media = 0;
     for (int i = 0; i < array.length;i ++)
        {
            media = (float)array[i] + media;
        }
     return media;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
               
        EsercizioBello e = new EsercizioBello(); 
        String vet1[] =  e.Get_array1();
        int vet2[] =  e.Get_array2();
        
         if (!e.find(vet1))
        {System.out.println("Trovato!!");}
        else{
            System.out.println(" Non Trovato!!");}
        
            System.out.println("La media �:"+ e.Avg(vet2));
        

        
        
        
    }
}
