/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import quadrilatero.Quadrilatero;
/**
 *
 * @author icts22-24.230
 */

public class Quadrato implements Quadrilatero{
private float x;
private float y;
public Quadrato(float x, float y)
{
    this.y = y;
    this.x = x;
}   @Override
    public float CalcoloA()
    {
        float area = this.x * this.x;
        return area;
    }
    @Override
    public float CalcoloP()
    {
        float Perimetro = this.x *4;
        return Perimetro;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        Quadrato q1 = new Quadrato(34,23);
        System.out.println("Area:" + q1.CalcoloA());
        System.out.println("Perimetro:" + q1.CalcoloP());
    }

    }

