/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.time.*;
/**
 *
 * @author icts22-24.230
 */
public class Time {

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    LocalDate date = LocalDate.now();
    LocalTime time = LocalTime.now();
    System.out.println(date.atTime(time));

    }
}
