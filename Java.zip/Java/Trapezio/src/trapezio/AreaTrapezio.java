/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trapezio;
import trapezio.Trapezio;
/**
 *
 * @author icts22-24.230
 */

public class AreaTrapezio extends Trapezio {
public AreaTrapezio(float B,float b, float h)
{
super(B,b,h);
}
@Override
public float Get_h()
{
    return h;
}
@Override
public float Get_b()
{
    return b;
}
public float Get_B()
{
    return B;
}
@Override
public float GetArea()
{
    float area = ((this.Get_b() + this.Get_B())* this.Get_h())/2;
    return area;
}
    
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    AreaTrapezio tr= new AreaTrapezio(2,3,4);
    System.out.println("Area:" + tr.GetArea());
    }
}
