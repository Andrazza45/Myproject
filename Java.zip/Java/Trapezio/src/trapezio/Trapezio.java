/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trapezio;

/**
 *
 * @author andre
 */
public abstract class Trapezio {
    protected float h;
    protected float b;
    protected float B;
    public Trapezio(float h,float b,float B)
        {
        this.h = h;    
        this.b = b;
        this.B = B;
        }
    public abstract float Get_h();

    
    public abstract float Get_b();

    public abstract float GetArea();
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

    }
}
