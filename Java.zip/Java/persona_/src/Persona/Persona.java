/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persona;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author andre
 */
public class Persona {
    private static String nome = null;
    private static String cognome = null;
    private static String Data = null;
    private static int altezza;
    private static boolean sesso = false;
    public Persona(String n, String c, String D, int h, boolean s)
    {
        this.nome = n;
        this.cognome = c;
        this.Data = D;
        this.altezza = h;
        this.sesso = s;
    }
    public String Stampa()
    {
        return "Nome: "+this.nome +" Cognome: "+this.cognome+" Data: "+this.Data+" Altezza: "+this.altezza+" Sesso: "+this.sesso;
    }
    public static void main(String args[]) {
    List<Persona> list = new ArrayList<>();
    LocalDate date1 = LocalDate.of(2004, 7, 9);
    LocalDate date2 = LocalDate.of(2004, 7, 11);
    LocalDate date3 = LocalDate.of(2009, 7, 9);
    list.add(new Persona("Mario","Rossi",date1.toString(),169, false));
    list.add(new Persona("Mario","Rossi",date2.toString(),169, false));
    list.add(new Persona("Mario","Rossi",date3.toString(),169, false));
    
    Iterator<Persona> it = list.iterator();
    while (it.hasNext()){
    Persona p = it.next();
    System.out.println(p);
     }
}
}
