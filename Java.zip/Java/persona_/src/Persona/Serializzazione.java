/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persona;
import Persona.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.text.ParseException;
import java.io.Serializable;

/**
 *
 * @author andre
 */
public class Serializzazione implements java.io.Serializable {
    

    public static void main(String args[])  throws FileNotFoundException, IOException, ClassNotFoundException,ParseException{
        List<Persona> list = new ArrayList<>();
        list.add(new Persona("Mario","Rossi","20/02/2002",169, false));
        try{
            FileOutputStream fos = new FileOutputStream(new File(Contents.PATH ,Contents.nome_file));
            ObjectOutputStream output = new ObjectOutputStream(fos);
            output.writeObject(list.get(0).Stampa());
            output.flush();
            output.close();
            
            FileInputStream fin = new FileInputStream(new File(Contents.PATH ,Contents.nome_file));
            ObjectInputStream input = new ObjectInputStream(fin);
            Object p =input.readObject();
            System.out.println(p);
            input.close();
            
        }catch(FileNotFoundException e){
        System.out.println("FileNotFoundException"+ e.getMessage());
        }catch(IOException e)
        { System.out.println("Ioexception" + e.getMessage());}
        }
       
}