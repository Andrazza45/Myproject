let data = {
	
    "Fish": {
    "trout": {},
    "salmon": {}
  },

  "Tree": {
    "Huge": {
      "sequoia": {},
      "oak": {}
    },
    "Flowering": {
        "apple tree": {},
      "magnolia": {}
    }
  }
};

const container = document.getElementById('container');
function createTree(container, data)
{
let str = "";
var UL = document.createElement('ul');
UL.style.display = "block";
for (var key1 in data) {
	str+= key1+':<br/>';
	
  if(key1 != 'Tree')
  {
  for (var key2 in data[key1]) {
    str+=key2 +':'+ data[key1][key2]+'<br/>';
  }
  str+='<br/>';
  // var lista = document.createElement('li');
  // lista.textContent = str;
  // UL.appendChild(lista);
  }
  else
  {
	    for (var key2 in data[key1]) {
			if(key1 != 'Fish')
			{
			str+= key2+':<br/>';
			for(key3 in data[key1][key2])
			{
				str+=key3 +':'+ data[key1][key2][key3]+'<br/>';
			}
			str+='<br/>';
			}
		}
		str+='<br/>';
		// var lista = document.createElement('li');
		// lista.textContent = str;
		// UL.appendChild(lista);

  }
}

console.log(str);
container.innerHTML = str;
container.append(UL);

}

createTree(container, data);