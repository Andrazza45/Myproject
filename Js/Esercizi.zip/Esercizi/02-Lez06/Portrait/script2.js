function isPortrait(h,w)
{
    return h > w;
}
console.log(isPortrait(10,20));
console.log(isPortrait(40,20));
console.log(isPortrait(10,10));


