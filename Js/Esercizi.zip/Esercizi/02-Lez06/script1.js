function trovaMax(n1,n2)
{
  let max = n1;
  if(n1 >= n2)
     max = n1;
  else
      max = n2;
  return max;
   //(a >= b) ? max = a : max = b
   //return max
}

console.log(trovaMax(2,3));
console.log(trovaMax(2,2));
console.log(trovaMax(12,2));
const h1 = document.createElement('h1');
var body =document.getElementsByTagName('body');
h1.textContent = trovaMax(12,2);
body[0].append(h1);


