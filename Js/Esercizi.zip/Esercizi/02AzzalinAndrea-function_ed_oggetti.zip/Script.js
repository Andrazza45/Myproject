console.log("Funzione");
let counter = 0;
function incrementa()
{
    console.log(counter);
    counter += 1;
    if(counter == titoli.length)
    {
        counter = titoli.length - 1;
    }
}
function decrementa()
{
    console.log(counter);
    counter -= 1;
    if(counter == -1)
    {
        counter = 0;
    }
}
const titoli = 
[
    "Pizza Margherita",
    "Pizza con fritte",
    "Pizza con funghi",
    "Pizza con patatine"
]
const foto =
[
    "Eq_it-na_pizza-margherita_sep2005_sml.jpeg"
]
const pizze =
[
    //{prezzo:function()}
    {nome:"Pizza Margherita",foto:"Eq_it-na_pizza-margherita_sep2005_sml.jpeg"},
    {nome:"Pizza con fritte",foto:""},
    {nome:"Pizza con funghi",foto:""},
    {nome:"Pizza con patatine",foto:""}
]
const BtnBack = document.getElementById("BtnBack");
const BtnFwd = document.getElementById("BtnFwd");
const spaziotitolo = document.getElementById("Titolo");
const spaziofoto = document.getElementById("foto");

function display()
{
    //spaziotitolo.textContent = pizze[counter].nome;
    spaziotitolo.textContent = titoli[counter];
    //spaziotitolo.src = pizze[counter].foto;
    spaziofoto.src = foto[counter];
}
document.body.onload = display;
BtnBack.addEventListener("click",function(){decrementa();display();});
BtnFwd.onclick = incrementa;
console.log(JSON.stringify(pizze));

