const btn = document.createElement("button");
btn.addEventListener("click",function()
{
    console.log("Hai cliccato");
	StampaMenu();
})
btn.textContent = "Stampa Menu";
document.body.append(btn);


const righe = document.getElementsByClassName("row");
for(const riga of righe)
{
 riga.innerHTML = "";
 riga.append(btn);
}

function PIZZA(nome, prezzo)
{
this.nome = nome;
this.prezzo = prezzo;
return this.nome +": "+this.prezzo+" euro";
}
let pizza1 = PIZZA("Margherita",5);
let pizza2 = PIZZA("Napoli", 6);

const menu =[];
menu.push(pizza1);
menu.push(pizza2);
function StampaMenu()
{
for(let i = 0; i < menu.length; i++)
{
    console.log(menu[i]);
}
}