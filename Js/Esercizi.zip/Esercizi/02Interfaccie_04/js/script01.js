//oggetto literal
const libro = {
titolo:"Io, robot",
prezzo:16.5,
pagine:120,
disponibile:true,
autori:['asimov'],
copertina:{
    big:'img/asimov.jpg',
    small:'thumb/asimov.jpg'
}
};

const libroJson = JSON.stringify(libro);
console.log(libroJson);
const Libro2 = JSON.parse(libroJson); 