const URL = 'http://jsonplaceholder.typicode.com/posts';
const xhr = new XMLHttpRequest();

xhr.onreadystatechange = function()
{
    console.log(xhr.readyState);
    if(xhr.readyState == 4 && xhr.status == 200)
    {
        const OGGETTO =JSON.parse(xhr.responseText);

        for(const post of OGGETTO)
        {
            const TITOLO = document.createElement('h2');
            TITOLO.textContent = post.title;
            document.body.append(TITOLO);
            console.log(post.title);

        }
    }else{console.log("Failed Request!")}
}
xhr.open('get',URL);
xhr.send();