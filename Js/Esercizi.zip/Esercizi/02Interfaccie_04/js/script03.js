fetch(URL)//promise
.then(risposta => risposta.json())
.then( risposta => {
var h2 = document.getElementsByTagName('h2');
var links = document.getElementsByTagName('a');
for(let i = 0; i < h2.length; i++)
{
	var a = document.createElement('a');
	a.textContent = " _";
	a.setAttribute('href','#');
	a.name = h2[i].textContent;
	h2[i].append(a) ;
}
var i = 0;
const UL = document.createElement('ul');
// for(let index = 0; index < risposta.length; index++)
// {
//     const element = risposta[index];
//     console.log(element.id);
// }
for(const post of risposta)
{  const ANCHOR = document.createElement('a');
   const PAR = document.createElement('li');

   ANCHOR.setAttribute('href','#'+links[i].name);

   PAR.onclick = function(){
     fetch(URL + '/'+ post.id)
    .then(res => res.json())
    .then(singolo => {

        console.log(singolo);
    })
  
   } 


    ANCHOR.textContent = post.title;

    PAR.append(ANCHOR);
    UL.append(PAR);
    i++;
}

document.body.append(UL);
//risposta.foreach(post => {
//  console.log(post.title)

//)
})