var saluto = "ciao";
let saluto2 = "Buongiorno";
const iva = 0.25;
document.getElementsByTagName('title')[0].textContent = 'Lancio del dado';
alert(saluto2);

const a  = 3;
if (a < 5 ) 
   {alert(saluto);}else{alert(saluto2);}
for (i = 0; i < 3;i ++) 
{
 alert(saluto);
}

var persona = "Mario";
document.writeln("Ciao mondo <br/>");
for (i = 0; i < 20;i ++) 
{
    document.write("Ciao "+ persona);
}
function estrai()
{
 var n;
 div = document.getElementById('Dado');
 n = Math.floor(Math.random()*(6-0)+1);
 switch(n)
 {
 case 1:
 div.style.backgroundImage ="url(Dado1.png)";
 break;
 case 2:
 div.style.backgroundImage ="url(Dado2.png)";
 break;
 case 3:
 div.style.backgroundImage ="url(Dado3.png)";
 break;
 case 4:
 div.style.backgroundImage ="url(Dado4.png)";
 break;
 case 5:
 div.style.backgroundImage ="url(Dado5.png)";
 break;
 case 6:
 div.style.backgroundImage ="url(Dado6.png)";
 break;
 }

}

'use strict';
var old = 'ancora funziona!';
let Nw = 'variabile con scope (visibilità limitata)';
const IVA = 0.22;
// IVA = 'PIPPO'; error!!
console.log(typeof old);
console.log(typeof IVA);

let b = 5;
let c = 7;
if(c > b){
	console.log("c è maggiore di b");
}else if (c == b)
{console.log("c è uguale di b");}else{
console.log("c è minore di b");
}


let d = 7;
let e = 7;  


switch(d)
{
	case 7:
	console.log("d = 7");
	break;
	
	default:
	console.log("non 7");
	break;
}
let result = (d > 7) ? 'ciao': 'hola';
console.log(result);
for(let i = 0; i <10;i++)
{
	console.log(i);
}


for(let i = 10; i >= 0;i--)
{
	console.log(i);
}


let gira = true;
while(gira)
{
	if(Math.random() > 0.8)
	{break;}
}

do{
	console.log('gira');
	gira = false;
}while(false);

let username = 'pippo';
let password = 12345;
console.log(username.toUpperCase());
if(username == 'pippo' && password == 12345)
console.log('logged');
const collezione = [];
collezione.push = 'pisolo';
collezione.push = 'eolo';
collezione.push = 'mammolo';
collezione.push = 'gongolo';
collezione.push = 'romolo';
let lunghezza = collezione.length;
for(const nano of collezione)
{console.log(nano);}
var totale;
function saluta()
{
  totale = 5;
}


function addizione(c, d)
{
  var s = c + d;
  return s;
}

saluta();
console.log(totale);
console.log(addizione(c,7));

let sottrazione = function(c,d){return c - d;}
console.log(sottrazione);

const allievi = [
["1","andre","Azza","1"],
["6","Luca","Rossi","4"],
["2","Boh","Verdi","6"],
["3","Fob","Bianchi","2"],
["4","Francesco","Spada","5"],
["5","g","Caio","23"]
]

for(const studente of allievi)
{
	let nome = studente[1];
	let cognome = studente[2];
	const DIV = document.createElement('div');
	DIV.setAttribute('class','card');
	DIV.innerHTML = '<p>'+ nome + ' ' + cognome+'</p>';

	document.body.append(DIV);
	if(studente[3] % 5 == 0){
	console.log('---');
	}
}