using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace Officina_meccanica.ConnessioneDatabase
{
    public class Database
    {
        static void Main(string []args)
        {
            Console.WriteLine("Connessione al Db MS SQL Server!");
            //accesso al DB
            SqlConnectionStringBuilder connection = new SqlConnectionStringBuilder();
            connection.DataSource = @".\localhost\Studenti,1433";//@".\MSSQLSERVER03"; dbms
            connection.UserID = "sa";
            connection.Password = "sqlserver01";
            connection.InitialCatalog = "Studenti";
            SqlConnection sqlconnection = new SqlConnection();
            sqlconnection.ConnectionString = connection.ConnectionString;
            sqlconnection.Open();
            Console.WriteLine("Connessione avvenuta con successo!!"); 
            //interrogare il database
            string sql = "select * from studenti2022";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            while(sdr.Read()){

            Console.Write(" Matricola:" + sdr.GetInt16(0)+",");
            Console.Write(" Nome:" + sdr.GetString(1)+",");
            Console.Write(" Cognome:" + sdr.GetString(2)+",");
            Console.Write(" Email:" + sdr.GetString(3)+",");
            Console.Write(" Classe:" + sdr.GetString(4)+";");
            Console.WriteLine();
            }
            //chiudo connessione
            sdr.Close();
            //visualizzare i dati estratti
        }
    }
}