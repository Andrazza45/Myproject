﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LinqEsempio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("LinqEsempio1 LinQ!");
            string[] nomi = {"Pietro","Maria","Giulia","Francesca","Laura","Pietro","Antonio","Vito","Giada","Rossella","Simone","Rosa",
            "Andrea","Mattia", "Ilaria","Alessandro" };
            int[] interi = {1,76,72,12,-1,34,27,35,34,56,45,89,98 };
            Console.WriteLine("Elenco completo");
            var query = from tutti in nomi select tutti;
            Console.WriteLine(string.Join(",", query));

            //Elenco dei nomi che iniziano con la lettera A
            var query2 = from iniziaA in nomi where iniziaA.StartsWith("A")
                         where iniziaA.Substring(0, 1).ToUpper().Equals("A")
                         select iniziaA;
            Console.WriteLine("Elenco nomi che inizia con A");
            Console.WriteLine(string.Join(",", query2));

            ////elenco dei nomi oridnato in modo ascendente 
            //var query3 = from ordinaAsc in nomi orderby ordinaAsc;
            //Console.WriteLine("Elenco nomi dei nomi ordinati in modo ASC");
            //Console.WriteLine(string.Join(",",query3));

            //elenco dei nomi che hanno lunghezza 7 caratteri, in ordine decrescente
            var query4 = from lunghezza7 in nomi
                         where lunghezza7.Length == 7
                         orderby lunghezza7 descending
                         select lunghezza7;
            Console.WriteLine("Elenco nomi ");
            Console.WriteLine(string.Join(",", query4));

            //esempio li linq su colleione di dati numerici
            var q1 = from elenco in interi select elenco;
            Console.WriteLine(string.Join(",",q1));
            Console.WriteLine();

            Console.WriteLine("Funzioni Lambda");
            Console.WriteLine($"Max:{interi.Max()}");
            Console.WriteLine($"Min:{interi.Min()}");
            //Console.WriteLine($"Min:{interi.Min(x => x >= 50)}");
            Console.WriteLine($"Count: {interi.Count()}");
            Console.WriteLine($"Min:{interi.Sum()}");
            Console.WriteLine($"Average:{interi.Average()}");

            var q2 = from elenco in interi where elenco >= 0 select elenco;
            Console.WriteLine($"Average:{q2.Average()}");
            Console.WriteLine($"Somma dei soli numeri positivi:{interi.Where(x => x>0).Sum()}");
            var q3 = interi.Where(x => x % 2 != 0).ToList();
            Console.WriteLine($"Elenco numeri dispari: {string.Join(",", q3)}");

            //Elenco numeri pari e appartenenti all'intervallo [50, 100] ordinati in senso decrescente
            var q4 = interi.Where(x => x % 2 == 0 && x >= 50 && x <= 100).OrderByDescending(x => x);
        }
 
 
    }
}
