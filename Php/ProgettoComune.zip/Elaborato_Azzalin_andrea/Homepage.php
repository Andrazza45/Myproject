<?php
// Start the session
session_start();

?>

<!-->Pagina statica </!-->
<?php
$Matricola = $_SESSION["Matricola"] ;


$myconn = mysqli_connect('localhost', 'root', '', 'comunicati');

$result1= mysqli_query($myconn, "SELECT * FROM personale WHERE Matricola = '$Matricola'");


$result1 = mysqli_fetch_assoc($result1);
$testo = "";
if(!is_null($result1["matricola"]))
{

	$testo = "Benvenuto ".$result1['nome']." ".$result1['cognome']." nella homepage";
	
	$_SESSION["Nome"] = $result1['nome'];
	
	$_SESSION["Cognome"] = $result1['cognome'];
	
	$_SESSION["Ruolo"] = $result1['ruolo'];
	
	$codsettore = $result1['codsettore'];
	$_SESSION["codsettore"] = $result1['codsettore'];

}

$result2= mysqli_query($myconn, "SELECT richiesta.matricola, richiesta.testo AS domanda, richiesta.datarichiesta, richiesta.oggetto, richiesta.codsettoredest, Count(risposta.testo) AS risp
								FROM 
									richiesta
								LEFT OUTER JOIN 
									risposta
								ON 
									richiesta.matricola = risposta.matricola AND richiesta.datarichiesta = risposta.datarichiesta
								GROUP BY
									richiesta.matricola, richiesta.testo , richiesta.datarichiesta, richiesta.oggetto, richiesta.codsettoredest
								HAVING richiesta.matricola = '$Matricola'
								ORDER BY richiesta.datarichiesta");
								
$result3 = 	mysqli_query($myconn,"select matricola, datarichiesta, oggetto,testo,codsettoredest
								  from richiesta
								  where codsettoredest = '$codsettore'");
								  

?>

<HTML>
<head>
<style type = "text/css">
#sfondo
{position:fixed;
top:0;left:0;
width:70%;
height:100%;
z-index: -1;
}

a
{
color:white;
font-size: 20px;
}

#view
{
color:red;
font-size: 20px;
}

</style>
</head>
<HEAD>
<TITLE>Homepage</TITLE>
</HEAD>
<BODY style ="background-color:grey">

<script>

function openRisposte(matricola, datarichiesta,codsettore)
{

	window.open('/Risposte.php?Matricola=' + matricola + "&DataRichiesta=" + datarichiesta +'&codsettore='+ codsettore, "Risposte", "height=400,width=400");
	
}

function openRispondi(matricola, datarichiesta)
{

	window.open('/Rispondi.php?Matricola=' + matricola + "&DataRichiesta=" + datarichiesta, "Rispondi", "height=400,width=400");
	
}

</script>

<?php

echo"<p style = \"color: white\"> $testo</p>";

?>
<br>
<img src ="communication.jpg" id = "sfondo" />
<a href="/Profilo.php"><i>Profilo</i></a>&nbsp;&nbsp;
<a href="/Richiesta.php"><i>Richiesta</i></a>
<a href="/Login.php"><i>Logout</i></a>
<br>
<br>

<?php

echo "<table border ='1' bgcolor='Grey'>";
echo "<tr>";   
echo "<th>Data richiesta</th>";
echo "<th>Oggetto</th>";
echo "<th>Testo richiesta</th>";
echo "<th>Settore destinatario</th>";
echo "<th>Risposte</th>";
echo "</tr>";

while($row = mysqli_fetch_assoc($result2))
{
	echo "<tr>";
	echo "<td>".$row['datarichiesta']."</td>";
	echo "<td>".$row['oggetto']."</td>";
	echo "<td>".$row['domanda']."</td>";
	echo "<td>".$row['codsettoredest']."</td>";
	
	if ($row['risp'] == 0)
	{ 
		echo "<td>*0</td>";
    }
	else
	{
		echo "<td>*".$row['risp']."&nbsp; <a href=\"#\" onclick=\"openRisposte('".$row['matricola']."','".$row['datarichiesta']."','".$row['codsettoredest']."');return false;\" id = \"view\"><i>Visualizza</i></a></td>";
	}
	echo "</tr>";
}	

echo "</table> <br>";

?>
<br><br>
<?php

echo "<table border ='1' bgcolor='Grey'>";
echo "<tr>";   
echo "<th>Data richiesta</th>";
echo "<th>Oggetto</th>";
echo "<th>Testo richiesta</th>";
echo "<th>Settore destinatario</th>";
echo "<th>link</th>";
echo "</tr>";

while($row = mysqli_fetch_assoc($result3))
{
	echo "<tr>";
	echo "<td>".$row['datarichiesta']."</td>";
	echo "<td>".$row['oggetto']."</td>";
	echo "<td>".$row['testo']."</td>";
	echo "<td>".$row['codsettoredest']."</td>";
	echo "<td>"."<a href=\"#\" onclick=\"openRispondi('".$row['matricola']."','".$row['datarichiesta']."');return false;\" id = \"view\"><i>Rispondi</i></a></td>";
	echo "</tr>";
}	
echo "</table> <br>";

?>



</BODY>
</HTML>