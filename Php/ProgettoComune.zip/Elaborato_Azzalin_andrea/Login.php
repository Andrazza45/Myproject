<?php
// Start the session
session_start();

$_SESSION["Matricola"] = "";

?>


<HTML>
<HEAD>
<TITLE>Login</TITLE>
</HEAD>
<BODY style="background-color: yellow;">
<H1>ACCESSO UTENTE</H1>
<FORM ACTION="Login.php" METHOD="POST" style="background-color: red;">

MATRICOLA <INPUT TYPE="TEXT" NAME="USERNAME"><BR><br>
PASSWORD <INPUT TYPE="PASSWORD" NAME="PASSWORD"><BR><br>
<INPUT TYPE="SUBMIT" NAME="ACCEDI" VALUE="ACCEDI"><BR>
</FORM>
</BODY>
</HTML>

<?php
if (isset($_POST['USERNAME'])) {
    $myconn = mysqli_connect('localhost', 'root', '', 'comunicati');
    $Matricola = $_POST['USERNAME'];
    $password = hash("md5", $_POST['PASSWORD']);
    $result= mysqli_query($myconn,"SELECT matricola, password FROM personale WHERE matricola = '$Matricola'");
    $result = mysqli_fetch_assoc($result);
    if(!is_null($result["matricola"]))
    {
        if($result["password"]== $password)
		{
			$_SESSION["Matricola"] = $Matricola;
			header('location: /homepage.php');
		}
        else
		{
			$_SESSION["Matricola"] = "";
			echo "La password è errata";
		}
    }
    else    
        echo "La matricola non è stata trovata";
}
?>
