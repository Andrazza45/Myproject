
<?php
// Start the session
session_start();
?>


<html>
 <head>
  <title>Invia una richiesta</title>
 </head>
 <body style="background-color: darkgray;">
 <div style="background-color: #EBEBEB;height:200px;margin-left: 10px;;margin-top: 5px;">
<?php


$Matricola = $_SESSION["Matricola"] ;
$Nome = $_SESSION["Nome"] ;
$Cognome = $_SESSION["Cognome"] ;
$Ruolo = $_SESSION["Ruolo"] ;
$Codsettore = $_SESSION["codsettore"] ;

echo "<p>Matricola: $Matricola</p>";
echo "<p>Nome: $Nome</p>";
echo "<p>Cognome: $Cognome</p>";
echo "<p>Ruolo: $Ruolo</p>";
echo "<p>Cod. Settore: $Codsettore</p>";
echo"<input type = \"submit\" name=\"Btnpassword\" value =\"Modifica Password\" ><br><br><br>"
?>
</div>
<br>
  <a href="/Homepage.php">
   Torna alla home page
  </a>
  
 </body>
</html>