<?php
if (isset($_POST['Reg'])) {
	
    $myconn = mysqli_connect('localhost', 'root', '', 'comunicati');
    $Matricola = $_POST['USERNAME'];
    $nome= $_POST['NOME'];
    $cognome= $_POST['COGNOME'];
    $ruolo= $_POST['RUOLO'];
    $settore= $_POST['SETTORE'];
    $password = hash("md5", $_POST['PASSWORD']);
    $result= mysqli_query($myconn,"SELECT matricola, password FROM personale WHERE matricola = '$Matricola'");
    $result = mysqli_fetch_assoc($result);
    if(is_null($result["matricola"]))
    {
        mysqli_query($myconn,"INSERT INTO personale (matricola,password,nome,cognome,ruolo,codsettore) VALUES('$Matricola','$password','$nome','$cognome','$ruolo','$settore')");
		//controlla se c'è una riga  nella tabella del personale
        if ($myconn->affected_rows == 1)
                echo "Registrazione effettuata.";
            else
                echo"C'e' stato un errore, riprovare.";
    }
    else    
        echo "E' gia' presente questo utente.";
}
?>

<HTML>
<HEAD>
<TITLE>REGISTRAZIONE</TITLE>
</HEAD>
<BODY style="background-color: yellow;">
<H1>REGISTRA UTENTE</H1>
<FORM ACTION="Registrazione.php" METHOD="POST" style="background-color: red;">

MATRICOLA <INPUT TYPE="TEXT" NAME="USERNAME"><BR><br>
PASSWORD <INPUT TYPE="PASSWORD" NAME="PASSWORD"><BR><br>
COGNOME <INPUT TYPE="TEXT" NAME="COGNOME"><BR><br>
NOME <INPUT TYPE="TEXT" NAME="NOME"><BR><br>
RUOLO <INPUT TYPE="TEXT" NAME="RUOLO"><BR><br>
SETTORE <INPUT TYPE="TEXT" NAME="SETTORE"><BR><br>

<INPUT TYPE="SUBMIT" NAME="Reg" VALUE="Registrati"><BR>
</FORM>
</BODY>
</HTML>