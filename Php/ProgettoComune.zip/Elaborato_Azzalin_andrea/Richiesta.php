<html>
 <head>
  <title>Invia una richiesta</title>
  <h4>Form di invio richieste</h4>
  <style>
  #ms
  {
width:50%;
height:50%;
  }
  </style>
  
 </head>
 <body style ="background-color:gold">

	<br><br>
  
	<form action="Richiesta.php" method ="POST" style ="background-color:red">
	Seleziona settore :<br>
	<select id = "settore" name="settore" >
	<option>(nessuna selezione)</option>
	<option>Anagrafe</option>
	<option>amministrativo</option>
	<option>Turismo</option>
	<option>Tecnico</option>
	<option>Tributi</option>
	</select>
	<br><br>
	Inserire l'oggetto:<br>
	<input type = "text" id ="oggetto" name="oggetto"><br><br><br>
	Inserire un messaggio:<br>
	<textarea id ="ms" name="ms" rows = "50"></textarea><br><br><br>
	
	<INPUT TYPE="SUBMIT" NAME="Invia" VALUE="Invia"><BR>
	
  <a href="homepage.php">
   Torna alla home page
  </a>
 </body>
</html>


<?php
// Start the session
session_start();
?>

<?php
if (isset($_POST['Invia'])) {
	
	
	$Matricola = $_SESSION["Matricola"] ;
	
	$currentDate = date('Y-m-d H:i:s');
  
	$oggetto = $_POST['oggetto'];
	
	$testo = $_POST['ms'];
	
	$settore = $_POST['settore'];
	
	
    $myconn = mysqli_connect('localhost', 'root', '', 'comunicati');
  
  
    $query = "INSERT INTO richiesta (matricola, datarichiesta, oggetto, testo, codsettoredest) VALUES ('$Matricola', '$currentDate', '$oggetto', '$testo', '$settore' )";
  
  
    $result= mysqli_query($myconn,$query);
    
 
	header('location: /homepage.php');
 
}
?>
