

<?php
// Start the session
session_start();
?>

<?php

if ($_GET)
{
	$_SESSION["mmm"] = $_GET["Matricola"];
	$_SESSION["ddd"] = $_GET["DataRichiesta"];

}


?>

<html>
 <head>
  <title>Invia una risposta</title>
  <h4>Form di invio risposta</h4>
  <style>
  #ms
  {
width:50%;
height:50%;
  }
  </style>
  
 </head>
 <body style ="background-color:gold">

	<br><br>
  
	<form action="Rispondi.php" method ="POST" style ="background-color:red">
	
	<br><br>
	
	Inserire un messaggio:<br>
	<textarea id ="ms" name="ms" rows = "50"></textarea><br><br><br>
	
	<INPUT TYPE="SUBMIT" NAME="Invia" VALUE="Invia"><BR>
	
  <a href="homepage.php">
   Torna alla home page
  </a>
 </body>
</html>


<?php


if (isset($_POST['Invia'])) {
	
	
	$Matricola = $_SESSION["mmm"];
	$DataRichiesta = $_SESSION["ddd"];
	
	
	$currentDate = date('Y-m-d H:i:s');

	
	$testo = $_POST['ms'];
	

    $myconn = mysqli_connect('localhost', 'root', '', 'comunicati');
  
  
    $query = "INSERT INTO risposta (datarisposta, testo, matricola, datarichiesta) VALUES ('$currentDate', '$testo', '$Matricola', '$DataRichiesta' )";
  
  
    $result= mysqli_query($myconn,$query);
    
	
	echo '<BUTTON onclick="window.close();">Close me.</BUTTON>';
 
}
?>
