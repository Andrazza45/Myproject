
<?php
// Start the session
session_start();
?>


<?php
$Matricola = $_GET["Matricola"] ;
$DataRichiesta = $_GET["DataRichiesta"] ;
$codsettore = $_GET["codsettore"] ;
$testo = "Benvenuto $Matricola nella homepage";
 
$myconn = mysqli_connect('localhost', 'root', '', 'comunicati');


$result= mysqli_query($myconn, "select  ric.codsettoredest,r.idrisposta, r.datarisposta,r.datarichiesta, r.testo as risposta
								from risposta as r inner join richiesta as ric 
								on r.matricola = ric.matricola and
								   r.datarichiesta = ric.datarichiesta
								where r.matricola = '$Matricola' and r.datarichiesta = '$DataRichiesta'");
?>

<html>
 <head>
  <title>Risposte</title>
 </head>
 <body>
  <?php
echo"<p style = \"color: white\"> $testo</p>";

echo"<table border ='1' bgcolor='Grey'>";
echo "<tr>";   
echo "<th>Data risposta</th>";
echo "<th>Testo Risposta</th>";
echo "<th>Settore Mittente</th>";
echo "</tr>";

while($row = mysqli_fetch_assoc($result))
{
	echo "<tr>";
	echo "<td>".$row['datarisposta']."</td>";
	echo "<td>".$row['risposta']."</td>";
	echo "<td>".$_GET['codsettore']."</td>";
	echo "</tr>";
}	

echo "</table>";
			
?>
 </body>
</html>