﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Core_PrestitiVideoteca.Models;
using Core_PrestitiVideoteca.Service;

namespace Core_PrestitiVideoteca.Controllers
{
    public class StudentiController : Controller
    {



        public IActionResult PrestitiStudenteX(string search)
        {
            RicercaXStudente r = new RicercaXStudente(search);
            return View(r); ;
        }

        //public IActionResult PrestitiFilter(string search)
        //{

        //    RicercaXStudente r1 = new RicercaXStudente(search);
        //    return View(r1);
        //}


    }
}
