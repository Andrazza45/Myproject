﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Core_PrestitiVideoteca.Models;
using Core_PrestitiVideoteca.Service;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.IO;
using Newtonsoft.Json;
using PrestitiVideoteca.Models;

namespace Core_PrestitiVideoteca.Controllers
{
    public class StudentiController : Controller
    {

        public IActionResult PrestitiStudenteX(string search, bool orderby)
        {
            
            if (search == null)
            {
                search = "Reale";
            }

            RicercaXStudente r = new RicercaXStudente(search);

            //Assegna al modello il contenuto della ricerca per poi ordinarlo al click del link
            r.Ricerca = search;
            if (orderby == false)
            { r.ordina = true; }
            else { r.ordina = false; }

            //Constants c = new Constants();
            //FileStream fw = new FileStream(c.getPath(), mode: FileMode.Open, access: FileAccess.Write);
            //BinaryFormatter bf = new BinaryFormatter();
            //try
            //{
            //    bf.Serialize(fw, r);
            //}
            //catch (Exception) { }
            //fw.Flush();
            //fw.Close();






            //if (r.ordina == true)
            //    r.List = r.List.OrderBy(r => r.Matricola).ToList();
            //else
            //{
            //    r.List = r.List.OrderByDescending(r => r.Matricola).ToList();
            //}
            return View(r);
        }
        public IActionResult Dashboard(int matricola, string nome, string cognome, string email, string classe, string pwd)
        {
            Studente s = new Studente(matricola, nome, cognome, email, classe, pwd);
            Gestionale g = new Gestionale(s);
            if (g.AddStudente(s) == 0)
            {
                return View(s);
            }
            else { return View(); }
            
        }
        public IActionResult Login(int matricola,string pwd)
        {
            Studente s = new Studente(matricola,null,null,null,null, pwd);
            Gestionale g = new Gestionale(s);
            if (g.Login(s) == 0)
            {
                return View(s);
            }
            else { return View(); }

        }
    }
}
