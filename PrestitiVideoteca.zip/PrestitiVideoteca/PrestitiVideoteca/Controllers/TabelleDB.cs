
using Core_PrestitiVideoteca.Models;
using Microsoft.AspNetCore.Mvc;

namespace Core_PrestitiVideoteca.Controllers
{
    public class TabelleDB : Controller
    {
        private static MostraPrestito prestiti = new MostraPrestito();
        private static MostraFilm films = new MostraFilm();
        public IActionResult MostraPrestito()
        {
            return View(prestiti);
        }
        public IActionResult MostraFilm()
        {

            return View(films);
        }
        public IActionResult RicercaXAttore(string search)
        {

            if (search == null)
                return View(films);
            else
            {
                Filter r = new Filter();
                r.filterA(films.getList(), search);
                return View(r);
            }
        }
        public IActionResult RicercaXTitolo(string search1)
        {
            
            if (search1 == null)
                return View(films);
            else
            {
                Filter r = new Filter();
                r.filterT(films.getList(), search1);
                return View(r);
            }
        }
    }
}