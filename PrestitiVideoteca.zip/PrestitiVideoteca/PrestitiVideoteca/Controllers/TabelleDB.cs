
using Core_PrestitiVideoteca.Models;
using Microsoft.AspNetCore.Mvc;

namespace Core_PrestitiVideoteca.Controllers
{
    public class TabelleDB : Controller
    {
        private static MostraPrestito prestiti = new MostraPrestito();
        private static MostraFilm films = new MostraFilm();
        public IActionResult MostraPrestito()
        {

            return View(prestiti);
        }
        public IActionResult MostraFilm()
        {

            return View(films);
        }
        public IActionResult RicercaXAttore()
        {

            return View(films);
        }
        public IActionResult RicercaXTitolo()
        {

            return View(films);
        }
    }
}