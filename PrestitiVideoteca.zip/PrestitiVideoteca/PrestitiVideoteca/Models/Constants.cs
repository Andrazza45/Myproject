namespace Core_PrestitiVideoteca.Models
{
    public class Constants
    {
        const string PATH = "C:/Users/andre/Desktop/PrestitiVideoteca/Files/Liste.dat";
        public string getPath()
        { return PATH; }
    }
}