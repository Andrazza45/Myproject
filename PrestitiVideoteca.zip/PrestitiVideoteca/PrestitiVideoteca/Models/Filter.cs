
using System.Collections.Generic;

namespace Core_PrestitiVideoteca.Models
{
   
    public class Filter
    {
        private List<Film> ListF = new List<Film>();
        public List<Film>  get_listf() { return this.ListF; }
        public void filterA(List<Film> p, string f)
        {
            List<Film> list = new List<Film>();
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].get_attore == f)
                {
                    list.Add(
                        new Film(
                        p[i].get_cod,
                        p[i].get_titolo,
                        p[i].get_supporto,
                        p[i].get_regista,
                        p[i].get_attore,
                        p[i].get_genere

                        ));
                }

            }
             this.ListF = list ;
        }

        public void filterT(List<Film> p, string f)
        {
            List<Film> list = new List<Film>();
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].get_titolo == f)
                {
                    list.Add(
                        new Film(
                        p[i].get_cod,
                        p[i].get_titolo,
                        p[i].get_supporto,
                        p[i].get_regista,
                        p[i].get_attore,
                        p[i].get_genere

                        ));
                }

            }
            this.ListF = list;
        }




    }
}