﻿using Core_PrestitiVideoteca.Models;
using Core_PrestitiVideoteca.Service;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace PrestitiVideoteca.Models
{
    public class Gestionale
    {
        private List<Studente> studenti= new List<Studente>();
        private Studente s = null;
        private SqlConnection sqlconnection;
        SqlDataReader sdr = null;
        public Gestionale(Studente s)
        {
            this.s = s;
            this.sqlconnection = new Connection().Open(0);
        }
        public int AddStudente(Studente s)
        {
            string sql = "select * from Studente";
            string sql1 = "insert into Studente values("+
            s.Matricola + ","+
            s.Nome + "," +
            s.Cognome + "," +
            s.Email + "," +
            s.Classe + ","+
            s.Pwd+")";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            this.sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {

                (this.studenti).Add(
                new Studente(

                !this.sdr.IsDBNull(0) ? this.sdr.GetInt32(0) : 0,
                !this.sdr.IsDBNull(1) ? this.sdr.GetString(1) : null,
                !this.sdr.IsDBNull(2) ? this.sdr.GetString(2) : null,
                !this.sdr.IsDBNull(3) ? this.sdr.GetString(3) : null,
                !this.sdr.IsDBNull(4) ? this.sdr.GetString(4) : null,
                !this.sdr.IsDBNull(5) ? this.sdr.GetString(5) : null
));
            }
                bool trovato = false;
                for (int i = 0; i < this.studenti.Count; i++)
                {
                    if (this.studenti[i].Matricola == s.Matricola)
                    {
                        trovato = true;
                        i = this.studenti.Count;
                    }
                }
                if (trovato == true)
                {
                    cmd.CommandText = sql1;
                    SqlDataReader sdr = cmd.ExecuteReader();
                    return 0;
                }
                else { return -1; }
            
            
        }
        public int Login(Studente s)
        {
            string sql = "select * from Studente";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {

                (this.studenti).Add(
                new Studente(

                !sdr.IsDBNull(0) ? sdr.GetInt32(0) : 0,
                !sdr.IsDBNull(1) ? sdr.GetString(1) : null,
                !sdr.IsDBNull(2) ? sdr.GetString(2) : null,
                !sdr.IsDBNull(3) ? sdr.GetString(3) : null,
                !sdr.IsDBNull(4) ? sdr.GetString(4) : null,
                !sdr.IsDBNull(5) ? sdr.GetString(5) : null
));

            }

            for (int i = 0; i < this.studenti.Count; i++)
            {
                if (this.studenti[i].Matricola == s.Matricola)
                {
                    if (this.studenti[i].Pwd == s.Pwd)
                    {
                        return 0;

                    }
                }
            }
            return -1;
        }


    }
}
