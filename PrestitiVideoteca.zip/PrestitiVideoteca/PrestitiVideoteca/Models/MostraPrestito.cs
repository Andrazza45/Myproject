﻿using Core_PrestitiVideoteca.Service;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Core_PrestitiVideoteca.Models
{
    public class MostraPrestito
    {


        List<Prestito> prestiti = new List<Prestito>();
        public MostraPrestito()
        { this.caricaprestiti(); }

        public void caricaprestiti()
        {
            //accesso al DB
            SqlConnection sqlconnection = new Connection().Open(0);

            string sql = "select * from Prestito";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {

                (this.prestiti).Add(
                new Prestito(

                !sdr.IsDBNull(1) ? sdr.GetInt32(1) : 0,
                sdr.GetInt32(2),
                !sdr.IsDBNull(3) ? sdr.GetDateTime(3) : System.DateTime.MinValue,
                !sdr.IsDBNull(4) ? sdr.GetDateTime(4) : System.DateTime.MinValue
));

            }
            //Mylibrary.ScriviFileOggetti(Constants.getPath(), prestiti);
        }

        public List<Prestito> getList()
        { return this.prestiti; }
    }
}
