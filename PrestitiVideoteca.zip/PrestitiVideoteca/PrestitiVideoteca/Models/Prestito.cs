﻿using System;

namespace Core_PrestitiVideoteca.Models
{
    [Serializable]
    public partial class Prestito
    {
        public int Id { get; set; }
        public int IdFilm { get; set; }
        public int Matricola { get; set; }
        public DateTime DataPrestito { get; set; }
        public DateTime DataRestituzione { get; set; }
        

        public Prestito(int IdFilm, int Matricola, DateTime DataPrestito, DateTime DataRestituzione)
        {
            this.IdFilm = Id;
            this.Matricola = Matricola;
            this.DataPrestito = DataPrestito;
            this.DataRestituzione = DataRestituzione;
        }
        public int get_id
        {
            get { return this.IdFilm; }
        }
        public int get_matricola
        {
            get { return this.Matricola; }
        }
        public DateTime get_dataP
        {
            get { return this.DataPrestito; }
        }
        public DateTime get_dataR
        {
            get { return this.DataRestituzione; }
        }
        public virtual Film IdFilmNavigation { get; set; } = null!;
        public virtual Studente MatricolaNavigation { get; set; } = null!;
    }
}
