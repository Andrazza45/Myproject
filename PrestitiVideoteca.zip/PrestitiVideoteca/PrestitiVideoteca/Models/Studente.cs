﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Core_PrestitiVideoteca.Models
{
    [Serializable]
    public partial class Studente
    {
        public int Matricola { get; set; }
        public string Nome { get; set; } = null!;
        public string Cognome { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Classe { get; set; } = null!;
        public string Pwd { get; set; } = null!;

        public Studente(int Matricola,String Nome, String Cognome,String Email,String Classe, string Pwd)
        {
            this.Matricola = Matricola;
            this.Nome = Nome;
            this.Cognome = Cognome;
            this.Email = Email;
            this.Classe = Classe;
            string input = Pwd;
            string hashedInput;
            // Creazione del provider di crittografia MD5
            using (MD5 md5 = MD5.Create())
            {
                // Calcola l'hash MD5 del testo di input
                byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Converti il risultato in una stringa esadecimale
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }

                 hashedInput = builder.ToString();
            }
            this.Pwd = hashedInput;
            Prestiti = new HashSet<Prestito>();
        }

        public virtual ICollection<Prestito> Prestiti { get; set; }//Virtual Connection
    }
}
