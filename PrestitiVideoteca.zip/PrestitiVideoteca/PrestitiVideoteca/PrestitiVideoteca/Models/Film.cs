﻿using System;
using System.Collections.Generic;

namespace Core_PrestitiVideoteca.Models
{
    [Serializable]
    public partial class Film
    {

        public int Codice { get; set; }
        public string Titolo { get; set; }
        public string Supporto { get; set; }
        public string Regista { get; set; }
        public string Attori { get; set; }
        public string Genere { get; set; }
        
        public Film(int Codice, String Titolo, String Supporto, String Regista,String Attori, String Genere)
        {
            this.Codice = Codice;
            this.Titolo = Titolo;
            this.Supporto = Supporto;
            this.Regista = Regista;
            this.Attori = Attori;
            this.Genere = Genere;
            Prestiti = new HashSet<Prestito>();
        }

        public int get_cod
        {
            get { return this.Codice; }
        }

        public string get_titolo
        {
            get { return this.Titolo; }
        }

        public string get_supporto
        {
            get { return this.Supporto; }
        }

        public string get_regista
        {
            get { return this.Regista; }
        }

        public string get_attore
        {
            get { return this.Attori; }
        }

        public string get_genere
        {
            get { return this.Genere; }
        }

        public virtual ICollection<Prestito> Prestiti { get; set; }
    }
}
