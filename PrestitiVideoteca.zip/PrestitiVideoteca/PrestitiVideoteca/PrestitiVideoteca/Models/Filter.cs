
using System.Collections.Generic;

namespace Core_PrestitiVideoteca.Models
{
    public class Filter
    {
        public List<Film> filterA(List<Film> p, string f)
        {
            List<Film> list = new List<Film>();
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].get_attore == f)
                {
                    list.Add(
                        new Film(
                        p[i].get_cod,
                        p[i].get_titolo,
                        p[i].get_supporto,
                        p[i].get_regista,
                        p[i].get_attore,
                        p[i].get_genere

                        ));
                }

            }
            return list;
        }

        public List<Film> filterT(List<Film> p, string f)
        {
            List<Film> list = new List<Film>();
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].get_titolo == f)
                {
                    list.Add(
                        new Film(
                        p[i].get_cod,
                        p[i].get_titolo,
                        p[i].get_supporto,
                        p[i].get_regista,
                        p[i].get_attore,
                        p[i].get_genere

                        ));
                }

            }
            return list;
        }




    }
}