﻿using Core_PrestitiVideoteca.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Core_PrestitiVideoteca.Models
{
    internal class Mylibrary
    {
        public static List<Prestito> LeggiFileOggetti(string PATH)
        {
            List<Prestito> lista = new List<Prestito>();
            FileStream fs = new FileStream(PATH, FileMode.Open, FileAccess.Read);
            BinaryFormatter bf = new BinaryFormatter();
            try
            {
                lista = bf.Deserialize(fs) as List<Prestito>;
            }
            catch (Exception)
            { 
            }
            fs.Close();
            return lista;
        }
        public static void ScriviFileOggetti(String PATH, List<Prestito> p)
        {
            FileStream fs = new FileStream(PATH, FileMode.Open, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, p);
            fs.Flush();
            fs.Close();
        }
        //public static void ScriviFileCSV(String PATH, List<Prestito> elenco)
        //{
        //    if (!File.Exists(PATH))
        //    {
        //        File.Create(PATH);
        //    }
        //    String txt = String.Join("\n", elenco);
        //    foreach (var item in elenco)
        //    {
        //        txt += (txt.Length != 0 ? "\n" : "") + item.ExportCSV();//non devi scrivere return
        //        StreamWriter sw = new StreamWriter(PATH);
        //        sw.WriteLine(txt);
        //        sw.Flush();
        //        sw.Close();

        //    }

        //}


        //public static List<Prestito> LeggiFileCSV(String PATH)
        //{
        //    var lista = new List<Prestito>();
        //    StreamReader sr = new StreamReader(PATH);
        //    String txt = sr.ReadToEnd();
        //    sr.Close();
        //    String[] righe = txt.Split('\n');

        //    foreach (var item in righe)
        //    {
        //        String[] dati = item.Split(';');
        //        lista.Add(
        //            new Prestito
        //            {
        //                Cod = Convert.ToInt32(dati[0]),
        //                Nome = dati[1],
        //                Desc = dati[3],
        //                prezzo = Convert.ToDouble(dati[2]),
        //                giacenza = Convert.ToInt32(dati[4])

        //            }

        //            );

        //    }
        //    return lista;

        //}
    }
}
