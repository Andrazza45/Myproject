﻿using Core_PrestitiVideoteca.Models;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Core_PrestitiVideoteca.Service
{
    public class RicercaXStudente
    {

        public RicercaXStudente(string search)
        {
            List = PrestitiStudenteX(search);
        }

        private List<Prestito> list = new List<Prestito>();
        public List<Prestito> PrestitiStudenteX(string cognome)
        {
            SqlConnectionStringBuilder connection = new SqlConnectionStringBuilder();
            connection.DataSource = @"localhost\MSSQLSERVER01";//@".\MSSQLSERVER03"; dbms
            connection.PersistSecurityInfo = true;
            connection.UserID = "sa";
            connection.Password = "sqlserver01";
            connection.InitialCatalog = "Core_PrestitiVideoteca";
            SqlConnection sqlconnection = new SqlConnection();
            sqlconnection.ConnectionString = connection.ConnectionString;
            sqlconnection.Open();
            string sql = "select * from Prestito p inner join Studente s on p.Matricola = s.Matricola where s.Cognome LIKE '" + cognome+"'";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                (this.list).Add(
            new Prestito(

                            !sdr.IsDBNull(0) ? sdr.GetInt32(0) : 0,
                            sdr.GetInt32(2),
                            !sdr.IsDBNull(3) ? sdr.GetDateTime(3) : System.DateTime.MinValue,
                            !sdr.IsDBNull(4) ? sdr.GetDateTime(4) : System.DateTime.MinValue
            ));

            }
            return this.list;
        }

        public List<Prestito> OrdinaMatricola()
        {
            List<Prestito> listord = new List<Prestito>();        
            for(int i = 0; i < this.list.Count; i ++)
            {
                listord.Add(this.list[i]);
            }
            list.OrderBy(studente => studente.Matricola);
            return listord;
        }


        public List<Prestito> List { get; set; }
        public List<Prestito> GetList()
        {
            return this.List;
        }
    }

}

