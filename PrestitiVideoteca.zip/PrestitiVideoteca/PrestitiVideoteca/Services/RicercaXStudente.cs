﻿using Core_PrestitiVideoteca.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Core_PrestitiVideoteca.Service
{
    [Serializable]
    public class RicercaXStudente
    {
        public bool ordina;
        public string json;
        public string Ricerca { get; set; }
        public RicercaXStudente(string search)
        {
            List = PrestitiStudenteX(search);
            this.json = JsonConvert.SerializeObject(this);
        }

        private List<Prestito> list = new List<Prestito>();
        public List<Prestito> PrestitiStudenteX(string cognome)
        {
            SqlConnection sqlconnection = new Connection().Open(0);
            string sql = "select * from Prestito p inner join Studente s on p.Matricola = s.Matricola where s.Cognome LIKE '%" + cognome +"'";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlconnection;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                (this.list).Add(
            new Prestito(

                            !sdr.IsDBNull(1) ? sdr.GetInt32(1) : 0,
                            sdr.GetInt32(2),
                            !sdr.IsDBNull(3) ? sdr.GetDateTime(3) : System.DateTime.MinValue,
                            !sdr.IsDBNull(4) ? sdr.GetDateTime(4) : System.DateTime.MinValue
            ));

            }
            return this.list;
        }
        public List<Prestito> OrdinaMatricola(List<Prestito> List)
        {
            if (this.ordina == true)
                List = List.OrderBy(r => r.Matricola).ToList();
            else
            {
                List = List.OrderByDescending(r => r.Matricola).ToList();
            }
            return List;
        }


        public List<Prestito> List { get; set; }
        public List<Prestito> GetList()
        {
            return this.List;
        }
    }

}

