class Salario():
    def __init__(self, bonus:float, stipendio:float):

        self.__bonus = bonus
        self.__stipendio = stipendio

    def GetBonus(self):
        return self.__bonus
    def GetStipendio(self):
        return self.__stipendio
    def SetBonus(self, bonus):
        self.__bonus = bonus
    def SetStipendio(self, stipendio):
        self.__stipendio = stipendio
    def Stipendio_annuale(self):
        StipA = self.__stipendio * 12 + self.__bonus
        return StipA
    def __str__(self):
        st = "Stipendio: "+str(self.GetStipendio())+" Bonus: "+str(self.GetBonus())
        return st
def main():
    sa = Salario(500,1500)
    print(sa)

main()
