from Funzioni import controllo_input
from random import randint, uniform
##from enum import Enum
import os
import math
def Inserisci_Alunno():
    nome = ""
    stato = ""
    nome = controllo_input(nome, "Inserisci un nome:")
    media = round(uniform(1, 10),2)

    if media < 6:
       stato = 'R'
    else:
         stato  = 'P'

    stream=open("Alunni.txt","a", encoding="utf-8")
    st = nome +" "+ str(media) +" "+ stato
    stream.write(st +"\n")
    stream.close()
def Stampa():
    st = ""
    nomefile = "Alunni.txt"
    ##lines = open('Alunni.txt', 'r').read().count("\n")
    stream=open(nomefile,"r", encoding="utf-8")
    ##for i in range(0, lines):
    st =st + stream.read()
    stream.close()
    print(st)

def Alunni():
    c = ""
    stringa = """
    I)Inserimento ALunni e scrittura su file
    L)Visualizza Alunni
    f)Fine"""

    while c != "f":
        print(stringa, "\n")
        c = controllo_input(c,"Quale operazione desideri effettuare?")
        print("\n")
        match c:
                case "I":
                         Inserisci_Alunno()
                         c = ""
                case "L":
                         Stampa()
                         c = ""
                case "f":print("fine!")
                case _: print("Errore!");c = "";
def main():
    Alunni()

main()