from Funzioni import controllo_input
#Di ogni auto si deve regisrtare marca, cilindrata, anno di immatricolazione e acquirente(l’acquirente è caratterizzato dai soli nome e cognome).
def inserimento_dati(lista):
    nome = ""
    cognome = ""
    marca = ""
    annoI = "int"
    cilindrata = "int"
    nome = controllo_input(nome,"Inserire il nome dell'acquirente:")
    cognome = controllo_input(cognome,"Inserire il cognome dell'acquirente:")
    marca = controllo_input(marca,"Inserire la marca dell'automobile:")
    annoI = controllo_input(annoI,"Inserire l'anno di immatricolazione:")
    cilindrata = controllo_input(cilindrata,"Inserire la cilindra:")
    print("\n")
    lista.append(nome)
    lista.append(cognome)
    lista.append(marca)
    lista.append(annoI)
    lista.append(cilindrata)

    return lista

def visualizza_Acquirente(lista):
    cognomi = ""
    for i in range(4,len(lista),5):
        if int(lista[i]) >= 1500:
           if i == len(lista)-1:
              cognomi = cognomi + str(lista[i - 3])+"."
           else:
                cognomi = cognomi + str(lista[i - 3])+","
    print("I cognomi degli acquirenti con cilindrata di 1500 cc sono: "+ cognomi+ "\n")

def auto_in_anno(lista):
    x = "int"
    x = controllo_input(x, "Inserisci un anno:")
    c = 0
    for i in range(3,len(lista),5):
        if lista[i] == str(x):
           c = c + 1
    print("\n","Le auto immatricolate nell'anno ",str(x)," sono: ",str(c),"\n")
def ordina(lista):
     lista1 = []
     for k in range(0,2):
         for i in range(3,len(lista),5):
             x = int(lista[i])
             for j in range(i,len(lista),5):
                 if int(lista[j]) <= x:
                    x = int(lista[j])
                    lista1.append(j)
             if len(lista1) > 1:
                scambio = lista[int(lista1[0])]
                lista[int(lista1[0])] = lista[int(lista1[1])]
                lista[int(lista1[1])] = scambio
                #1
                scambio = lista[int(lista1[0])-3]
                lista[int(lista1[0])-3] = lista[int(lista1[1])-3]
                lista[int(lista1[1])-3] = scambio
                #2
                scambio = lista[int(lista1[0])-2]
                lista[int(lista1[0])-2] = lista[int(lista1[1])-2]
                lista[int(lista1[1])-2] = scambio
                #3
                scambio = lista[int(lista1[0])-1]
                lista[int(lista1[0])-1] = lista[int(lista1[1])-1]
                lista[int(lista1[1])-1] = scambio
                #4
                scambio = lista[int(lista1[0])+1]
                lista[int(lista1[0])+1] = lista[int(lista1[1])+1]
                lista[int(lista1[1])+1] = scambio
                #5
                lista1 = []
             else:
                  lista1.remove(lista1[0])
     return lista

def stampa_elenco(lista):
    if len(lista) == 0:
       print("Non ci sono auto immatricolate!!","\n")
    else:
            lista = ordina(lista)
            k = 5
            p = 0
            t = 0
            fine = False
            lista2 = [0,1,2,4]
            print("***************AUTO IMMATRICOLATE***************","\n")
            for i in range(p, len(lista)+ 5):
                if p >= len(lista) + 5:
                   break
                if p == 0:
                   anno = lista[p + 3]
                else:
                     anno = lista[p - 2]
                print("Anno:",anno,"\n")
                lista1 = []
                n = 0
                c = 0
                for j in range(p + 3,len(lista),5):
                    if lista[j] == anno:
                       n = n + 1
                    else:
                         break
                if n > 1:
                   if j == len(lista) - 2 and n != int(len(lista)/5)-1:
                      n = n + 1
                   stop = k + (n * 5) + 5
                else:
                     if j == len(lista) - 2 and n != int(len(lista)/5)-1:
                        n = n + 1
                     else:
                          n = n + 1
                     stop = k + n * 5
                if p == 0 and n > 1:
                   stop = stop - 5
                for j in range(k, stop):

                    for h in range(0, len(lista1)):
                        c = c + 1
                        if c + int(len(lista)/5) == len(lista):
                           fine = True
                    if k == stop or fine == True:
                       break
                    lista1 = []
                    k1 = k
                    for h in range(0,5):
                        if k == k1 + 5:
                           break
                        if k-lista2[h] == 5 and t == 2:
                           lista1.append(lista[lista2[h]])
                           t = 0
                           k = k1
                           for h in range(0,5):
                               if k == k1 + 5:
                                  break
                               if k - lista2[h] == 5 and t == 3:
                                  lista1.append(lista[lista2[h]])
                                  t = 0
                                  k = k1
                                  for h in range(0,5):
                                      if k == k1 + 5:
                                         break
                                      if k - lista2[h] == 5 and t == 0:
                                         lista1.append(lista[lista2[h]])
                                         t = 0
                                         k = k1
                                         for h in range(0,5):
                                             if k - lista2[h] == 5 and t == 1:
                                                lista1.append(lista[lista2[h]])
                                                print(lista1[0],",",lista1[1],",",lista1[2],",",lista1[3],".","\n")

                                                for h in range(0,4):
                                                    lista2[h] = lista2[h] + 5
                                                k = k1 + 5
                                                p = k
                                                t = 0
                                                break

                                             else:
                                                  t = t + 1
                                                  if t != 3:
                                                     k = k + 1
                                                  else:
                                                       k = k + 2
                               else:
                                     t = t + 1
                                     if t != 3:
                                        k = k + 1
                                     else:
                                          k = k + 2
                        else:
                             t = t + 1
                             if t != 3:
                                k = k + 1
                             else:
                                  k = k + 2
            print("************************************************","\n")
def autosalone():
    lista = []
    stringa = """
    *********************************************************************
    a)Inserimento dati
    b)Visualizza cognome di acquirenti con 1500 cc o superiore
    c)Visualizza il numero totale di auto immatricolate in un certo anno
    d)Ordinare l'elenco in base all'anno di immatricolazione
    e)Stampa elenco ordinato
    f)Uscita
    *********************************************************************"""
    scelta = ""
    while scelta != "f":
           print("Programma Autosalone","\n")
           print(stringa)
           scelta = input("Che tipo di operazione desideri effettuare?")
           print("\n")

           match scelta:
                   case "a":lista = inserimento_dati(lista)
                   case "b":visualizza_Acquirente(lista)
                   case "c":auto_in_anno(lista)
                   case "d":lista = ordina(lista)
                   case "e":stampa_elenco(lista)
                   case "f":
                            print("FINE")
                            scelta = "f"
                   case _: print("ERRORE!")

def main():
    autosalone()
main()