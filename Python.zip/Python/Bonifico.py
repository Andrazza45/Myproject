from Persona import Persona
from Conto import ContoCorrente
from Funzioni import controllo_input
def Bonifico(lst,nc1, nc2, val):
    trovato1 = False
    trovato2 = False
    for i in lst:
        if i.GetNumConto() == nc1:
            c1 = i
            trovato1 = True
    for i in lst:
        if i.GetNumConto() == nc2:
            c2 = i
            trovato2 = True
    if trovato1 == True and trovato2 == True:
       ris1 = c1.Prelievo(val)
       ris2 = c2.Versamento(val)
    if ris1 == 0 and ris2 == 0:
       messaggio = "bonifico effettuato dal conto"+str(nc1)+"al conto"+str(nc2)+"di €"+str(val)
    else:
       messaggio = "bonifico non effettuato dal conto"+str(nc1)+"al conto"+str(nc2)
    return messaggio, lst

def CreaConto(lst,saldo, nomi, cognomi,i, nprop):
    j = 0
    c = ContoCorrente(saldo)
    while j < nprop:
          p = Persona(nomi[i-nprop], cognomi[i-nprop])
          c.SetProprietario(p)
          j += 1
          i += 1
    lst.append(c)
    return lst, i
def MenuVersamento(lst, nc, val):
    messaggio = ""
    trovato = False
    for i in lst:
        if i.GetNumConto() == nc:
           trovato = True
           ris = i.Versamento(val)
           break
        if ris == 0 and trovato == True:
           messaggio = "Versamento effettuato con successo di valore "+str(val)+"sul conto:"+str(nc)
        else:
             messaggio = "Valore negativo o numero conto non trovato!!"
    return messaggio, lst
def MenuPrelievo(lst, nc, val):
    messaggio = ""
    trovato = False
    for i in lst:
        if i.GetNumConto() == nc:
           trovato = True
           ris = i.Prelievo(val)
           break
        if ris == 0 and trovato == True:
           messaggio = "Prelievo effettuato con successo di valore "+str(val)+"dal conto:"+str(nc)
        else:
             messaggio ="Valore negativo o numero conto non trovato!!"
    return messaggio, lst
def StampaPersona(lst, persona):
    for i in lst:
        for x in range(0, len(i.GetProprietari())):
            if str(i.GetProprietario(x)) == persona:
               print(i)
def StampaOrdinata(lst, ordinamento):
#     match ordinamento
    match ordinamento:
          case 1:lst.sort(key = lambda x:x.GetNumConto(), reverse = True)
          case 2:lst.sort(key = lambda x:x.GetSaldo(), reverse = True)
    for i in lst:
        print(i)

###def input_nome(stringa)
##
###Creo oggetto persona
##p1 = Persona("Mario", "Rossi")
##c1 = ContoCorrente(500)
### p1.SetConto(c1)
##c1.SetProprietario(p1)
##print(c1.GetProprietario(0))
### print(p1, "Conto:", p1.GetSaldo())
##val = "float"
##val = float(controllo_input(val,"Inserisci un valore da prelevare:"))
##ris = c1.Prelievo(val)
##if ris == 0:
##   print("Prelievo effettuato!!","Nuovo saldo:", c1.GetSaldo())
##else:
##     print("Prelievo non effettuato!!!")
##
##
##val = "float"
##val = float(controllo_input(val,"Inserisci un valore da versare:"))
##ris = c1.Versamento(val)
##if ris == 0:
##   print("Versamento effettuato!!","Nuovo saldo:", c1.GetSaldo())
##else:
##     print("Versamento non effettuato!!!")
##
##p2 = Persona("Sergio","Verde")
##c2 = ContoCorrente(1500)
### p2.SetConto(c2)
##c2.SetProprietario(p2)
##
##lst = []
##lst.append(c1)
##lst.append(c2)
##print("Nuova stampa")
##for conto in lst:
##    print(conto)
##
##prel = "int"
##dest = "int"
##val = "float"
##prel = int(controllo_input(prel,"Inserisci il numero del conto da cui prelevare"))
##dest = int(controllo_input(dest,"Inserisci il numero del conto su cui versare"))
##while val == "float":
##      val = float(controllo_input(val,"Inserisci il valore del bonifico:"))
##      if val < 0:
##         print("Valore non ammesso!!")
##         val = "float"
##trovato = False
##for c in lst:
##    if c.GetNumConto() == prel:
##       conto1 = c
##       trovato = True
##trovato2 = False
##for c in lst:
##    if c.GetNumConto() == dest:
##        conto2 = c
##        trovato2 = True
##        break
##if trovato == False:
##   print("Conto",prel,"non esiste!!, bonifico annullato")
##elif trovato2 == False:
##     print("Conto",dest,"non esiste!!, bonifico annullato")
##elif trovato == True and trovato2 == True:
##     ris1 = conto1.Prelievo(val)
##     ris2 = conto2.Versamento(val)
##     if ris1 == 0 and ris2 == 0:
##        print("bonifico effettuato dal conto",str(prel),"al conto",str(dest),"di €",str(val))
##     else:
##          print("bonifico  non effettuato dal conto",str(prel),"al conto",str(dest))
##lst.sort(key = lambda x:x.GetSaldo(), reverse = True)
##for i in c1. GetProprietari():
##    print(i)

##nome = ""
##cognome = ""
##n = "int"
##saldo = "float"
##elencoconti = []
##while True:
##    saldo = float(controllo_input(saldo,"Inserire il saldo iniziale:"))
##    c3 = ContoCorrente(saldo)
##    while True:
##          nome = controllo_input(nome, "Inserisci un nome:")
##          cognome = controllo_input(cognome,"Inserisci un cognome:")
##          p3 = Persona("Mario", "Rossi")
##          p4 = Persona("Sergio","Verde")
##
##          c3.SetProprietario(p3)
##          c3.SetProprietario(p4)
##          m = "int"
##          n = int(controllo_input(n,"Vuoi inserire ancora(1.si 2.No)"))
##          if n == 2:
##             break
##          elencoconti.append(c3)
##    m = int(controllo_input("Vuoi creare un altro conto corrente?: (1.si 2.No)"))
##    if m == 2:
##       break
def main():
    lst = []
    nomi = []
    cognomi = []
    i = 0
    nc = 1
    s = "int"
    st = """
            1) Crea Conto per Persone
            2) Prelievo dal conto N.
            3) Versamento al conto N.
            4) Bonifico
            5) Stampa elenco conti di una persona
            6) Stampa elenco ordinato
            7) Fine"""
    while s != 7:
                  print(st)
                  s = "int"
                  s = int(controllo_input(s,"Quale operazione desideri effettuare?"))
                  match s:
                      case 1:
                          saldo = "float"
                          nprop = "int"
                          nome = ""
                          cognome = ""
                          ms ="Inserire il saldo del conto "+ str(nc)
                          saldo = float(controllo_input(saldo, ms))
                          nprop = int(controllo_input(nprop, "Inserire il numero di proprietari del conto:"))
                          for j in range(1, nprop + 1):
                              ms ="Inserire il nome del proprietario "+str(j) +" del conto:"
                              nome = controllo_input(nome, ms)
                              ms ="Inserire il cognome del proprietario "+str(j) +" del conto:"
                              cognome = controllo_input(cognome, ms)
                              nomi.append(nome)
                              cognomi.append(cognome)
                          lst, i = CreaConto(lst,saldo, nomi, cognomi,i, nprop)
                          nc = nc + lst[len(lst)-1].GetNumConto()
                      case 2:
                          nc = "int"
                          val = "float"
                          nc = int(controllo_input(nc, "Da quale conto corrente desideri prelevare?"))
                          val = float(controllo_input(val, "Quanto vuoi prelevare?"))
                          messaggio, lst = MenuPrelievo(lst, nc, val)
                          print(messaggio)
                      case 3:
                          nc = "int"
                          val = "float"
                          nc = int(controllo_input(nc, "Da quale conto corrente desideri versare?"))
                          val = float(controllo_input(val, "Quanto vuoi versare?"))
                          messaggio,lst = MenuVersamento(lst, nc, val)
                          print(messaggio)
                      case 4:
                          nc1 = "int"
                          nc2 = "int"
                          val = "float"
                          nc1 = int(controllo_input(nc, "Da quale conto corrente desideri prelevare?"))
                          nc2= int(controllo_input(nc, "Da quale conto corrente desideri versare?"))
                          val = float(controllo_input(val, "Quanto vuoi versare?"))
                          messaggio, lst = Bonifico(lst,nc1, nc2, val)
                          print(messaggio)
                      case 5:
                          persona =input("Inserisci il nome ed il cognome della persona(es.Carlo Bianchi) per visullizzare la lista dei conti intestati ad essa: ")
                          StampaPersona(lst, persona)
                      case 6:
                          ordinamento = "range"
                          ordinamento = int(controllo_input(ordinamento,"1.Ordina per numero di conto  2.Ordina per Saldo  3.Interrompi"))
                          if ordinamento != 3:
                             StampaOrdinata(lst, ordinamento)

                      case 7:
                          print("Programma Terminato!")
                      case _:
                          print("Errore!")


main()


