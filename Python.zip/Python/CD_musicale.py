from Funzioni import controllo_input
from random import choice

class CD_musicale:
      def __init__(self,prezzo, titolo, album, formato, durata):
          self.__titolo = titolo
          self.__album = album
          self.__formato = formato
          self.__prezzo = prezzo
          self.__durata = durata

      def GetTitolo(self):
          return self.__titolo
      def GetPrezzo(self):
          return self.__prezzo
      def GetAlbum(self):
          return self.__album
      def Getformato(self):
          return self.__formato
      def GetDurata(self):
          return self.__durata

      def SetDurata(self,durata):
          __durata = durata
      def SetTitolo(self,titolo):
          __titolo = titolo
      def SetAlbum(self,album):
          __album = album
      def SetPrezzo(self,formato):
          __prezzo = prezzo
      def Setformato(self,formato):
          __formato = formato
      def __str__(self):
            st = "prezzo:" +str(self.__prezzo)+ " " + "titolo:" + str(self.__titolo)+ " " + "album:" + str(self.__album)+ " " + "formato:" + str(self.__formato)+ " " \
            +"durata" + str(self.__durata)
            return st

# def ispeziona_oggetto():
#     CD = CD_musicale()
#     for name in CD.__dict__.keys():
#         st = name.split("_")-
#         val = getattr(CD.name)
#		  print(val[1], " = ",val)
#	  print(hasattr(obj,'__titolo'))

def Inserisci_cd(lista_CD):
    lista_f = [".mp4",".mp3",".WAW",".avi"]
    prezzo = "float"
    titolo = ""
    album = ""
    formato = choice(lista_f)
    durata = "int"
    durata = controllo_input(durata,"Inserire la durata del CD:")
    prezzo = controllo_input(prezzo,"Inserire il prezzo del CD:")
    titolo = controllo_input(titolo,"Inserire il titolo del CD:")
    album = controllo_input(album,"Inserire il nome dell'album del CD:")
    CD = CD_musicale(prezzo, titolo, album, formato, durata)
    lista_CD.append(CD)
    return lista_CD


def stampa(lista_CD):
    for i in lista_CD:
        print(i)
def main():
    lista_CD = []
    risposta = ""
    while risposta != "NO":
          risposta = controllo_input(risposta, "Vuoi inserire un nuovo CD?")
          if risposta == "SI":
             lista_CD = Inserisci_cd(lista_CD)

    stampa(lista_CD)
main()
