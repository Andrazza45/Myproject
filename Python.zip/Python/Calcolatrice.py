#Scrivere un programma che simula la calcolatrice
#prendere in input due numeri e l'operazione da eseguire(+-*/**)
print("Programma calcolatrice","\n")
ris = 0
def controllo_numerico(n):

    if n.isdigit() == True:
       n = int(n)
    else:
            print("ERRORE!")
            while True:
                        n = input("Inserisci un numero Intero:")
                        if n.isdigit() == True:
                           n = int(n)
                           break
                        else:
                             print("ERRORE!")
    return n
x = input("Inserire un numero Intero:")
x = controllo_numerico(x)
print("Scegliere il tipo di operazione che si desidera effettuare:")
stringa = """
    ****************************
    1.somma
    2.sottrazione
    3.divisione
    4.moltiplicazione
    5.potenza
    6.Riinserisci il numero
    7.fine
    ****************************"""
scelta = -1

while scelta != 0:
       print(stringa)
       scelta = input("Inserisci un opzione:")
       match scelta:
               case "1":
                   print("Operazione somma")
                   y = input("Scegliere un addendo:")
                   y = controllo_numerico(y)
                   ris = x + y
                   print(str(x)+"+"+str(y)+"="+str(ris))
               case "2":
                   print("Operazione sottrazione")
                   y = input("Scegliere un sottraendo:")
                   y = controllo_numerico(y)
                   ris = x - y
                   print(str(x)+"-"+str(y)+"="+str(ris))
               case "3":
                   print("Operazione divisione")
                   y = input("Scegliere il divisore:")
                   y =controllo_numerico(y)
                   ris = x / y
                   print(str(x)+"/"+str(y)+"="+str(ris))
               case "4":
                   print("Operazione moltiplicazione")
                   y = input("Scegliere un moltiplicatore:")
                   y = controllo_numerico(y)
                   ris = x * y
                   print(str(x)+"*"+str(y)+"="+str(ris))
               case "5":
                   print("Operazione potenza")
                   y = input("Scegliere un esponente:")
                   y = controllo_numerico(y)
                   ris = x**y
                   print(str(x)+"**"+str(y)+"="+str(ris))
               case "6":
                x = input("Riinserisci un numero su cui effettuare un operazione")
                x = controllo_numerico(x)
               case "7":
                   print("FINE")
                   scelta = 0
               case _:print("ERRORE!")

