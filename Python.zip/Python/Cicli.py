#Utilizzo del while e del for
#prendere i numeri n da tastiera e calcolare il max e termina quando si inserisce -1
numero = int(input("Inserisci un numero eppure -1 per terminare"))
contatore = 0
massimo = 0
while numero!= -1:
    contatore +=1
    if contatore == 1:
        massimo = int(numero)

    numero = int(input("Inserisci un numero eppure -1 per terminare"))

    if numero >= massimo:
            massimo = numero
    if contatore == 16:
            break #rompe il ciclo in ogni caso
print("Il numero più grande è:",massimo)
for i in range(1,6):
       #pass
       print("numero di valori di 1:", i)
else:
       print("finito il for")

lista =[2,4,6]
for i in lista:
    print("valore i = ",i)

'''Scrivere una frase più o meno lunga o a piacere
che inverte le maiuscole con le minuscole e la stampa'''

stringa = input("Inserire una frase tutta in MAIUSCOLE")
lista1 = []
ris =""
i = 0
for ch in stringa:
    lista1.append(ch)

for i in range(len(stringa)):
    if lista1[i].isupper():
        ris = ris+ stringa[i].lower()

print("La stringa in caratteri convertiti è:")
print(ris)

'''
Trovare caratteri distribuiti all'interno di un'altra stringa in modo ordinato
'''
lista2 = []
lista3 = []
str2 = input("Inserisci una stringa:")
str3 = input("Inserisci una stringa da cercare: ")
x = 0
start = 0
pos = 0
for ch in str3.strip():
    lista2.append(ch)

for ch in str2.strip():
    lista3.append(ch)

for i in range(0,len(str3)):
    for j in range(pos,len(str2)):
        if lista2[i].find(lista3[j],start) >= 0:
            pos = j
            x = x + 1
            break


if len(str3) == x:
    print("Trovato")
else:
        print("Non trovato")

