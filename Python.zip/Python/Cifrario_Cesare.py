#Cifrario di cesare
st ="""
       1. Criptazione di un mmessaggio
       2. Decriptazione di un messaggio
       3. fine
                """
scelta = -1
messaggio = input("Inserisci un messaggio:")
while scelta != 0:
      print(st)
      scelta = input("scegli un opzione:")
      match scelta:
              case "1":
                          n  = 4
                          cripto = ""
                          st1 = ""
                          for ch in messaggio:
                              codice = ord(ch) + n
                              st1 = st1 + chr(codice)
                          print("frase crittografata",st1)
              case "2":
                          if st1 == "":
                             print("Non è ancora stata crittografata")
                          else:
                                  st2 = st1
                                  st1 =""
                                  for ch in st2:
                                      codice = ord(ch) - n
                                      st1 = st1 +chr(codice)
                                  print("frase decrittografata",st1)


              case "3":
                          print("Concluso")
                          scelta = 0
              case _:     print("Errore")
