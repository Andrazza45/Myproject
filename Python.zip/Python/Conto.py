# from Persona import Persona
class ContoCorrente():
      __numconti = 0
      def __init__(self, saldo):
          self.__saldo = saldo
          ContoCorrente.__numconti += 1
          self.__numconto = ContoCorrente.__numconti
          self.__movim = []
#           self.__proprietario = None
          self.__proprietari = []
      def GetSaldo(self):
          return self.__saldo
      def SetSaldo(self,saldo):
          self.__saldo = saldo

      def GetNumConto(self):
          return self.__numconto

      def GetProprietario(self,x):
          return self.__proprietari[x]
      def GetProprietari(self):
          return self.__proprietari
      def SetProprietario(self, proprietario):
          self.__proprietari.append(proprietario)
      def Prelievo(self, op):
          """
          Prelievo dal conto di valore op; restituisce -1 se op è negativo;restituisce 0 se è positivo
             """
          if op < 0:
             return -1
          else:
               self.__saldo -= op
               self.__movim.append("Prelievo:"+str(op))
               return 0
      def Versamento(self, op):
            if op < 0:
               return -1
            else:
               self.__saldo += op
               self.__movim.append("Versamento:"+str(op))
               return 0
      def __str__(self):
         st = "Conto corrente N." + str(self.__numconto)+"\n Saldo: "+str(self.__saldo)+"\n"
##       st += "\n".join(str(m))
         for m in self.__movim:
             st = st + m + "\n"
         return st