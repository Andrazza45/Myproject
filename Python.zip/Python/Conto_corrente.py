from Funzioni import controllo_input

def stampa_saldo(saldo):
    print("SALDO DISPONIBILE:",saldo,"€","\n")

def prelievo(saldo, lista):
    movimento = "Prelievo"
    print("PRELIEVO","\n")
    valore = "float"
    conferma = ""
    while True:
          valore = float(controllo_input(valore,"Quanti soldi vuoi prelevare dal tuo conto corrente?"))
          if valore < 0:
             print("Valore errato! L'importo non può essere negativo")
          else:
               if saldo < valore:
                  while conferma != "s" or conferma != "n":
                        conferma =input(" Il prelievo che stai effettuando è superiore al saldo; \n Lo sconfinamento del saldo richiede interessi del 20% \n Sei sicuro di voler svolgere l'operazione (s = SI, n = NO)")
                        if conferma == "s" or conferma == "n":
                           break

                  if conferma == "s":
                     saldo = saldo - valore -(valore * 20)/100
                     print("Prelevamento effettuato!! Nuovo saldo aggiornato: "+str(saldo)+"€","\n")
                     break
                  else:
                       print("Prelevamento Annullato!! Saldo invariato: "+str(saldo)+"€","\n")
                       break
               else:
                    saldo = saldo - valore
                    print("Prelevamento effettuato!! Nuovo saldo aggiornato: "+str(saldo)+"€","\n")
                    break
    lista[0] = "Prelievo"
    lista[1] = valore
    return saldo, lista

def versamento(saldo, lista):
    movimento = "Versamento"
    print("OPERAZIONE DI VERSAMENTO","\n")
    valore = "float"
    while True:
          valore = float(controllo_input(valore,"Quanti euro vuoi versare sul conto corrente?"))
          if valore < 0:
             print("Valore errato! L'importo non può essere negativo")
          else:
               saldo = saldo + valore
               break

    print("Versamento effettuato!! Nuovo saldo aggiornato: "+str(saldo)+"€","\n")
    lista[0] = "Versamento"
    lista[1] = valore
    return saldo, lista
def ultimo_movimento(lista):
    print("STAMPA ULTIMO MOVIMENTO","\n")
    if lista[0] != "a":
       print(lista[0]+" Valore = "+str(lista[1])+"€"+"\n")
    else:
         print("Non hai ancora effettuato movimenti!!")


def Conto_corrente():
    saldo = 0
    lista = ["a","b"]
    stringa = """
    ***************************************
    *           CONTO CORRENTE            *
    ***************************************

    ***************************************
    *       Menù utente principale        *
    ***************************************
    *    1.Saldo                          *
    *    2.Prelievo                       *
    *    3.Versamento                     *
    *    4.Stampa ultimo movimento        *
    *    5.=====>Uscita                   *
    ***************************************
    Inserire scelta(1, 2, 3, 4 oppure 5):
    """
    scelta = -1
    while scelta != 0:
           print("Programma Conto Corrente","\n")
           print(stringa)
           scelta = input("Che tipo di operazione desideri effettuare?")
           print("\n")
           match scelta:
                   case "1":stampa_saldo(saldo)

                   case "2":saldo, lista = prelievo(saldo, lista)

                   case "3":saldo, lista = versamento(saldo, lista)

                   case "4":ultimo_movimento(lista)

                   case "5":print("FINE!");scelta = 0;


                   case _: print("ERRORE!")
def main():
    Conto_corrente()
main()