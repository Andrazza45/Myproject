#valuta
"""
Scrivere un programma che cambia valuta, da euro a dollari e da euro a lire;cercare il cambio su internet
calcolare
1)Input in lire e conversione in euro
2)Input in euro e conversione in lire e dollari
3)Input in dollari e conversione in euro e lire
1 euro =1936.27 lire
1 euro =1.033 dollari
"""
from Funzioni import controllo_input
import math
euro_lira = 1936.27
euro_dollaro = 1.033
euro = "float"
dollaro = "float"
lira = "float"
print("Conversione valuta euro_dollaro e euro_lire")
euro = controllo_input(euro, "Inserire valuta in euro:")
valuta_convertita = round(euro *euro_dollaro,2)
print("La valuta convertita in euro_dollari è :",valuta_convertita,"$")
valuta_convertita = round(euro *euro_lira,2)
print("La valuta convertita in euro_lire è :",valuta_convertita,"lire")

print("Conversione valuta dollaro_euro e dollaro_lire")
dollaro = controllo_input(dollaro, "Inserire valuta in dollari:")
valuta_convertita = round(dollaro /euro_dollaro,2)
print("La valuta convertita in dollaro_euro è :",valuta_convertita,"€")
valuta_convertita = round(dollaro /euro_lira * euro_dollaro,2)
print("La valuta convertita in dollaro_lire è :",valuta_convertita,"lire")

print("Conversione valuta lire_euro")
lira = controllo_input(lira, "Inserire valuta in lire:")
valuta_convertita = round(lira/euro_lira,2)
print("La valuta convertita in lire_euro è :",valuta_convertita,"euro")

