
from datetime import date
oggi = date.today()
print("data di oggi:",oggi)
anno = oggi.year
mese = oggi.month
giorno = oggi.day
print("anno: ",anno)
data = date(2021,11,25)
print(data)
print(data.strftime("%d/%m/%Y %H:%M:%S"))
print(oggi-data)
import calendar
print(calendar.calendar(11255))

# #data una scadenza calcolare quanti giorni mancano al compleanno preso in input come giorno e mese
# #data una scadenza calcolare quanto manca in giorni ore e minuti
# print("Inserire la propria data di nascita:","\n",end = "")
# mese=int(input("Inserire il mese di nascita"))
# giorno=input(("Inserire il giorno di nascita"))
#
# mese_attuale = int (oggi.month)
# giorno_attuale = int (oggi.day)
#
# if mese < mese_attuale:
# 	anno = oggi.year + 1
#
# if mese > mese_attuale:
#     anno = oggi.year
#
# if mese == mese_attuale:
#     if giorno < giorno_attuale:
# 	     anno = oggi.year + 1
#
#     else:
# 		   anno = oggi.year
#
# comp = date(mese,giorno)
# if anno == oggi.year:
#     ris = oggi - comp
#     ris = oggi.days
# else:
#     ris = comp- oggi
#     ris = oggi.days


    ################
scadenza = int(input("Inserire quanti mm mancano alla scadenza"))

minuti = scadenza%60
ore = scadenza //60
giorni = ore//24
ore = ore - (giorni*24)

print("restano ancora giorni{} ore{} minuti{}".format(giorni,ore,minuti))