class dipendente():
      def __init__(self, nome, indirizzo, sesso):
          self.__nome = nome
          self.__indirizzo = indirizzo
          self.__sesso = sesso
      def GetNome(self):
          return self.__sesso
      def GetIndirizzo(self):
          return self.__indirizzo
      def GetSesso(self):
          return self.__sesso

      def SetNome(self, nome):
          self.__nome = nome
      def SetIndirizzo(self, indirizzo):
          self.__indirizzo = indirizzo
      def SetSesso(self, sesso):
          self.__sesso = sesso

      def __str__(self):
          return "Nome: "+self.__nome+" Indirizo: "+self.__indirizzo+" Sesso: "+self.__sesso



class Impiegato(dipendente):
      def __init__(self, ufficio, nome, indirizzo,sesso):
          super().__init__(nome, indirizzo, sesso)
          self.__ufficio = ufficio
          def GetUfficio(self):
              return self.__ufficio
          def SetUfficio(self, ufficio):
              self.__uffico = ufficio
          def __str__(self):
              return super().__str__()+" Ufficio:"+str(self.__ufficio)

class Docente(dipendente):
      def __init__(self, disciplina, ruolo, nome, indirizzo, sesso):
          super().__init__(nome, indirizzo, sesso)
          self.__disciplina = disciplina
          self.__ruolo = ruolo

      def GetDisciplina(self):
          return __disciplina
      def SetDisciplina(self, disciplina):
          self.__disciplina = disciplina

      def GetRuolo(self):
          return self.__ruolo
      def SetRuolo(self, ruolo):
          self.__ruolo = ruolo
      def __str__(self):
          return super().__str__()+" Disciplina: "+self.__disciplina+" Ruolo: "+self.__ruolo


