#Rettangolo
print("*"*20)
print(("*"+" "*18 +"*\n")*5,end ="")
print("*"*20)
#Freccia su
print("Disegno una freccia rivolta verso l'alto"+"\n"+ "\n",end = "")
print("    *    ")
print("   "+"*"+" "+"*","\n",end="")
print("  "+"*"+"   "+"*","\n",end="")
print(" "+"*"+"     "+"*","\n",end="")
print(""+"*"+"**   "+"***","\n",end="")
print(("  *"+" "*3 +"*"+"\n")*5,end ="")
print("  *"+"***" +"*"+"\n",end ="")

