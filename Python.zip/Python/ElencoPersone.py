" creare un elenco di persone e fare un ordinamento"
"""
persona={"nome":"....","cognome":"...","sesso":"....","data":"..."}

elenco=[
    persona1,
    persona2,
    persona3,
    .....
    personan
    ]
"""
from random import randint,choice
from datetime import date
nomi=['marco','valerio','antonio','sergio','carlo','maria']
cognomi=['rossi','verdi','gialli','marrone','daniele','flavia']
sessi=['M','M','M','M','M','F']

def caricadati():
    elenco=[]
    for i in range(len(nomi)):
        persona={}
        nome=nomi[i]
        cognome=cognomi[i]
        sesso=sessi[i] #input("inserisci sesso M/F: ")
         #data=input("inserisci data: ")
        data=date(randint(1950,2000),randint(1,12),randint(1,28))
        persona['nome']=nome
        persona['cognome']=cognome
        persona['sesso']=sesso
        persona['data']=str(data)
        elenco.append(persona)
    return elenco

def stampadiz(elenco):
    print("Stampa dizionario elenco persone")
    for p in elenco:
        for key in p:
            print(p[key],end="\t")
        print("\n")    
        #print(p)
        
def ordinaper(elenco,parametro):
    import operator
    elenco.sort(key=operator.itemgetter(parametro))

def ordinaper_2(elenco,parametro):
    elenco.sort(key=lambda cognome:cognome[parametro])
    
def main():
    ele=caricadati()
    #print(ele)
    stampadiz(ele)
    ordinaper(ele,"nome")
    stampadiz(ele)
    ordinaper(ele,"cognome")
    stampadiz(ele)
    ordinaper_2(ele,"data")
    stampadiz(ele)

    
main()