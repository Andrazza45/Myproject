from Funzioni import controllo_input
from datetime import datetime
import math
def inserimento_articolo(scontrino):
    riga = {}
    nome = ""
    prezzo = "float"
    quantità = "int"
    nome = controllo_input(nome,"Inserimento del nome dell'articolo:")
    prezzo =  round(controllo_input(prezzo, "Inserire il prezzo dell'articolo:"),2)
    quantità = int(controllo_input(quantità,"Quantità:"))
    riga['nome'] = nome
    riga['prezzo'] = prezzo
    riga['quantità'] = quantità
    riga['totale'] = prezzo * quantità
    scontrino.append(riga)
    return scontrino

def applica_sconto(scontrino, newscontrino):
    newscontrino = []
##    print(id(scontrino))
##    print(id(newscontrino))

    for p in scontrino:
        riga = {}
        riga['nome'] = p["nome"]
        riga['prezzo'] = p["prezzo"]
        riga['quantità'] = p["quantità"]
        riga['totale_scontato'] = p["prezzo"] * p["quantità"]
        newscontrino.append(riga)

    for p in newscontrino:
        for key in p:
            if key == "totale_scontato":
               if p[key] >= 50:
                  p[key] = p[key] - (p[key]/100 *10)

               if p["quantità"] > 5:
                  p[key] = p[key] - (p[key]/100 *5)

    return newscontrino
def totale_articoli(scontrino):
    totale = 0
    for p in scontrino:
        for key in p:
            if key == "quantità":
               totale = totale + p[key]
    return totale
def totale_sconti(newscontrino,scontrino):
    n = 0
    start = 0
    for p in scontrino:
        for p1 in range (start,len(newscontrino)):
            for key in newscontrino[p1]:
                if key == "totale_scontato":
                   if p["totale"] != newscontrino[p1].get(key):
                      n = n + 1
            start = start + 1
            break
    return n

def ordina(newscontrino):
    import operator
    tipo = "range"
    tipo = int(controllo_input(tipo,"1 = \"ordina per nome\"; 2 = \"ordina per prezzo\";3 = \"ordina per quantità\" "))
    print("\n")
    match tipo:
               case 1:parametro = "nome"
               case 2:parametro = "prezzo"
               case 3:parametro = "quantità"

    newscontrino.sort(key=operator.itemgetter(parametro))
    return newscontrino

def stampa_scontrino(scontrino,newscontrino, tipo):
    tot = 0
    if tipo == "a":
       print("Scontrino:")
       now = datetime.today().strftime("%d-%m-%Y %H:%M:%S")
       print("Data:" + str(now),"\n")
       for p in scontrino:
           for key in p:
               print("{:<15}".format(key),end="\t")
           print("\n")
           break
       for p in scontrino:
           for key in p:
               if key == "nome":
                  print("{:.<15}".format(p[key]),end="\t")
               elif key == "prezzo":
                    print("{:<15}".format(p[key]),end="\t")
               elif key == "quantità":
                    print("{:<15}".format(p[key]),end="\t")
               else:
                    print("{:<15}".format(round(p[key],2)),end="\t")
                    tot = tot + p[key]
           print("\n")

       print("{:.>49}".format("totale scontrino:"),'{:,}'.format(round(tot,2)).replace(',', '˙'))
    elif tipo == "b":
         newscontrino = applica_sconto(scontrino,newscontrino)
         print("Scontrino:")
         now = datetime.today().strftime("%d-%m-%Y %H:%M:%S")
         print("Data:" + str(now),"\n")
         for p in newscontrino:
             for key in p:
                 print("{:<15}".format(key),end="\t")
             print("\n")
             break
         for p in newscontrino:
             for key in p:
                 if key == "nome":
                    print("{:.<15}".format(p[key]),end="\t")
                 elif key == "prezzo":
                      print("{:<15}".format(p[key]),end="\t")
                 elif key == "quantità":
                      print("{:<15}".format(p[key]),end="\t")
                 else:
                      print("{:<15}".format(round(p[key],2)),end="\t")
                      tot = tot + p[key]
             print("\n")
         print("{:.>49}".format("totale scontrino:"),'{:,}'.format(round(tot,2)).replace(',', '˙'))
    else:
         print("Come desideri ordinare lo scontrino?","\n")
         newscontrino = ordina(newscontrino)
         print("Scontrino:")
         now = datetime.today().strftime("%d-%m-%Y %H:%M:%S")
         print("Data:" + str(now),"\n")
         for p in newscontrino:
             for key in p:
                 print("{:<15}".format(key),end="\t")
             print("\n")
             break
         for p in newscontrino:
             for key in p:
                 if key == "nome":
                    print("{:.<15}".format(p[key]),end="\t")
                 elif key == "prezzo":
                      print("{:<15}".format(p[key]),end="\t")
                 elif key == "quantità":
                      print("{:<15}".format(p[key]),end="\t")
                 else:
                      print("{:<15}".format(round(p[key],2)),end="\t")
                      tot = tot + p[key]

             print("\n")
         print("{:.>49}".format("totale scontrino:"),'{:,}'.format(round(tot,2)).replace(',', '˙'))
    return scontrino, newscontrino

def Emissione_scontrino():
    scontrino = []
    newscontrino = []
    totale = 0
    totsc = 0
    tipo = ""
    print("Programma Emissione Scontrino","\n")
    stringa = """
1) Inserimento articolo
2) Totale Articoli venduti
3) Totale degli sconti effettuati
4) Stampa scontrino senza sconto
5) Stampa scontrino con lo sconto
6) Stampa scontrino con sconto ordinato per prezzo o per quantità a scelta
7) Fine """
    c = "int"
    while c != 0:
          print(stringa)
          c = controllo_input(c,"Quale operazione desideri effettuare?")
          print("\n")
          match int(c):
                  case 1:scontrino = inserimento_articolo(scontrino); c = "int";
                  case 2:
                         totale = totale_articoli(scontrino)
                         print("Il totale di articoli nel carrello sono:",totale)
                         c = "int"
                  case 3:
                         totsc = totale_sconti(newscontrino,scontrino)
                         print("Il totale di articoli scontati nel carrello sono:",totsc)
                         c = "int"
                  case 4:
                         if len(scontrino) != 0:
                            tipo = "a"; scontrino, newscontrino = stampa_scontrino(scontrino,newscontrino,tipo);
                         else:
                              print("Non ci sono articoli nel carrello!")
                         c = "int"
                  case 5:
                         if len(scontrino) != 0:
                            tipo = "b";scontrino, newscontrino = stampa_scontrino(scontrino,newscontrino,tipo);
                         else:
                              print("Non ci sono articoli nel carrello!")
                         c = "int"
                  case 6:
                         if len(newscontrino) != 0:
                            tipo = "c"; scontrino, newscontrino = stampa_scontrino(scontrino,newscontrino,tipo);
                         else:
                              print("Non ci sono articoli scontati nel carrello!")
                         c = "int"
                  case 7:
                         print("Fine!")
                         c = 0
                  case _:print("ERRORE!");c = "int";
def main():
    Emissione_scontrino()

main()