from Studente import Studente
from Persona import Persona,figuraMitologica
Stud1 = Studente("Mario","Rossi","Via Bologna 43 - Torino")
print(Stud1) ## Lingua e età sono valori default
p1 = Persona("Sergio","Verdi")
print(p1)
f1 = figuraMitologica("Sfinge","Leone","ruggito","Egizia")
print(f1)