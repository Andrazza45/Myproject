#esercizio 1
from random import randint, random, randrange
def stampa_matrice(mat,lista3, lista4):
    for j in range(len(mat)-1):
        print(mat[j],"=",lista3[j], end = "\n")
    print("\n")
    print(lista4)
def stampa(lista):
    stampa =""
    for i in range(len(lista)):
        if i == 0:
           stampa =stampa + str(lista[i])
        else:
             stampa =stampa +"," + str(lista[i])
    print(stampa,end ="")
    print("\n")
    return stampa

def genera_matrice(r, c):
    mat = []
    for j in range(r):
        riga = []
        for i in range(c):
            riga =riga + [randint(1, 20)]
        mat.append(riga)
    return mat

def conta_in_stringa(s):
    lista = []
    vocali = ["a","A","e","E","i","I", "u","U"]
    consonanti = ["b","B","c", "C","d","D","f","F","g","G","h","H","j","J","k","K","l","L","m","M","n","N","o","O","p","P","q","Q","r","R","s","S","t","T","w","W","x","X","y","Y","z","Z"]
    numeri = ["0","1","2","3","4","5","6","7","8","9"]
    contatore = 0
    for ch in s:
        lista.append(ch)

    for i in range(0, len(lista)):
        if lista[i] == chr(32):
           contatore = contatore +1
    print("Gli spazi sono:", contatore)
    contatore = 0
    for i in range(0, len(lista)):
        for j in range(0, len(consonanti)):
            if lista[i] == consonanti[j]:
               contatore = contatore + 1
    print("Le consonanti sono:", contatore)
    contatore = 0
    for i in range(0, len(lista)):
        for j in range(0, len(vocali)):
            if lista[i] == vocali[j]:
               contatore = contatore + 1
    print("Le vocali sono:", contatore)
    contatore = 0
    for i in range(0, len(lista)):
        for j in range(0, len(numeri)):
            if lista[i] == numeri[j]:
               contatore = contatore + 1
    print("I numeri sono:", contatore, end = "")

#Esercizio 2
def elimina_duplicati(lista1):
    for i in range(0, len(lista1)):
        for j in range(i +1, len(lista1)):
            if lista1[i] == lista1[j]:
              lista1.remove(lista1[i])
              break
    for n in lista1:
        print(str(n)+"|",end ="")
    print("\n")

#Esercizio 3 somma di arrey
def moltiplicazione_somma_lista(lista1, lista2):
    lista3 = []
    lista4 = []
    j = 0
    for i in range(0, len(lista1)):

        while j < len(lista2):
              lista3.append(str(lista1[i] + lista2[j]))
              j = j + 1
              break
    j = 0
    for i in range(0, len(lista1)):
        while j < len(lista2):
              lista4.append(str(lista1[i] * lista2[j]))
              j = j + 1
              break

    stampa(lista3)
    stampa(lista4)

def somma_mat(mat):
    somma_vert = 0
    somma_orizz = 0
    lista3 = []
    lista4 = []
    #scorro la riga
    for i in range(0, len(mat)):
        j = 0
        while j < len(mat[j])-1:
              somma_orizz =  somma_orizz  + mat[i][j]
              j = j + 1
        if j == 9:
           somma_orizz =  somma_orizz  + mat[i][j]
        lista3.append(somma_orizz)
        somma_orizz = 0
    #scorro la colonna
    for i in range(0, len(mat[0])):
        j = 0
        while j < len(mat)-1:
              somma_vert  =somma_vert + mat[j][i]
              j = j + 1
        lista4.append(somma_vert)
        somma_vert = 0

    stampa_matrice(mat,lista3, lista4)
    return lista3, lista4
def main():
    s = input("Inserire una frase:")
    #1
    conta_in_stringa(s)
    print("\n")
    lista1 = []
    lista2 = []

    for i in range(10):
        lista1.append(randrange(1,30))

    for i in range(50):
        lista2.append(randrange(1,30))
    stampa(lista1)
    stampa(lista2)
    #2
    elimina_duplicati(lista1)
    #3
    moltiplicazione_somma_lista(lista1,lista2)
    mat = genera_matrice(10,10)
    #4
    somma_mat(mat)
main()