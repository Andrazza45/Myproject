print("Esercizio trasporti:","\n")
p1= 7
p2= 2
p3= 4
p4= 3
p5= 6

primoit= min(p1,p2)
terzoit= min(p1,p5)
secondoit= min(p1,p3,p4)

sol= max(primoit,secondoit,terzoit)

print("Il tonnellaggio massimo che può far arrivare a destinazione con un viaggio è:",sol)

#Caso A
print("\nCaso A")
p1= 2
p2= 6
p3= 2
p4= 4
p5= 5

primoit= min(p1,p2)
terzoit= min(p1,p5)
secondoit= min(p1,p3,p4)

sol= max(primoit,secondoit,terzoit)

print("Il tonnellaggio massimo che può far arrivare a destinazione con un viaggio è:",sol)

#Caso B
print("\nCaso B")
p1= 8
p2= 6
p3= 2
p4= 9
p5= 5

primoit= min(p1,p2)
terzoit= min(p1,p5)
secondoit= min(p1,p3,p4)

sol= max(primoit,secondoit,terzoit)

print("Il tonnellaggio massimo che può far arrivare a destinazione con un viaggio è:",sol)

#Caso C
print("\nCaso C")
p1= 8
p2= 9
p3= 9
p4= 4
p5= 7

primoit= min(p1,p2)
terzoit= min(p1,p5)
secondoit= min(p1,p3,p4)

sol= max(primoit,secondoit,terzoit)

print("Il tonnellaggio massimo che può far arrivare a destinazione con un viaggio è:",sol)