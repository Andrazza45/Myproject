def input_numero():
    while True:
                try:
                    n = int(input("Inserisci un numero:"))
                    break
                except:
                       print("input errato!....")
    return n

def fibonacci():
    print("Di quanti numeri si compone la sequenza di Fibonacci?")
    x = input_numero()
    lista = []
    i = 0
    while i <= x + 1:
            if i == 0 or i == 1:
               lista.append(i)
            else:
                 lista.append(lista[i-2] + lista[i -1])
            i = i + 1
    print("I numeri della sequenza di fibonacci sono:",lista[1 : x + 1])
def connversioniTemperature(tipo):
    while True:
                t1 = ""
                t = input("Inserire una temperatura:(specificare se è in °F, °C, o °K )")
                trovata1 = False
                parole = ["°C","°F","°K"]

                for j in range(0, len(parole)):
                    if parole[j] in t:
                        trovata1 = True
                        lista = []
                        lista = list(t.strip())
                        for i in range(0,len(lista)-2):
                            if ord(lista[i]) >= 58 and ord(lista[i]) <= 127:
                               trovata1 = False
                               break
                            else:
                                 t1 = t1 + str(lista[i])

                if t1 != "" and trovata1 == True:
                   t1 = float(t1)
                   if t1 < -1272.99 or t1> 1272.99 and parole[j] == "°K":
                      trovata1 = False
                   elif t1 < -1830.99 or t1> 1830.99 and parole[j] == "°F":
                        trovata1 = False
                   elif t1 < -999.99 or t1> 999.99 and parole[j] == "°C":
                        trovata1 = False
                   if trovata1 == True:
                            if parole[j] == "°K":
                               if tipo == "°C":
                                  t1 = t1* -272.15

                               else:
                                     t1 = (t1 - 273.15)*1.8 + 32

                            elif parole[j] == "°C":
                                 if tipo == "°K":
                                    t1 = t1* 274.15

                                 else:
                                      t1 = t1*1.8 + 32

                            elif parole[j] == "°F":
                                 if tipo == "°C":
                                    t1 = (t1 - 32)/1.8

                                 else:
                                      t1 = ((t1 - 32)/1.8) + 273.15
                   else:
                         print("Valore non valido!")
                else:
                     print("Non hai inserito nessun valore!")

                if trovata1 == True:
                   break
                else:
                     print("Non è una temperatura!")
    return t1
def connversioniBMI():

    h1 = ""
    p1 = ""
    while True:

                p = input("Inserire il proprio peso:(specificare se è in lb o kg)")
                h = input("Inserire la propria altezza:(specificare se è in ft o m)")

                parole = ["ft","''","m","lb","kg"]
                trovata1 = False
                trovata2 = False

                for j in range(0, len(parole)):
                    if parole[j] in p:
                        trovata1 = True
                        lista = []
                        lista = list(p.strip())
                        for i in range(0,len(lista)-2):
                            if ord(lista[i]) >= 58 and ord(lista[i]) <= 127:
                               trovata1 = False
                               break
                            else:
                                 p1 = p1 + str(lista[i])
                        if trovata1 == True and p1 != "":
                            if parole[j] == "lb":
                                p1 = float(p1)*0.46
                                break

                for j in range(0, len(parole)):
                    if parole[j] in h:
                       trovata2 = True
                       lista = []
                       lista = list(h.strip())
                       for i in range(0,len(lista)-2):
                           if ord(lista[i]) >= 58 and ord(lista[i]) <= 127:
                               trovata2 = False
                               break
                           else:
                                 h1 = h1 + str(lista[i])
                       if trovata2 == True and h1 != "":
                           if parole[j] == "ft":
                              h1 = float(h1) /3.28
                           elif parole[j] == "''":
                                 h1 = float(h1)*0.03
                                 break

                if trovata1 == True and trovata2 == True and h1 != "" and p1 != "" :
                    break
                else:
                     return -1
    return p1,h1
def Calcolo_BMI():
    p1 = 0
    h1 = 0
    if connversioniBMI() == -1:
       print("I dati di peso e altezza non sono corretti!")
    else:
            p1,h1 = connversioniBMI()
            BMI = p1 / h1**2
            messaggio = ""
            if BMI < 16.5:
               messaggio = "Sottopeso severo"
            elif BMI >= 16.5 and BMI <= 18.4:
                 messaggio ="Sottopeso"
            elif BMI >= 18.5 and BMI <= 24.9:
                 messaggio ="Normale"
            elif BMI >= 25.0 and BMI <= 30.0:
                 messaggio ="Sovrappeso"
            elif BMI >= 30.1 and BMI <= 34.9:
                 messaggio ="Obesità primo grado"
            elif BMI >= 35.0 and BMI <= 40.0:
                 messaggio ="Obesità secondo grado"
            elif BMI > 40:
                 messaggio ="Obesità terzo grado"
            print("Il tuo BMI è: ",BMI," CLASSE:",messaggio)
            return BMI
def convertitore_temperature():
    stringa = """
    ***************************************
        1.°F
        2.°C
        3.°K
        4.Solo invio per concludere
    ***************************************
    """

    tipo = "-1"
    while tipo != "":
           print(stringa)
           tipo = input("Che tipo di conversione desideri fare:")

           match tipo:
                   case "°F":print("la temperatura in °F è: ",connversioniTemperature(tipo))

                   case "°C":print("la temperatura in °C è: ",connversioniTemperature(tipo))

                   case "°K":print("la temperatura in °K è: ",connversioniTemperature(tipo))

                   case "":print("FINE")

                   case _: print("ERRORE!")

def main():
     fibonacci()
     Calcolo_BMI()
     convertitore_temperature()
main()