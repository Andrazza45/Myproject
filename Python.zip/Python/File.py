from platform import platform, machine, processor

print("Sistema utilizzato:", platform())
print("Tipo PC", machine())
print("Processore:", processor())

# from platform import python_implementation(), python_version_tuple()
# print("Versione Python:", platform)


##Cartelle
import os
cartella = os.getcwd()
print(cartella)
for nome in os.listdir():
    print(nome)

os.mkdir("mia_cartella")

for nome in os.listdir():
    print(nome)

elenco = os.listdir()
print("mia_cartella" in elenco)

if "mia_cartella" in elenco:
    os.rmdir("mia_cartella")
#menù
from tkinter import filedialog
nome_file = filedialog.askopenfilename(filetypes = (("file di testo","*.txt"),("Tutti i file",".*")))
print(nome_file)

stream = open(nome_file,"r", encoding = "utf-8")
st = stream.read()
stream.close()
print(st)
stream = open(nome_file,"w", encoding = "utf-8")
st = "questa è una frase di prova \n"
st1 = "questa frase è scritta al rigo successivo"
stream.write(st + st1)
stream.close()

from os import path, system
if path.exists(nome_file) == True:
   print("Exist!")

