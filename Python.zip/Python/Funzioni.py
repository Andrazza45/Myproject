import math

def Data():

    data = ""
    gg = "int"
    mm = "int"
    aa = "int"

    aa = controllo_input(aa,"Inserire l'anno:")
    mm = controllo_input(mm,"Inserire il mese:")
    while int(mm) < 1 or int(mm) > 12:
          mm = "int"
          mm = controllo_input(mm,"Inserire il mese:")

    if int(mm) == 4 or int(mm) == 6 or int(mm) == 9 or int(mm) == 11:
       gg = controllo_input(gg,"Inserire il giorno:")
       while int(gg) < 1 or int(gg) > 30:
             gg = "int"
             gg = controllo_input(gg,"Inserire il giorno:")
    else:
         if int(mm) == 2:
            gg = controllo_input(gg,"Inserire il giorno:")
            while int(gg) < 1 or int(gg) > 28:
                  gg = "int"
                  gg = controllo_input(gg,"Inserire il giorno:")
         else:

              gg = controllo_input(gg,"Inserire il giorno:")
              while int(gg) < 1 or int(gg) > 31:
                    gg = "int"
                    gg = controllo_input(gg,"Inserire il giorno:")

    data = aa+"-"+mm+"-"+gg
    return data
def estraiAnno(dataass):
    count = 0
    anno = ""
    for i in dataass:
        if i == '-':
           break
        anno += i

    return int(anno)
def adatta(s1, s2):
    c = 0
    i = 0
    for i in range(i, len(s1)):
        if s1[i] == "|":
           if i >= len(s2):
              break
           if ord(s2[i]) != 32:
              for j in range(i, len(s2)):
                  if ord(s2[j]) != 32:
                     c = c + 1
                  else:
                       for k in range(i - c, c):
                           s1[k] = " "
                       i = i + c
                       c = 0
                       break
    return s1,s2

def genera_matrice(mat, c, ID, proprietario, categoria, mq, numfamigliari ):
        riga = []
        if len(mat) == 0:
           for i in range(c):
               match i:
                        case 0:riga =riga + ["ID"]
                        case 1:riga =riga + ["proprietario"]
                        case 2:riga =riga + ["categoria"]
                        case 3:riga =riga + ["mq"]
                        case 4:riga =riga + ["numero_famigliari"]
           mat.append(riga)
        riga = []
        for i in range(c):
            match i:
                    case 0:riga =riga + [ID]
                    case 1:riga =riga + [proprietario]
                    case 2:riga =riga + [categoria]
                    case 3:riga =riga + [mq]
                    case 4:riga =riga + [numfamigliari]
        mat.append(riga)
        return mat

def controllo_input(n, m):
    while True:

               if n == "range":
                  n = input(m)
                  if not n.isdigit():
                     print("ERRORE! Dato non valido!")
                     n = "int"
                  else:
                       if int(n) > 3 or int(n) < 1:
                          print("ERRORE! Dato non valido!")
                          n = "int"
                       else:
                            break

               if n == "int":
                  n = input(m)
                  if not n.isdigit():
                     print("ERRORE! Dato non valido!")
                     n = "int"
                  else:
                       break
               if n == "float":
                  try:
                      n = float(input(m))
                      break
                  except:
                         print("ERRORE! Dato non valido!")
                         n = "float"
               if n != "int" and n != "range" and n != "float":
                  n = input(m)
                  if not n.isalpha():
                     print("ERRORE! Dato non valido!")
                     n = ""
                  else:
                       break
    return n

def funzione():
    x = 25
    y = 3
    global v
    print("x =",x,"y =",y,"v = ", v)
    return x, y

def pari_dispari():
    """Calcola pari e dispari"""
    pari = 0
    dispari = 0
    number = "int"
    number = controllo_input(number, "Inserisci un numero:")
    while number != 0:
          if number%2 != 0:
               dispari += 1
          else:
               pari += 1
          number = "int"
          number = controllo_input(number, "Inserisci un numero:")
    return pari, dispari

def stampa(pari, dispari):
    if pari > 0 or dispari > 0:
        print("\n Stampa pari e dispari","\n")
        print("i numeri pari sono in totale:", pari)
        print("i numeri dispari sono in totale:", dispari)
    else:
         print("Non ci sono numeri pari o dispari!")

##def main_1():
##    y = 10
##    x = 6
##    funzione()
##    print("x =",x,"y =",y)
##x = 11
##y = 5
##v = 10 - y
##x, y = funzione()
##print("x =",x,"y =",y,"\n")

def main_2():
    print("Calcolo pari e dispari")
    pari, dispari = pari_dispari()
    stampa(pari, dispari)

##main_2()
