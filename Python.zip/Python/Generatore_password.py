from random import random, randrange, randint
lista1 = []
n = 0
l = 0
def cancella(lista1, l):
    for i in range(0,len(lista1)):
        print("\n"+str(i)+". ",lista1[i])
    while True:
          try:
              canc = int(input("Quale elemento desideri cancellare?"))
              if len(lista1) >= canc:
                 break
          except:
                 print("errore!")
    if len(lista1) >= canc:
        if  lista1[canc] != "" :
            lista1[canc] = ""
            l = l - 1
            for i in range(canc,len(lista1)-1):
                lista1[i] = lista1[i + 1]
                lista1[i + 1] = ""
            print("L'elemento "+str(canc)+" è stato rimosso")
        else:
             print("Errore!")
    return lista1, l

def salva(p,l):
    c = 0
    for i in range(0,len(lista1)):
        if lista1[i] == "":
           lista1[i] = p
           break
        else:
             c = c + 1
    if c == len(lista1):
       lista1.append(p)
    l = l + 1
    return lista1,l
def random_password(password, tipo):
    match tipo:
               case "1":
                        l = randint(10, 20)
                        i = 2
                        for i in range(i, l + 3):
                            if i % 2 == 0 :
                               password = password +chr(randint(65, 90))
                            else:
                                 password = password +chr(randint(97, 122))
               case "2":
                        l = randint(10, 20)
                        i = 2
                        for i in range(i, l + 3):
                            if i % 2 == 0 and i - 1 != 13 :
                               password = password +chr(randint(65, 90))
                            elif i % 3 == 0 and i - 1 != 20:
                                 password = password +chr(randint(97, 122))
                            else:
                                 password = password +chr(randint(48, 57))

               case "3":
                        l = randint(10, 20)
                        i = 2
                        while i <= l + 2:
                                if i % 2 == 0 and i - 1 != 13:
                                   i = i + 3
                                   password = password +chr(randint(65, 90))
                                   password = password +chr(randint(36, 38))
                                   password = password +"*"

                                elif i % 3 == 0 and i - 1 != 20:
                                     i = i + 3
                                     password = password +chr(randint(97, 122))
                                     password = password +chr(randint(40, 42))
                                     password = password +"-"

                                else:
                                     i = i + 2
                                     password = password +chr(randint(48, 57))
                                     password = password +"@"

    return password

def genera1(lista1, n,l, tipo):
    p = ""
    password = ""
    while p != "YES" and  p != "NO":
          p = input("Desideri impostare una password casuale?(YES or NO)")
    if p == "NO":
       password = input("Imposta una password con lunghezza minima di 10 e massima di 20")
    else:
         password = random_password(password, tipo)
    valida = False
    criteri = 0
    while valida == False:
          lista= list(password)
          for i in range(0,len(lista)):
                if ord(lista[i]) >= 65 and ord(lista[i]) <= 90:
                   valida = True
                   criteri += 1

                if ord(lista[i]) >= 97 and ord(lista[i]) <= 122:
                   valida = True
                   criteri += 1
          if len(password) >=10 and len(password) <=20 and criteri == len(password):
             valida = True
          else:
               valida = False
          if valida == False:
                criteri = 0
                print("Password non valida!, riinserire la password:")
                password = input("Imposta una password con lunghezza minima di 10 e massima di 20")

          else:
                 if l < n:
                    print("Password salvata correttamente!")
                    lista1,l= salva(password,l)
                    impostapassword(n,l)
                 else:
                      print("Spazio esaurito!")

def genera2(lista1, n,l, tipo):
    p = ""
    password = ""
    while p != "YES" and  p != "NO":
          p = input("Desideri impostare una password casuale?(YES or NO)")
    if p == "NO":
       password = input("Imposta una password con lunghezza minima di 10 e massima di 20")
    else:
         password = random_password(password, tipo)
    valida = False
    criteri = 0
    while valida == False:
          lista= list(password)
          for i in range(0,len(lista)):
                if ord(lista[i]) >= 65 and ord(lista[i]) <= 90:
                   valida = True
                   criteri += 1
                if ord(lista[i]) >= 97 and ord(lista[i]) <= 122:
                   valida = True
                   criteri += 1
                if ord(lista[i]) >= 48 and ord(lista[i]) <= 57:
                   valida = True
                   criteri += 1

          if len(password) >=10 and len(password) <=20 and criteri == len(password):
                valida = True
          else:
                valida = False

          if valida == False:
                criteri = 0
                print("Password non valida!, riinserire la password:")
                password = input("Imposta una password con lunghezza minima di 10 e massima di 20")
          else:
                if l < n:
                    print("Password salvata correttamente!")
                    lista1,l = salva(password,l)
                    impostapassword(n,l)
                else:
                      print("Spazio esaurito!")
def genera3(lista1, n, l, tipo):
    p = ""
    password = ""
    while p != "YES" and  p != "NO":
          p = input("Desideri impostare una password casuale?(YES or NO)")
    if p == "NO":
       password = input("Imposta una password con lunghezza minima di 10 e massima di 20")
    else:
         password = random_password(password, tipo)
    valida = False
    criteri = 0
    while valida == False:
          lista= list(password)
          for i in range(0,len(lista)):
                if ord(lista[i]) >= 36 and ord(lista[i]) <= 38:
                   valida = True
                   criteri += 1
                if ord(lista[i]) >= 40 and ord(lista[i]) <= 42 :
                   valida = True
                   criteri += 1
                if ord(lista[i]) == 45 or ord(lista[i]) == 64 or ord(lista[i]) == 163:
                   valida = True
                   criteri += 1
                if ord(lista[i]) >= 65 and ord(lista[i]) <= 90:
                   valida = True
                   criteri += 1

                if ord(lista[i]) >= 97 and ord(lista[i]) <= 122:
                   valida = True
                   criteri += 1

                if ord(lista[i]) >= 48 and ord(lista[i]) <= 57:
                   valida = True
                   criteri += 1
          if len(password) >=10 and len(password) <=20 and criteri == len(password):
                valida = True
          else:
                valida = False
          if valida == False:
                criteri = 0
                print("Password non valida!, riinserire la password:")
                password = input("Imposta una password con lunghezza minima di 10 e massima di 20")
          else:
                 if l < n:
                    print("Password salvata correttamente!")
                    lista1,l = salva(password,l)
                    impostapassword(n,l)
                 else:
                      print("Spazio esaurito!")

def npassword(n):
    if n <= 50 and n >= 1:
       n = 0
    while n < 1 or n > 50:
          n = int(input("Quante password vuoi registrare:(1-50)"))
          if n < 1 or n > 50:
             print("Errore")
    return n
def impostapassword(n,l):
    tipo = -1
    st ="""
            1.Maiuscole e minuscole
            2.Maiuscole, minuscole e numeri
            3.Maiuscole, minuscole, numeri e simboli( $ £ % & ( ) * @ -)
            4.Fine"""
    while tipo != 0:
          print(st)
          tipo = input("Scegli quale tipo di password desideri impostare:")
          match tipo:
                case "1":
                         genera1(lista1, n, l, tipo)

                case "2":
                         genera2(lista1, n, l, tipo)

                case "3":
                         genera3(lista1, n, l, tipo)

                case "4":tipo = 0;main(lista1, n, l);
                case _: print("Errore")

def main(lista1, n,l):
    scelta = -1
    st1 ="""
            1.Quante password vuoi registrare?
            2.Imposta password
            3.Cancella password"""

    while scelta != 0:
              print(st1)
              scelta = input("Scegli un opzione:")
              match scelta:
                    case "1":n= npassword(n)
                    case "2":impostapassword(n,l)
                    case "3":lista1, l = cancella(lista1,l)
main(lista1, n,l)
