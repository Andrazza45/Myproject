from Dipendenti import Impiegato, Docente
from Funzioni import controllo_input
class gestione_dipendenti():

      def __init__(self, elenco):
          self.__elenco = elenco

      def aggiungi_dipendente(self, dip):
          self.__elenco.append(dip)

      def elimina_dipendente(self, ind):
          for i in range(0,len(self.__elenco)):
              if self.__elenco[i].GetIndirizzo() == ind:
                 del(self.__elenco[i])
              else:
                   return -1

      def cerca_dipendente(self, ind):
          for i in range(0, len(self.__elenco)):
              if self.__elenco[i].Getndirizzo() == ind:
                 return self.__elenco[i]
      def cancella_tutti_dip(self):
          for i in range(0,len(self.__elenco)):
              if i == len(self.__elenco):
                  del(self.__elenco[i-1])
              else:
                   del(self.__elenco[i])

      def Stampa_dip(self):
          for i in self.__elenco:
              print(i)

def Crea_dipendente(op, elenco, Dipendenti):
    ufficio = "int"
    nome = ""
    via = ""
    civico = "int"
    paese = ""
    indirizzo = ""
    sesso = ""##en
    disciplina = ""
    ruolo = ""
    if op == '1':
        ufficio = int(controllo_input(ufficio,"Inserire l'ufficio di appartenenza:"))
        nome = controllo_input(nome,"Inserire il nome dell'impiegato:")
        via = controllo_input(via,"Inserire la via della residenza")
        civico = controllo_input(civico,"Inserire il civico  della residenza")
        paese = controllo_input(paese,"Inserire il nome del paese")
        sesso = controllo_input(sesso,"Inserire il sesso della persona:")
        indirizzo = via +civico+"-"+ paese
        Imp= Impiegato(ufficio, nome, indirizzo, sesso)
        Dipendenti.aggiungi_dipendente(Impiegato)

    else:
         nome = controllo_input(nome,"Inserire il nome del docente:")
         via = controllo_input(via,"Inserire la via della residenza")
         civico = controllo_input(civico,"Inserire il civico  della residenza")
         paese = controllo_input(paese,"Inserire il nome del paese")
         indirizzo = via +civico+"-"+ paese
         disciplina = controllo_input(disciplina,"Inserire la disciplina del docente:")
         ruolo = controllo_input(ruolo,"Inserire il ruolo del docente:")
         docente = Docente(disciplina, ruolo, nome,indirizzo, sesso)
         Dipendenti.aggiungi_dipendente(docente)
         return Dipendenti
def main():
    elenco = []
    Dipendenti = gestione_dipendenti(elenco)

    st = """
         1.Crea dipendente
         2.Elimina dipendente
         3.Cancella tutti dipendenti
         4.Cerca dipendente
         5.Stampa elenco dipendenti
         6.FINE
                """
    m = "int"
    while m != '6':
          m = "int"
          op = "range"
          ind = ""
          print(st)
          m = controllo_input(m,"Inserire un opzione:")
          match m:

                case '1':  op =controllo_input(op,"(1 = Impiegato, 2 = Docente)"); Dipendenti = Crea_dipendente(op, elenco, Dipendenti);
                case '2':
                           ind =controllo_input(ind,"Inserire l'indirizzo da cercare")
                           if Dipendenti.elimina_dipendente(ind) == -1:
                              print("Dipendente non trovato!")

                case '3':  Dipendenti.cancella_tutti_dip();print("Tutti i dipendenti sono stati cancellati!")
                case '4':  ind =controllo_input(ind,"Inserire l'indirizzo da cercare");Dipendenti.cerca_dipendente(ind)
                case '5':  Dipendenti.Stampa_dip()
                case '6':  print("FINE!")
                case _:print("ERRORE!!")


main()


