from Personale import dirigente,funzionarioJunior,funzionarioSenior,tecnicoInformatico,tecnicoElettronico
from Funzioni import controllo_input, Data
class Gestione_Progetto():
      costo = 0
      def __init__(self, elenco, nome):
          self.__elenco = elenco
          self.__nome = nome

      def Get_elenco(self, x):
          return self.__elenco[x]

      def Get_nomeP(self):
          return self.__nome

      def Aggiungi_lavoratore(self, lavoratore):

          self.__elenco.append(lavoratore)

      def Eliminazione_lavoratore(self, codice):
          for i in range(0,len(self.__elenco)):
              if self.__elenco[i].Get_codice() == codice:
                 del(self.__elenco[i])
                 break
          if (i == len(self.__elenco)-1):
              return -1

      def Ricerca(self, codice):
          trovato = False
          for i in range(0, len(self.__elenco)):
              if self.__elenco[i].Get_codice() == codice:
                 trovato = True
                 break
          if trovato == True:
             return self.__elenco[i]
          else:
               return -1
      def Stampa_lavoratori(self):
          st = ""
          n = 1
          for i in self.__elenco:
              st += str(n)+". "+ str(i) + "\n"
              n += 1
          return st
      def Get_Personale(self):
          n = 0
          for i in self.__elenco:
              n += 1
          return n

      def Calcolo_Costo_totale(self,anno):
          totale = 0
          for i in self.__elenco:
              Gestione_Progetto.costo += i.GetCostoC(anno)

          return Gestione_Progetto.costo

def Inserisci_lavoratore(ruolo, oggetto):
    codice = ""
    nome = ""
    cognome = ""
    interno = True
    scelta = ""
    data = ""
    ore_lavoro = "int"
    match ruolo:
          case 'TecnicoInformatico':
                codice = controllo_input(codice,"Inserire la matricola del tecnico")
                print("Inserire la data del primo giorno di lavoro","\n")
                data = Data()
                print("\n")
                lavoratore = tecnicoInformatico(codice, interno, data)
                nome = controllo_input(nome,"Inserire il nome del tecnico:")
                lavoratore.Set_nome(nome)
                cognome = controllo_input(cognome,"Inserire il cognome del tecnico:")
                lavoratore.Set_cognome(cognome)

                while scelta != "SI" and scelta != "NO":
                      scelta = input("Specificare se il tecnico è interno o esterno:(SI = interno, NO = esterno)")
                      if scelta == "SI":
                         interno = True
                      else:
                           interno = False
                lavoratore.SetInterno(interno)
                ore_lavoro = int(controllo_input(ore_lavoro,"Inserire le ore di lavoro necessarie:"))
                lavoratore.SetOrelavorate(ore_lavoro)
          case 'TecnicoElettronico':
                codice = controllo_input(codice,"Inserire la matricola del tecnico")
                print("Inserire la data del primo giorno di lavoro","\n")
                data = Data()
                print("\n")
                lavoratore = tecnicoElettronico(codice, interno, data)
                nome = controllo_input(nome,"Inserire il nome del tecnico:")
                lavoratore.Set_nome(nome)
                cognome = controllo_input(cognome,"Inserire il cognome del tecnico:")
                lavoratore.Set_cognome(cognome)
                while scelta != "SI" and scelta != "NO":
                      scelta = input("Specificare se il tecnico è interno o esterno:(SI = interno, NO = esterno)")
                      if scelta == "SI":
                         interno = True
                      else:
                           interno = False
                lavoratore.SetInterno(interno)
                ore_lavoro = int(controllo_input(ore_lavoro,"Inserire le ore di lavoro necessarie:"))
                lavoratore.SetOrelavorate(ore_lavoro)
          case 'FunzionarioJunior':
                codice = controllo_input(codice,"Inserire la matricola del funzionario")
                print("Inserire la data del primo giorno di lavoro","\n")
                data = Data()
                print("\n")
                lavoratore = funzinarioJunior(codice, data)
                nome = controllo_input(nome,"Inserire il nome del funzionario:")
                lavoratore.Set_nome(nome)
                cognome = controllo_input(cognome,"Inserire il cognome del funzionario:")
                lavoratore.Set_cognome(cognome)
                ore_lavoro = int(controllo_input(ore_lavoro,"Inserire le ore di lavoro necessarie:"))
                lavoratore.SetOrelavorate(ore_lavoro)
          case 'FunzionarioSenior':
                codice = controllo_input(codice,"Inserire la matricola del funzionario")
                print("Inserire la data del primo giorno di lavoro","\n")
                data = Data()
                print("\n")
                lavoratore = funzinarioSenior(codice, data)
                nome = controllo_input(nome,"Inserire il nome del funzionario:")
                lavoratore.Set_nome(nome)
                cognome = controllo_input(cognome,"Inserire il cognome del funzionario:")
                lavoratore.Set_cognome(cognome)
                ore_lavoro = int(controllo_input(ore_lavoro,"Inserire le ore di lavoro necessarie:"))
                lavoratore.SetOrelavorate(ore_lavoro)
          case 'Dirigente':
                codice = controllo_input(codice,"Inserire la matricola del dirigente:")
                print("Inserire la data del primo giorno di lavoro","\n")
                data = Data()
                print("\n")
                lavoratore = dirigente(codice, data)
                nome = controllo_input(nome,"Inserire il nome del dirigente:")
                lavoratore.Set_nome(nome)
                cognome = controllo_input(cognome,"Inserire il cognome del dirigente:")
                lavoratore.Set_cognome(cognome)
                ore_lavoro = int(controllo_input(ore_lavoro,"Inserire le ore di lavoro necessarie:"))
                lavoratore.SetOrelavorate(ore_lavoro)
          case _:return -1
    oggetto.Aggiungi_lavoratore(lavoratore)
    return oggetto

def main():
    progetti = [""]
    nome = ""
    st = """
         1. aggiunta di una persona al progetto
         2. eliminazione di una persona dal progetto ricercato per codice
         3. verifica esistenza di una persona nel progetto ricercato per codice
         4. elenco dei partecipanti al progetto
         5. calcolo costo totale del progetto
         6. totale persone partecipanti
         7. Crea progetto
         8. Confronto progetti
         9. Stampa progetti in ordine di costo
         10. Fine
             """
    s = "int"
    ruolo = ""
    while s != "10":
          print(st)
          trovato = False
          s = "int"
          s = controllo_input(s, "Inserire un opzine:")
          match s:
                case '1':
                         indice = "int"
                         indice = int(controllo_input(indice, "In quale progetto desideri inserire un nuovo lavoratore?"))
                         for i in range(0,len(progetti)):
                             if i == indice:
                                trovato = True
                                break

                         if trovato == True and indice != 0:
                             ruolo = controllo_input(ruolo, "Inserire il ruolo del lavoratore:")
                             if Inserisci_lavoratore(ruolo, progetti[i]) == -1:
                                print("Ruolo inesistente!")
                         else:
                             print("Progetto non trovato!!")

                case '2':
                         indice = "int"
                         indice = int(controllo_input(indice, "Su quale progetto desideri eliminare un lavoratore?"))
                         for i in range(0,len(progetti)):
                             if i == indice:
                                trovato = True
                                break
                         if trovato == True and indice != 0:

                             codice = ""
                             codice = controllo_input(codice,"Inserire il codice del lavoratore che vuoi eliminare:")
                             if progetti[i].Eliminazione_lavoratore(codice) == -1:
                                print("Codice non trovato!")
                             else:
                                  print("Eliminazione effettuata con successo!")
                         else:
                             print("Progetto non trovato!!")
                case '3':
                         indice = "int"
                         indice = int(controllo_input(indice, "Inserire il numero del progetto che si desidera visualizzare"))
                         for i in range(0,len(progetti)):
                             if i == indice:
                                trovato = True
                                break
                         if trovato == True and indice != 0:
                             codice = ""
                             codice = controllo_input(codice,"Inserire il codice del lavoratore che vuoi cercare:")
                             if progetti[i].Ricerca(codice) == -1:
                                print("Codice non trovato!")
                             else:
                                  print(progetti[i].Ricerca(codice))
                         else:
                               print("Progetto non trovato!!")

                case '4':
                         indice = "int"
                         indice = int(controllo_input(indice, "Inserire il numero del progetto che si desidera visualizzare"))
                         for i in range(0,len(progetti)):
                             if i == indice:
                                trovato = True
                                break
                         if trovato == True and indice != 0:
                            print(progetti[i].Stampa_lavoratori())
                         else:
                              print("Progetto non trovato!!")

                case '5':
                         indice = "int"
                         indice = int(controllo_input(indice, "Inserire il numero del progetto che si desidera visualizzare"))
                         for i in range(0,len(progetti)):
                             if i == indice:
                                trovato = True
                                break
                         if trovato == True and indice != 0:
                            anno = "int";anno = int(controllo_input(anno,"Inserire l'anno della scadenza:"));print("Il costo totale del progetto è : "+str(progetti[i].Calcolo_Costo_totale(anno))+"€")
                         else:
                              print("Progetto non trovato!!")
                case '6':
                         indice = "int"
                         indice = int(controllo_input(indice, "Inserire l'id del progetto che si desidera visualizzare"))
                         for i in range(0,len(progetti)):
                             if i == indice:
                                trovato = True
                                break
                         if trovato == True and indice != 0:
                            print("Il numero di partecipanti al progetto è: "+str(progetti[i].Get_Personale()))
                         else:
                              print("Progetto non trovato!!")
                case '7':
                         elenco = []
                         nome = controllo_input(nome,"Inserire il nome del nuovo progetto:")
                         p = Gestione_Progetto(elenco,nome)
                         progetti.append(p)
                case '8':
                         trovato1 = False
                         trovato2 = False
                         indice1 = "int"
                         indice2 = "int"
                         indice1 = int(controllo_input(indice1, "Inserire l'id del progetto che desideri confrontare"))
                         indice2 = int(controllo_input(indice2, "Con quale progetto vuoi confrontarlo?"))
                         for i in range(0,len(progetti)):
                             if i == indice1:
                                i1 = i
                                trovato1 = True
                             if i == indice2:
                                i2 = i
                                trovato2 = True
                             if trovato1 == True and trovato2 == True:
                                break
                         if trovato1 == True and trovato2 == True and indice1 != 0 and indice2 != 0 :
                            l1 = progetti[i1].Get_Personale()
                            l2 = progetti[i2].Get_Personale()
                            eq = 0
                            if l1 == l2:
                               for i in range(0,l1):
                                   obj1 = progetti[i1].Get_elenco(i)
                                   obj2 = progetti[i2].Get_elenco(i)
                                   if  obj1 == obj2 :
                                       eq += 1
                               if eq == l1:
                                  print("è uguale!")
                               else:
                                     print("è diverso")
                            else:
                                 print("è diverso")

                case '9':
                         anno = "int"
                         anno = int(controllo_input(anno,"Inserire l'anno della scadenza:"))
                         progettiO = progetti
                         for i in range(1, len(progettiO)-1):
                             for j in range(i + 1, len(progettiO)):
                                 if progettiO[j].Calcolo_Costo_totale(anno) < progettiO[i].Calcolo_Costo_totale(anno):
                                    copia = progettiO[i]
                                    progettiO[i] = progettiO[j]
                                    progettiO[j] = copia

                         for i in range (1,len(progettiO)):
                             print("Progetto " + progettiO[i].Get_nomeP()+"\n")
                             print(progettiO[i].Stampa_lavoratori())

                case '10':print("Fine")
                case _: print("Scelta non consentita")
main()