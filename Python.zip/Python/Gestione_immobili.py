from Funzioni import controllo_input
from Immobili import Villa, Appartamento, Abitazione
def Inserisci_Immobile(tipo, immobili):
    nome = ""
    mq = "float"
    stanze = "int"
    anno_c = "int"
    via = ""
    civico = "int"
    citta = ""
    ind = ""
    match tipo:
                case 'Villa':
                         nome = controllo_input(nome,"Inserire il nome dell'immobile:")
                         mq = float(controllo_input(mq,"Inserire il dato sulla superficie:"))
                         stanze = int(controllo_input(stanze,"Inserire il numero di stanze:"))
                         anno_c = int(controllo_input(anno_c,"Inserire l'anno di edificazione:"))
                         via = controllo_input(via,"Inserire il nome della via:")
                         civico = controllo_input(civico,"Inserire il civico:")
                         citta = controllo_input(citta,"Inserire il nome della città:")
                         ind = via +"-" + civico + "-"+ citta
                         immobile = Villa(mq,stanze, anno_c, nome,ind )
                case 'Abitazione':
                         nome = controllo_input(nome,"Inserire il nome dell'immobile:")
                         mq = float(controllo_input(mq,"Inserire il dato sulla superficie:"))
                         stanze = int(controllo_input(stanze,"Inserire il numero di stanze:"))
                         anno_c = int(controllo_input(anno_c,"Inserire l'anno di edificazione:"))
                         via = controllo_input(via,"Inserire il nome della via:")
                         civico = controllo_input(civico,"Inserire il civico:")
                         citta = controllo_input(citta,"Inserire il nome della città:")
                         ind = via +"-" + civico + "-"+ citta
                         immobile = Abitazione(mq, stanze, anno_c, nome,ind)
                case 'Appartamento':
                         nome = controllo_input(nome,"Inserire il nome dell'immobile:")
                         mq = float(controllo_input(mq,"Inserire il dato sulla superficie:"))
                         stanze = int(controllo_input(stanze,"Inserire il numero di stanze:"))
                         anno_c = int(controllo_input(anno_c,"Inserire l'anno di edificazione:"))
                         via = controllo_input(via,"Inserire il nome della via:")
                         civico = controllo_input(civico,"Inserire il civico:")
                         citta = controllo_input(citta,"Inserire il nome della città:")
                         ind = via +"-" + civico + "-"+ citta
                         immobile = Appartamento(mq, stanze, anno_c, nome,ind)

    immobili.append(immobile)
    return immobili

def ordina(immobili, ordine):
    immobileO = immobili
    match ordine:
          case 'superficie':

                            for i in range(1, len(immobileO)-1):

                                for j in range(i + 1, len(immobileO)):
                                    if immobileO[j].Get_mq() < immobileO[i].Get_mq():
                                       copia = immobileO[i]
                                       immobileO[i] = immobileO[j]
                                       immobileO[j] = copia


          case 'stanze':

                            for i in range(1, len(immobileO)-1):
                                for j in range(i + 1, len(immobileO)):
                                    if immobileO[j].Get_stanze() < immobileO[i].Get_stanze():
                                       copia = immobileO[i]
                                       immobileO[i] = immobileO[j]
                                       immobileO[j] = copia

          case 'città':
                       immobileO = sorted(immobileO, key = Getattr(Get_citta()))

    return immobileO



def main():
    #1 oggetto
    ## get elenco
    print("Patrimonio Immobiliare")
    immobili = [""]
    ordini = ["superficie", "stanze", "città", "costo"]
    st = """
         1) Crea immobile da aggiungere al patrimonio immobiliare
         2) Compara immobili
         3) Stampa elenco immobili e il costo
         4) Stampa costo di un immobile
         5) Stampa immobili in ordine di superficie
         6) Stampa immobili in ordine di numero di stanze
         7) Stampa immobili in ordine di città
             """
    s = "int"
    tipo = ""
    while s != "8":
          print(st)
          trovato = False
          s = "int"
          s = controllo_input(s,"Inserire un opzine:")
          match s:
                case '1':
                         tipo = controllo_input(tipo, "Inserire il tipo dell'immobile:")
                         if Inserisci_Immobile(tipo, immobili) == -1:
                            print("tipo inesistente!")

                case '2':
                         trovato1 = False
                         trovato2 = False
                         indice1 = "int"
                         indice2 = "int"
                         indice1 = int(controllo_input(indice1, "Inserire l'id dell'immobile che si desidera comparare:"))
                         indice2 = int(controllo_input(indice2, "Con chi vuoi compararlo?"))
                         for i in range(0,len(immobili)):
                             if i == indice1:
                                i1 = i
                                trovato1 = True
                             if i == indice2:
                                i2 = i
                                trovato2 = True
                             if trovato1 == True and trovato2 == True:
                                break
                         if trovato1 == True and trovato2 == True and indice1 != 0 and indice2 != 0  :
                            if immobili[i1] == immobili[i2]:
                               print("è uguale!")
                            else:
                                 print("è diverso")
                case '3':
                            for i in range(1, len(immobili)):
                                print(immobili[i].Stampa_immobile()+ " Costo: ",immobili[i].Costo_immobile())

                case '4':
                         indice = "int"
                         indice = int(controllo_input(indice, "Inserire l'id dell'immobile del quale vuoi vedere il costo"))
                         for i in range(0,len(immobili)):
                             if i == indice:
                                trovato = True
                                break
                         if trovato == True and indice != 0:
                            print(immobili[i].Costo_immobile())

                case '5':
                         ordine =  ordini[0]
                         ordinati = ordina(immobili, ordine)
                         for i in range(1, len(ordinati)):
                             print(ordinati[i].Stampa_immobile())
                case '6':
                         ordine = ordini[1]
                         ordinati = ordina(immobili, ordine)
                         for i in range(1, len(ordinati)):
                             print(ordinati[i].Stampa_immobile())
                case '7':
                         ordine = ordini[2]
                         ordinati = ordina(immobili, ordine)
                         for i in range(1, len(ordinati)):
                             print(ordinati[i].Stampa_immobile())

                case '8':print("Fine")
                case _: print("Scelta non consentita")
main()