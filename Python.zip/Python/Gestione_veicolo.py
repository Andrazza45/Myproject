from Veicolo import  Furgone, Autovettura
from Funzioni import controllo_input
from operator import attrgetter, methodcaller

class Gestione_veicoli():
    def __init__(self,elenco):
        self.__elenco = elenco

    def Get_elenco(self, x):
        return self.__elenco[x]

    def aggiungi_veicolo(self,veicolo):
        self.__elenco.append(veicolo)
    def cerca_veicolo(self, targa):
        for i in range (0, len(self.__elenco)):
            if self.__elenco[i]._targa == targa:
               return self.__elenco[i]
            else:
                 return -1

    def cancella_veicolo(self,targa):
        for i in range (0, len(self.__elenco)):
            if self.__elenco[i]._targa == targa:
                del(self.__elenco[i])
            else:
                 return -1
    def tot_veicoli(self):
        return len(self.__elenco)

    def costo_tot(self):
        totale = 0
        for i in range (0, len(self.__elenco)):
            totale += self.__elenco[i]._costo
        return totale
    def ordina_veicoli(self, chiave):
        el = self.__elenco.copy()
        match chiave:
                case 1:
                       el= sorted(el, key= attrgetter('_marca'))
                case 2:
                       el = sorted(el, key= attrgetter('_targa'))
                case 3:
                       el = sorted(el, key= attrgetter('_costo'))
        return el
    def stampa_veicoli(self):
        print("Elenco Veicoli:","\n")
        for i in range (0, len(self.__elenco)):
            print(self.__elenco[i])

def Inserisci(tipo, Veicoli):
    marca = ""
    targa = ""
    costo = "float"
    posti = "int"
    capacita = "int"

    match tipo:

                case 'Furgone':
                      marca = controllo_input(marca, "Inserire la marca del Furgone:")
                      while (len (targa) != 7):
                             targa = ""
                             targa = input("Inserire la targa del Furgone:")

                      costo = float(controllo_input(costo, "Inserire il costo del Furgone:"))
                      capacita = int(controllo_input(capacita, "Inserire la capacita del Furgone:"))
                      veicolo = Furgone(marca, targa, costo,capacita)
                      Veicoli.aggiungi_veicolo(veicolo)
                case 'Autovettura':
                      marca = controllo_input(marca, "Inserire la marca dell'Autovettura:")
                      while (len (targa) != 7):
                             targa = ""
                             targa = input("Inserire la targa dell'Autovettura:")

                      costo = float(controllo_input(costo, "Inserire il costo dell'Autovettura:"))
                      posti = int(controllo_input(posti, "Inserire la capacita dell'Autovettura:"))
                      veicolo = Autovettura(marca, targa, costo, posti)
                      Veicoli.aggiungi_veicolo(veicolo)
                case _:print("Il tipo di veicolo non è disponibile","\n")
    return Veicoli

def main():

    o = ""
    tipo = ""
    elenco = []
    Veicoli = Gestione_veicoli(elenco)

    menu = '''
                1) Inserisci veicolo
                2) Cancella Veicolo per targa
                3) Cerca veicolo per targa
                4) Stampa elenco dei veicoli in ordine crescente di targa
                5) Stampa numero totale dei veicoli
                6) Stampa costo totale dei veicoli
                7) Fine'''
    while(o != '7'):
          print(menu)
          o = "int"
          o = controllo_input(o, "Inserire un opzione:")

          match o:
                    case '1':tipo = controllo_input(tipo, "Vuoi inserire un Furgone o un Autovettura"); Veicoli = Inserisci(tipo,Veicoli)
                    case '2':
                             targa = ""
                             while (len (targa) != 7):
                                   targa = ""
                                   targa = input("Inserire la targa da cercare")

                             if Veicoli.cancella_veicolo(targa) == -1:
                                print("Veicolo non trovato!")
                             else:
                                   print("Veicolo cancellato")
                    case '3':
                             targa = ""
                             while (len (targa) != 7):
                                   targa = ""
                                   targa = input("Inserire la targa da cercare")

                             if Veicoli.cerca_veicolo(targa) == -1:
                                print("Veicolo non trovato")
                             else:
                                   print(Veicoli.cerca_veicolo(targa))
                    case '4':

                             chiave = "range"
                             chiave = int(controllo_input(chiave,"1.(ordina per marca), 2.(ordina per targa) 3.(ordina per costo)"))
                             elenco = Veicoli.ordina_veicoli(chiave)
                             print("Elenco Veicoli:","\n")
                             for i in range (0, len(elenco)):
                                 print(elenco[i])

                    case '5':print("I veicoli registrati sono:",Veicoli.tot_veicoli())
                    case '6':print("Il costo totale dei veicoli in vendita è:",Veicoli.costo_tot())
                    case '7':print("Fine!")
                    case _: print("opzione errata")
main()
