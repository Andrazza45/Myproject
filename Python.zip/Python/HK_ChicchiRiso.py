lista = [64]
somma = 1
while True:

            caselle = input("Inserisci quante caselle hai bisogno di utilizzare:")
            if caselle.isdigit():
               caselle = int(caselle)
               if caselle > 64 or caselle < 0:
                  print("Errore")
               else:
                    break
            else:
                 print("Errore")
for i in range(2,caselle +1):
    lista.append(i)
    somma = int(somma) + int(lista[i-1])
print(somma)
##########################################################
st = ""
num = "0"
i = 0
print("Conta numeri compresi tra h e k","\n"*2)
h = int(input("Inserisci il primo numero"))
k = int(input("Inserisci il secondo numero"))
while num.isdigit():
      num = input("Inserisci un numero:")
      if num.isdigit():
          if int(num) <= k and int(num) >= h:
              st = st + str(num)+"."
              i = i + 1
print("I numeri compresi tra h e k sono:",st.replace(".",",",i-1))


