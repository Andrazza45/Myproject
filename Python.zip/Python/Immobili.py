from abc import ABC,abstractmethod
# for i, immobile in enumerate(immobili):
#     print(str(i+1)+")",immobile)
class Immobile():
      valore = 0
      def __init__(self,mq,stanze, anno_c, nome, ind):
          self._mq = mq
          self._stanze = stanze
          self._anno_c = anno_c
          self._nome = nome
          self._ind = ind

      def Get_mq(self):
          return self._mq

      def Get_stanze(self):
          return self._stanze

      def Set_stanze(self, stanze):
          self._stanze = stanze

      def Get_annoc(self):
          return self._anno_c
      def Get_nome(self):
          return self._nome
      def Set_nome(self, nome):
          self._nome = nome
      def Get_via(self):
          ind = self._ind.split("-")
          return ind[0]

      def Get_civico(self):
          ind = self._ind.split("-")
          return ind[1]

      def Get_citta(self):
          ind = self._ind.split("-")
          return ind[2]

      def get_indirizzo(self):
          return self._ind

      def Stampa_immobile(self):
          return "mq: "+str(self._mq) +" num_stanze: "+str(self._stanze)+" Costruita in: "+ str(self._anno_c) +" Nome: "+self._nome + " Indirizzo: "+self._ind
      @abstractmethod
      def Costo_immobile(self):
          costo = 0
          costo = self._mq * Immobile.valore
          if self._anno_c < 1940:
             costo = costo - (costo * 0.00)
          return costo

class Villa(Immobile):
      valore = 3500
      def __init__(self,mq,stanze, anno_c, nome, ind):
          super().__init__(mq,stanze, anno_c, nome, ind)
      def Costo_immobile(self):
          costo = 0
          costo = self._mq * Villa.valore
          if self._anno_c < 1940:
             costo = costo - (costo * 0.25)
          return costo
      def __eq__(self, immobile):
          if isinstance(immobile,Villa):
             return (immobile.Get_mq() == self._mq) and (immobile.Get_annoc() == self._anno_c) and (immobile.Get_nome() == self._nome) and (immobile.Get_indirizzo() == self._ind)

class Appartamento(Immobile):
      valore = 1750
      def __init__(self,mq,stanze, anno_c, nome, ind):
          super().__init__(mq,stanze, anno_c, nome, ind)
      def Costo_immobile(self):
          costo = 0
          costo = self._mq * Appartamento.valore
          if self._anno_c < 1940:
             costo = costo - (costo * 0.15)
          return costo
      def __eq__(self, immobile):
          if isinstance(immobile,Appartamento):
             return (immobile.Get_mq() == self._mq) and (immobile.Get_annoc() == self._anno_c) and (immobile.Get_nome() == self._nome) and (immobile.Get_indirizzo() == self._ind)

class Abitazione(Immobile):
      valore = 2500
      def __init__(self,mq,stanze, anno_c, nome, ind):
          super().__init__(mq, stanze, anno_c, nome, ind)
      def Costo_immobile(self):
          costo = 0
          costo = self._mq * Abitazione.valore
          if self._anno_c > 1940:
             costo = costo - (costo * 0.20)
          return costo

      def __eq__(self, immobile):
          if isinstance(immobile,Abitazione):
             return (immobile.Get_mq() == self._mq) and (immobile.Get_annoc() == self._anno_c) and (immobile.Get_nome() == self._nome) and (immobile.Get_indirizzo() == self._ind)
