from AggregazioneComposizione import Salario
class Impiegato():
    def __init__(self, nome,  eta, stipendio, bonus):
        self.__nome = nome
        self.__eta = eta
        self.__miosalario = Salario(bonus, stipendio)

    def getNome(self):
        return self.__nome

    def getEta(self):
        return self.__eta
    def getStipendio(self):
        return self.__miosalario.GetStipendio()
    def getBonus(self):
        return self.__miosalario.GetBonus()
    def total_sal(self):
        return self.__miosalario.Stipendio_annuale()
    def __str__(self):
        return "Nome: "+str(self.__nome)+ " Età: "+str(self.__eta)+" "+str(self.__miosalario) +" Stipendio Annuale: "+ str(self.total_sal())

def main():
    i = Impiegato('Andrea',21, 1500,500)
    print(i)
main()