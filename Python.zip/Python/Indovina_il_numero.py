#Indovina il numero
from random import random, randint, randrange
from Funzioni import controllo_input
x = randrange(1, 100)
tentativi = "int"
tentativi = controllo_input(tentativi,"Inserisci il numero di tentativi:")

for i in range(0, int(tentativi)):
    numero = "int"
    numero = int(controllo_input(numero,"Indovina il numero:"))
    if numero < x:
       print("Il numero inserito è minore del numero da cercare")
    elif numero > x:
         print("Il numero inserito è maggiore del numero da cercare")
    elif numero == x:
         print("Indovinato")
         break
    if i == int(tentativi) -1:
       print("Hai perso!","il numero era",x)
