nomi = ("luigi","mario","davide")
nomi = set(nomi)
nomi.add("antonio")
print(nomi)
# #cancello un elemento e non da errore
# nomi.discard("renato")
# #cancello un elemento e da errore se non esiste
# nomi.remove("renato")
if "renato" in nomi:
    nomi.remove("renato")
else:
     print("renato non esiste in nomi")

alunni = {"mario","luigi"}
nomi.issubset(nomi)
print(alunni.issubset(nomi))
print(nomi.issuperset(alunni))
persone = nomi.union(alunni)
print("Unione =", persone)
persone = nomi.intersection(alunni)
print("intersezione = ", persone)
persone = nomi.difference(alunni)
print("differenza = ", persone)
numeri = set(range(10))
print(numeri)
numeri.clear()
lst = list(range(10))
lst1 = list(range(10))
lst2 = list()
lst2.append(lst)
lst2.append(lst1)
lst2 = sorted(list(set(lst)))
print(lst2)









