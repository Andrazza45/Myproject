from Funzioni import controllo_input
class lampadina():
      def __init__(self,accesa, rotta):
          self.__accesa = accesa
          self.__totclick = 15000
          self.__click = 0
          self.__rotta = rotta
      def __str__(self):
          st ="Accesa:" +" "+ str(self.__accesa)+" Totale click:" +" "+ str(self.__totclick) + " Click: " + str(self.__click) + " Rotta: " + str(self.__rotta)
          return st
      def GetAccesa(self):
          return self.__accesa
      def Get_n_click(self):
          return self.__click
      def GetRotta(self):
          return self.__rotta
      def GetTolleranza(self):
          return self.__totclick
      def SetRotta(self,rotta):
          self.__rotta = rotta
      def SetAccesa(self, accesa):
          self.__accesa = accesa
      def SetClick(self,click):
          self.__click = click

      def click(self, stato, click):
          self.__click = self.__click + click
          if click % 2 != 0:
             self.__accesa = stato
          else:
               self.__accesa = not stato

def crea(lista_lamp):
    lamp = lampadina(False, False)
    lista_lamp.append(lamp)
    return lista_lamp
def stampa(lista_lamp):
    for i in (lista_lamp):
        print(i)
def Esempio_lampadina():
    lista_lamp = []
    print("Esempio Lampadina","\n")
    stringa = """
                 ** 1 ON/OFF
                 ** 2 Stampa stato
                 ** 3 Crea Lampadina
                 ** 4 Exit"""
    m = "int"
    click = 0
    while m != 0:
            print(stringa,"\n")
            m = int(controllo_input(m, "Inserisci un opzione:"))
            match m:
                    case 1:
                           m = "int"
                           l = "int"
                           l = int(controllo_input(l, "Quale lampadina desideri spegnere/accendere?"))
                           for i in range(0,len(lista_lamp)):
                               if l == i:
                                  if lista_lamp[i].GetRotta() == False:

                                      if lista_lamp[i].GetAccesa() == True:
                                         stato = False
                                         lista_lamp[i].click(stato, 7500)
                                      else:
                                           stato = True
                                           lista_lamp[i].click(stato, 7501)
                                      if lista_lamp[i].Get_n_click() >= lista_lamp[i].GetTolleranza():
                                         lista_lamp[i].SetRotta(True)
                                         lista_lamp[i].SetAccesa(False)
                                         print("La lampadina è rotta!!")
                                  else:
                                       scelta = ""
                                       while scelta != "SI" and scelta != "NO":
                                             scelta = controllo_input(scelta,"Lampadina rotta, desideri sostituirla?")
                                             if scelta == "SI":
                                                lista_lamp[i].SetClick(0)
                                                lista_lamp[i].SetRotta(False)

                                  break

                    case 2:
                           m = "int"
                           stampa(lista_lamp)

                    case 3:lista_lamp = crea(lista_lamp);m = "int"
                    case 0:print("Fine!")
                    case _:print("Errore!");m = "int"

def main():
    Esempio_lampadina()
main()