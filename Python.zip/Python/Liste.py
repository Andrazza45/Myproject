lista =["Ugo","Ernesto","Carolina","Roberta"]
print(lista)
dim = len(lista)
print(dim)
lista[3] = "Gianluca"
print(lista[1:3])

#Scorre gli elementi della lista
i = 0
while i < len(lista):
      print(lista[i])
      i = i + 1
for i in range(0,len(lista)):
    print(lista[i])
for elemento in lista:
    print(elemento)

lista[0], lista[1] = lista[1], lista[0]
print(lista)
lista.reverse()
print(lista)
lista.append("mario")
#inserisci in una posizione
lista.insert(3,"Tobia")
print(lista)
#conta gli elementi indicati
lista.count('mario')
print(lista)
lista.extend(["Nora","Simone","Alberto"])
print(lista)
lista.sort()
print(lista)
lista.sort(reverse = True)
ls=[7,4,1]
ls = sorted(ls)
print(lista)
if "mario" in lista:
    print(lista.index("mario"))
#cancella un elemento se non esiste da errore
if "alberto" in lista:
    lista.remove("alberto")
#prima copy
lt = lista.copy()
lista.clear()
print(lista)
if len(lt) > 0:
   print(max(lt))
else:
     print("lista vuota")

my_list = [1,2,3,4,5,6,7,8,9,10]
da_cercare = 5

print(da_cercare in my_list)

#lotteria
#ho giocato alcuni numeri alla lotteria; sono uscite le estrazioni
#quanti numeri ho centrato?
estrazione=[5,11,9,42,3,49]
numeri_giocati=[3,7,11,42,34,49]
centrati = 0
for numero in numeri_giocati:
    if numero in estrazione:
       centrati += 1
print("numeri centrati =", centrati)



