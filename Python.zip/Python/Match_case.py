# Utilizzo struttura match case stringhe
n = input("Inserire un valore ")
match n:
        case '1':
            print("scelta 1")
        case '2':
            print("scelta 2")
        case '3' | '4':
            print("scelta 3 o 4")
        case _:
            print("scelta non inclusa ")


#menù
stringa = """
***************************************
    1.opzione 1
    2.opzione 2
    3.opzione 3
    4.opzione 4
    5.opzione 5
    6.Fine """

scelta = -1
while scelta != 0:
       print(stringa)
       scelta = input("Inserisci un opzione:")
       
       match scelta:
               case "1":
                   print("Operazione 1")
               case "2":
                   print("Operazione 2")
               case "3":
                   print("Operazione 3")
               case "4":
                   print("Operazione 4")
               case "5":
                   print("Operazione 5")
               case "6":
                   print("FINE")
                   scelta = 0
               case _:print("ERRORE!")
               