#Matrice vuota
def crea_matrice(r, c):
    mat = []
    for j in range(r):
        riga =[0] * c
        mat.append(riga)
    return mat
def stampa(mat):
    for j in range(len(mat)):
        print(mat[j])

def carica_matrice(mat):
    from random import randint
    for i in range(len(mat)):
        for c in range(len(mat[0])):
            mat[i][c] = randint(1, 20)
    return mat
def main():
    print("Carica matrice di r righe e c colonne")
    mat = crea_matrice(4,5)
    stampa(mat)
    print("\n")

    mat = carica_matrice(mat)
    mat1 = []
    mat1 = crea_matrice(4,5)
    mat1 = carica_matrice(mat)
    stampa(mat1)
    print("\n")
    stampa(mat)

main()