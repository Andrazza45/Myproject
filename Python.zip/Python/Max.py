"""
massimo 3 numeri
prendere 3 numeri in input e calcolare il massimo
dei 3 numeri e stamparlo"""
while True:
    
    a = input("Inserire il primo numero:")
    
    if a.isdigit() == True:
        a = int(a)
        break

    else:       
         print("Non è un numero")

while True:
    b = input("Inserire il secondo numero:")
    if b.isdigit() == True:
        b = int(b)
        break

    else:
         print("Non è un numero")

while True:
    c = input("Inserire il terzo numero:")
    if c.isdigit() == True:
        c = int(c)
        break

    else:
         print("Non è un numero")
        
maxi = a

if b > maxi:
    maxi = b
    
elif c > maxi:
    maxi = c
    
print("Il numero più grande tra i 3 è:", maxi) 
    