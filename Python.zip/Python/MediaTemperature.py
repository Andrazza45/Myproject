#Calcolo della media di tre temperature
from Funzioni import controllo_input
t = ["float","float","float"]
for j in range(0, len(t)):
    t[j] = controllo_input(t[j], "Inserire la temperatura:")
#1
somma = 0
for i in range(0,len(t)):
    somma = somma + t[i]
    media = somma/3
print("media delle temperature",media)
#2
media = sum(t)/len(t)
print(media)

#3
import statistics
media = statistics.mean(t)
print(f"la media è :{media:3.3f}")

