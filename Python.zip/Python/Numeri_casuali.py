from random import random, randrange, randint
print(random(),"\n")
for i in range(5):
    print(randint(1,20))
print("**************************")
for i in range(5):
     print(randrange(1,20,2))
print("**************************")
lista =[]
for x in range(0,6):
    y = randint(1,45)
    lista.append(y)
print(lista)