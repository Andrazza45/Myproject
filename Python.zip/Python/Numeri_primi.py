def is_primo(num):
    #Ritorna true o false se il numero è primo
    numprimo = True
    if num == 2 or num == 3 or num == 5:
        return numprimo
    #numero non è primo
    if num % 2 == 0 or num % 3 == 0 or num % 5 == 0:
       numprimo = False
    else:
         numprimo = True
         return numprimo

def main():
    stringa ="|"
    for k in range(1,100):
        if is_primo(k):
            stringa = stringa + str(k) + "|"
    print("I numeri primi sono:",stringa)
main()