from Funzioni import controllo_input
print("Calcola se il numero è primo","\n")
num = "int"
num = controllo_input(num,"Inserisci un numero:")
num = int(num)
#Ritorna true o false se il numero è primo
if num == 2 or num == 3 or num == 5:
   print("Il numero è primo")
else:

     if num % 2 == 0 or num % 3 == 0 or num % 5 == 0:
        print("Il numero non è primo")
     else:
          print("Il numero è primo")

#Cifrario di cesare
text = input("Inserisci un testo:")
n  = int(input("Inserisci un numero per la crittografia"))
st = ""
for ch in text:
    codice = ord(ch) + n
    st = st + chr(codice)
print("frase crittografata",st)
st1 = st
st =""
for ch in st1:
    codice = ord(ch) - n
    st = st +chr(codice)
print("frase decrittografata",st)
