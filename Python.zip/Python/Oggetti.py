class Atleti:
      def __init__(self,nome, cognome, altezza, squadra): ##squadra = "", visitamedica = False
          self.__nome = nome
          self.__cognome = cognome
          self.__altezza = altezza
          self.__squadra = squadra
          self.__visitamedica = False
      def GetNome(self):
          return self.__nome
      def GetCognome(self):
          return self.__cognome
      def GetAltezza(self):
          return self.__altezza
      def GetSquadra(self):
          return self.__squadra
      def GetVisitaMedica(self):
          return self.visitamedica
      def SetAltezza(self,altezza):
          self.__altezza = altezza
      def SetVisitaMedica(self,visita_medica):
          self.__visitamedica = visita_medica
      def SetSquadra(self,squadra):
         self. __squadra = squadra
      def __str__(self):
          st = "nome:" +str(self.__nome)+ " " + "cognome:" + str(self.__cognome)+ " " + "Squadra:" + str(self.__squadra)+ " " + "Altezza:" + str(self.__altezza)+ " " \
          +"VisitaMedica:" + str(self.__visitamedica);
          return st

def input_numero(stringa):
    while True:
      st = input(stringa)
      try:
          n = int(st)
          break
      except:
             print("Input errato!")
    return n

def main():
    #dati in input
    listaG = []

    Delpiero = Atleti("Alessandro", "Delpiero",170,"")
    Totti = Atleti("Francesco", "Totti", 140, "")
    Totti.SetVisitaMedica(True)
    Delpiero.SetSquadra("Juve")
    Totti.SetSquadra("Roma")
    listaG.append(Delpiero)
    listaG.append(Totti)

    ##print(Totti.nome)  attributo pubblico
    print(Totti.GetNome())
    print(Totti.GetNome(), Totti.GetCognome())
    print(Totti.GetNome(), Totti.GetCognome(), Totti.GetAltezza())

    for i in listaG:
        print(i)
main()