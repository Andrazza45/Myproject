#Calcolare numero se pari o dispari
from Funzioni import controllo_input
print("Numero pari o dispari")
while True:
      n = input("Inserisci un numero:")
      if n.isdigit():
         break
      else:
           print("Errore")
n = int(n)
if n%2==0:
	print("il numero è pari")
else:
	print("Il numero è dispari")
#Ordina 3 numeri in senso crescente presi in input
n1 = "int"
n2 = "int"
n3 = "int"
n1 = int(controllo_input(n1,"inserisci numero 1:"))
n2 = int(controllo_input(n2,"inserisci numero 2:"))
n3 = int(controllo_input(n3,"inserisci numero 3:"))
if n1 <= n2 and n2 <= n3:
        print("numeri ordinati:",n1,n2,n3)
elif n2 <= n1 and n1 <= n3:
        print("numeri ordinati:",n2,n1,n3)
elif n2 <= n3 and n3<= n1:
        print("numeri ordinati:",n2,n3,n1)
elif n1 <= n3 and n3 <= n2:
        print("numeri ordinati:",n1,n3,n2)
elif n3 <= n1 and n1 <= n2:
        print("numeri ordinati:",n3,n1,n2)
elif n3 <= n2 and n2 <= n1:
        print("numeri ordinati:",n3,n1,n1)

#calcola se un anno è bisestile
print("calcola se un anno è bisestile")
anno = "int"
anno = int(controllo_input(anno,"Inserisci numero di anno:"))
if anno < 1582:
	print("non è un anno del calendario gregoriano")
else:
	if anno%4 != 0 :
			print("anno non Bisestile")

	elif anno%400 !=0:
            print("anno non bisestile")
	elif anno%4 == 0 and anno%100 == 0 or anno%400 == 0:
          print("anno bisestile")

 #Scrivere un programma che calcola le radici di secondo grado sapendo che non esistono se delta < 0
import math

while True:
    a = input("Inserire il primo numero:")
    if a.isdigit() == True:
       a = int(a)
       break
    else:
	     print("Non è un numero!")

while True:
    b = input("Inserire il secondo numero:")
    if  b.isdigit() == True:
        b = int(b)
        break
    else:
         print("Non è un numero!")
while True:
    c = input("Inserire il terzo numero:")
    if c.isdigit() == True:
       c = int(c)
       break
else:
    print("Non è un numero!")

delta = b**2 -4*a*c
ris1= 0
ris2= 0
if delta < 0:
    print("Non ci sono S nell'insieme Reale")
elif delta > 0 or delta == 0 :
    ris1 = (-1*b + sqrt(delta))/2*a
    ris2 = (-1*b + sqrt(delta))/2*a
    print("Le soluzioni sono:",ris1,"e",ris2)