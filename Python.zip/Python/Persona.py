class Persona():
    __lingue = []
    def __init__(self, nome, cognome):
        self.__nome = nome
        self.__cognome = cognome
        self.__saldo= 0
        self.__eta = None
        Persona.__lingue = ["Italiano"]

    def GetLingue(self):
        lingue = ""
        for i in range(0, len(Persona.__lingue)):
            if  i == len(Persona.__lingue) -1:
                lingue += lingue + Persona.__lingue[i]+"."
            else:
                 lingue += lingue + Persona.__lingue[i]+","

        return lingue
    def GetCognome(self):
        return self.__cognome
    def GetNome(self):
        return self.__nome
    def GetEta(self):
        return self.__eta
    def GetSaldo(self):
        return self.__saldo
    def GetSaldo(self):
        return self.__saldo
    def SetConto(self, saldo):
        self.__saldo = saldo
    def SetEta(self,eta):
        self.__eta = eta
    def Apprendi_lingua(self,lingua):
        Persona.__lingue.append(lingua)

    def __str__(self):
        st = ""
        st = st +self.__nome +","+ self.__cognome +","+ str(self.__eta)+"\n"+"Lingue Conosciute:"+"\n"

        for i in Persona.__lingue:
            st += "-"+i
        return st +"\n"

class Animale():
      def __init__(self, tipo, verso, nome):
          self._tipo = tipo
          self._verso = verso
          self._nome = nome

      def __str__(self):
          return ">>> Sono un "+self._tipo+" mi chiamo: "+self._nome+"e faccio "+self._verso+" "

class figuraMitologica(Persona, Animale):
      def __init__(self, nome, tipo, verso, mitologia):
          Animale.__init__(self,tipo ,verso, nome)
          self.__mitologia = mitologia

      def ComeSeiFormato():
          return "ho 4 gambe e due mani"

      def __str__(self):
          st = ""
          st += "Sono una figura Mitologica: metà UOMO e metà "+self._tipo+", mi chiamo " \
               +self._nome+ ", so fare il verso "+self._verso \
               + " appartengo alla mitologia: "+self.__mitologia + " e so parlare le seguenti lingue:" + Persona.GetLingue(self)
          return str(st) +"\n"


