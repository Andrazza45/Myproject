from abc import ABC,abstractmethod
from datetime import date
from Funzioni import estraiAnno
class Persona():
    def __init__(self, codice, nome, cognome, dataass):
        self._codice = codice
        self._nome = nome
        self._cognome = cognome
        self._dataass = dataass

    def Get_codice(self):
        return self._codice
    def Get_nome(self):
        return self._nome
    def Set_nome(self, nome):
        self._nome  = nome
    def Get_cognome(self):
        return self._cognome
    def Set_cognome(self, cognome):
         self._cognome = cognome
    def Get_dataass(self):
        return self._dataass

    @abstractmethod
    def GetCostoC(self,anno):
        costoh = 1
        return costoh * (anno - estraiAnno(self._dataass)) * 1720

    def __str__(self):
        return " Codice: "+ self._codice+" Nome: "+self._nome+" Cognome: "+self._cognome+" Data Assunzione: "+self._dataass


    def __eq__(self, persona):
        if isinstance(persona,Persona):
           return (persona.Get_nome() == self._nome) and (persona.Get_cognome() == self._cognome) and (persona.Get_dataass() == self._dataass)

class dirigente(Persona):
      __costoOra = 100
      def __init__(self, codice, dataass):
          super().__init__(codice, None,None, dataass)
          self.__orelavoro = 0
      def GetOrelavorate(self):
          return self.__orelavoro
      def SetOrelavorate(self, ore):
          self.__orelavoro = ore
      def GetCostoC(self,anno):
          return dirigente.__costoOra * (anno - estraiAnno(self._dataass)) * 1720
      def __str__(self):
         st = ""
         st += "Codice: "+self._codice+" Nome: " + self._nome +" Cognome: "+ self._cognome +" Data assunzione: "+ self._dataass +" Ore necessarie: "+ str(self.__orelavoro)+" ore "
         return str(st)

      def __eq__(self, persona):
          if isinstance(persona,dirigente):
             return (persona.Get_nome() == self._nome) and (persona.Get_cognome() == self._cognome) and (persona.Get_dataass() == self._dataass) and (persona.GetOrelavorate() == self.__orelavoro)

class funzionarioJunior(Persona):
      __costoOra = 70
      def __init__(self, codice, dataass):
          super().__init__(codice,None, None, dataass)
          self.__orelavoro = 0
      def GetOrelavorate(self):
          return self.__orelavoro
      def SetOrelavorate(self, ore):
          self.__orelavoro = ore
      def GetCostoC(self,anno):
          return funzionarioJunior.__costoOra * (anno - estraiAnno(self._dataass)) * 1720
      def __str__(self):
          st = ""
          st += "Codice: "+self._codice+" Nome: " + self._nome +" Cognome: "+ self._cognome +" Data assunzione: "+ self._dataass +" Ore necessarie: "+ str(self.__orelavoro)+" ore "
          return st


      def __eq__(self, persona):
          if isinstance(persona,funzionarioJunior):
             return (persona.Get_nome() == self._nome) and (persona.Get_cognome() == self._cognome) and (persona.Get_dataass() == self._dataass)


class funzionarioSenior(Persona):
      __costoOra = 80
      def __init__(self, codice, dataass):
          super().__init__(codice, None,None, dataass)
          self.__orelavoro = 0
      def GetOrelavorate(self):
          return self.__orelavoro
      def SetOrelavorate(self, ore):
          self.__orelavoro = ore
      def GetCostoC(self,anno):
          return funzionarioSenior.__costoOra * (anno - estraiAnno(self._dataass)) * 1720

      def __str__(self):
          st = ""
          st += "Codice: "+self._codice+" Nome: " + self._nome +" Cognome: "+ self._cognome +" Data assunzione: "+ self._dataass +" Ore necessarie: "+ str(self.__orelavoro)+" ore "
          return st

      def __eq__(self, persona):
          if isinstance(persona,funzionarioSenior):
             return (persona.Get_nome() == self._nome) and (persona.Get_cognome() == self._cognome) and (persona.Get_dataass() == self._dataass) and (persona.GetOrelavorate() == self.__orelavoro)



class tecnicoInformatico(Persona):
      __costoOra = 40
      def __init__(self, codice, interno, dataass):
          super().__init__(codice, None,None, dataass)
          self.__orelavoro = 0
          self.__interno = interno
      def GetOrelavorate(self):
          return self.__orelavoro
      def SetOrelavorate(self, ore):
          self.__orelavoro = ore
      def GetInterno(self):
          return self.__interno
      def SetInterno(self, interno):
          self.__interno = interno
      def GetCostoC(self,anno):
          return tecnicoInformatico.__costoOra * (anno - estraiAnno(self._dataass)) * 1720
      def __str__(self):
          st = ""
          st += "Codice: "+self._codice+" Nome: " + self._nome +" Cognome: "+ self._cognome +" Data assunzione: "+ self._dataass +" Ore necessarie: "+ str(self.__orelavoro)+" ore Interno: "+ str(self.__interno)
          return st

      def __eq__(self, persona):
          if isinstance(persona,tecnicoInformatico):
             return (persona.Get_nome() == self._nome) and (persona.Get_cognome() == self._cognome) and (persona.Get_dataass() == self._dataass) and (persona.GetOrelavorate() == self.__orelavoro) and (persona.GetInterno() == self.__interno)



class tecnicoElettronico(Persona):
      __costoOra = 50
      def __init__(self, codice, interno, dataass):
          super().__init__(self,codice, None,None, dataass)
          self.__orelavoro = 0
          self.__interno = interno
      def GetOrelavorate(self):
          return self.__orelavoro
      def SetOrelavorate(self, ore):
          self.__orelavoro = ore
      def GetInterno(self):
          return self.__interno
      def SetInterno(self, interno):
          self.__interno = interno
      def GetCostoC(self,anno):
          return tecnicoElettronico.__costoOra * (anno - estraiAnno(self._dataass)) * 1720
      def __str__(self):
          st = ""
          st += "Codice: "+self._codice+" Nome: " + self._nome +" Cognome: "+ self._cognome +" Data assunzione: "+ self._dataass +" Ore necessarie: "+ str(self.__orelavoro)+" ore Interno: "+ str(self.__interno)
          return st

      def __eq__(self, persona):
          if isinstance(persona,tecnicoElettronico):
             return (persona.Get_nome() == self._nome) and (persona.Get_cognome() == self._cognome) and (persona.Get_dataass() == self._dataass) and (persona.GetOrelavorate() == self.__orelavoro) and (persona.GetInterno() == self.__interno)
