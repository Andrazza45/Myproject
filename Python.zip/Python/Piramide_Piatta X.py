import math
#Costruzione piramide
st1 = "+----------+"
st2= "\n"
st3= "|          |"
spazio =" "
spaziostrato = ""

print("Programma per calcolo dell'altezza della piramide")
nblocchi = input("Inserisci il numero di blocchi a disposizione dei costruttori")
while True:

            if nblocchi.isdigit():
               break
            else:
                  print("Dato non valido!")
                  nblocchi = input("Inserisci il numero di blocchi a disposizione dei costruttori")


nblocchi = int(nblocchi)
x = 1
n = nblocchi
c = round(nblocchi/2)

for i in range(0,nblocchi):

    if x == 1:
           spaziostrato = spaziostrato + (spazio)*(c+(x + 6))
    else:
         spaziostrato = ""
         spaziostrato = spaziostrato +(spazio)*(c-(x -3))
    if x == 1:
       print(spaziostrato + st1 + st2 +(spaziostrato+st3 + st2)*2 +spaziostrato + st1)
    else:

         if nblocchi - x >= 0:
            print(spaziostrato+(st1)*x)
            print(spaziostrato+(st3)*x)
            print(spaziostrato+(st3)*x)
            print(spaziostrato+(st1)*x)

         else:

              break
    nblocchi = nblocchi - x
    x = x + 1
if(nblocchi - x <= 0):
    print("l'altezza della piramide è", x - 1,"con scarto di",nblocchi,"blocchi" )











