import math
#Costruzione piramide
st1 = "+----------+"
st2= "\n"
st3= "|          |"
spazio =" "
spaziostrato = ""
def calcola_h(nblocchi):
    x = 1
    for i in range(0, nblocchi):
        nblocchi = nblocchi - x
        x = x + 1
        if nblocchi - x <= 0:
           break
    return x

print("Programma per calcolo dell'altezza della piramide")
nblocchi = input("Inserisci il numero di blocchi a disposizione dei costruttori")
while True:

            if nblocchi.isdigit():
               break
            else:
                  print("Dato non valido!")
                  nblocchi = input("Inserisci il numero di blocchi a disposizione dei costruttori")


nblocchi = int(nblocchi)
x = 1
c = round(nblocchi/2)
tab = calcola_h(nblocchi) - 1
for i in range(0,nblocchi):

    if x == 1:
           spaziostrato = spaziostrato +"\t"*tab +(spazio)*(c-(x -4))
    else:
         spaziostrato = ""
         spaziostrato = spaziostrato +(spazio)*(c-(x -3))
    if x == 1:
       print(spaziostrato + st1 + st2 +(spaziostrato+st3 + st2)*2 +spaziostrato + st1)
    else:

         if nblocchi - x >= 0:
            print("\t"*tab+spaziostrato+(st1)*x)
            print("\t"*tab+spaziostrato+(st3)*x)
            print("\t"*tab+spaziostrato+(st3)*x)
            print("\t"*tab+spaziostrato+(st1)*x)

         else:

              break
    nblocchi = nblocchi - x
    x = x + 1
    tab -= 1
if(nblocchi - x <= 0):
    print("l'altezza della piramide è", x - 1,"con scarto di",nblocchi,"blocchi" )











