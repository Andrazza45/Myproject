## Prova
a = "la mia prima stringa in doppie virgolette"
print(a)
b = 'la mia seconda stringa, in virgolette semplici'
print(b)
c = """la mia terza stringa,
in triple virgolette
quindi la posso mettere a capo
su più righe"""
print(c)

d= '''la mia quarta stringa,
in triplici apici
pure su più
linee '''
print(d)

x = 3
y = 7.9 - 4.2
premio = "Migliore atleta della Valle"
print("ho saltato",x,"m")
print(premio[0])
q = print(premio[:])
print(premio[0:3])
print(format(x,'2.55f'))
print(y == 3.7)
import math
print(math.isclose(y,3.7, abs_tol = 0.00001))
i = 11234
ex = 0x123f
b =0b1001
p = 0o234
print(i,ex,b,p,sep ="\t")
a =3e2
b = False
d = True

print(b == False and d == True)
print(9/2,9*2,9+2,9-2,9**2, 9%2,9//2,math.sqrt(9))
n = 9
st = str(n)
print("ci sono tutti numeri in st",st.isdigit())
c = "3"
st1 = str(c)
print(st + st1+ "-frasemia")
print(st1*3)
print("*"*20,"\n")
nome = input("Inserisci un nome:")
cognome = input("Inserisci un cognome:")
n = input("Inserisci un numero:")
#nota bene
print(n, end = "-")
print(n)
# io sono {} {}. format(cognome,nome)
st2= f"io sono {cognome} {nome}"
altezza = 135.5
print(st2)
print("io sono {a:3.3f}{c} {n} cm".format(a = altezza, c = cognome,n = nome))