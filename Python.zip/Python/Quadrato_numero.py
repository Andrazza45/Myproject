#Quadrato numero in python
import math
while True:
      numero = input("inserisci un numero:")
      if numero.isdigit():
         break
      else:
           print("errore")
numero = int (numero)
quadrato =numero* numero
cubo = numero**3
print("quadrato del numero", numero,"=",quadrato)
print("cubo del numero", str(numero),"=",str(cubo))


