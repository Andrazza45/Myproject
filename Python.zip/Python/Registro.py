#elenco dati di persone in cui si deve registrare nome, cognome, data di nascita e sesso
def carica_elenco(persone):
    while True:
               persona = []
               nome = input("Inserisci il nome:")
               cognome = input("Inserisci il cognome:")
               data_nascita = input("Inserisci la data:")
               sesso = input("Inserisci il sesso:")
               persona.append(nome)
               persona.append(cognome)
               persona.append(data_nascita)
               persona.append(sesso)
               scelta = input("Vuoi uscire?(1. si 2. no)")
               if scelta == "1":
                   break
    return persone
def stampa(elenco):
    for j in range(len(elenco)):
        print(elenco[j])
def f(x):
    return x[1]
def ord_insertion(elenco, x): #ordinamento crescente
    for i in range(len(elenco)-1):
        for j in range(i + 1, len(elenco)):
            if elenco[i][x] > elenco[j][x]:
               elenco[i],elenco[j] = elenco[j],elenco[i]
def main():
    elenco = []
    elenco = carica_elenco(elenco)
    stampa(elenco)
    #elenco.sort(key =f)
    ord_insertion(elenco, 1)
    stampa(elenco)
main()
