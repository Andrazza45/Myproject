from Persona import Persona
from Conto import ContoCorrente
from Funzioni import controllo_input
#Creo oggetto persona
p1 = Persona("Mario", "Rossi")
c1 = ContoCorrente(500)
p1.SetConto(c1)
c1.SetProprietario(p1)
print(c1.GetProprietario())
print(p1, "Conto:", p1.GetSaldo())
val = "float"
val = float(controllo_input(val,"Inserisci un valore da prelevare:"))
ris = c1.Prelievo(val)
if ris == 0:
   print("Prelievo effettuato!!","Nuovo saldo:", c1.GetSaldo())
else:
     print("Prelievo non effettuato!!!")


val = "float"
val = float(controllo_input(val,"Inserisci un valore da versare:"))
ris = c1.Versamento(val)
if ris == 0:
   print("Versamento effettuato!!","Nuovo saldo:", c1.GetSaldo())
else:
     print("Versamento non effettuato!!!")

p2 = Persona("Sergio","Verde")
c2 = ContoCorrente(1500)
p2.SetConto(c2)
c2.SetProprietario(p2)

lst = []
lst.append(c1)
lst.append(c2)
print("Nuova stampa")
for conto in lst:
    print(conto)

prel = "int"
dest = "int"
val = "float"
prel = int(controllo_input(prel,"Inserisci il numero del conto da cui prelevare"))
dest = int(controllo_input(dest,"Inserisci il numero del conto su cui versare"))
while val == "float":
      val = float(controllo_input(val,"Inserisci il valore del bonifico:"))
      if val < 0:
         print("Valore non ammesso!!")
         val = "float"
trovato = False
for c in lst:
    if c.GetNumConto() == prel:
       conto1 = c ###Trovo oggetto sul quale voglio  lavorare con il metodo prelievo
       trovato = True
trovato2 = False
for c in lst:
    if c.GetNumConto() == dest:
        conto2 = c
        trovato2 = True
        break
if trovato == False:
   print("Conto",prel,"non esiste!!, bonifico annullato")
elif trovato2 == False:
     print("Conto",dest,"non esiste!!, bonifico annullato")
elif trovato == True and trovato2 == True:
     ris1 = conto1.Prelievo(val)
     ris2 = conto2.Versamento(val)
     if ris1 == 0 and ris2 == 0:
        print("bonifico effettuato dal conto",str(prel),"al conto",str(dest),"di €",str(val))
     else:
          print("bonifico  non effettuato dal conto",str(prel),"al conto",str(dest))
lst.sort(key = lambda x:x.GetSaldo(), reverse = True)