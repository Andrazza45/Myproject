#Esercizio 1
'''
scrivere una funzione che faccia lo split di una stringa
split()
- accettare una stringa e restituire un elenco di parole create
  da una stringa separate con spazio
'''
def str_to_split(stringa):
    '''ritorna una lista vuota se la lista è vuota '''
    lista = []
    if stringa == "" or stringa.isspace():
       return lista

    word = ''
    inword = not stringa[0].isspace()
    for x in stringa:
        if inword:
           if x.isspace():
              word = word + x
           else:
                lista.append(word)
                inword = False
        else:
           if not x.isspace():
              inword = True
              word = x
           else:
                 pass
    if inword:
       lista.append(word)
    return lista


#Esercizio 2
'''scrivere una funzione is_anagramma che confronta due stringhe e dice se sono una l'anagramma dell'altro
esempio: parola 1 = "incerta" parola2 = "Trincea"'''

def is_anagramma(st,st1):
    an = False
    lista1 = []
    for ch1 in st:
        for ch2 in st1:
            if ch1 == ch2:
               lista1.append(ch1)
               break
    if len(lista1) == len(st):
       an = True
    else:
         an = False

    return an

def main():
    st = input("Inserisci la frase da splittare:")
    st = str_to_split(st)
    st = input("Parola 1:")
    st1 = input("Parola 2:")
    print(is_anagramma(st,st1))

main()

