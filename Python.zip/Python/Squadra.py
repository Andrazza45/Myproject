from Funzioni import controllo_input
class squadra():
      def __init__(self,nome):
        self.__nome = nome
        self.__partiteVinte = 0
        self.__partitePerse = 0
        self.__partitePareggiate = 0
        self.__goal = 0
        self.__subiti = 0
      def __str__(self):
          st = "Nome"+self.__nome +" Partite Vinte: "+str(self.__partiteVinte)+" Partite Perse: "+str(self.__partitePerse)+" Partite Pareggiate: "+str(self.__partitePareggiate)+" Goal Fatti: "+str(self.__goal)+" Goal Subiti: "+str(self.__subiti)
          return st
      def GetNome(self):
          return self.__nome
      def GetpartiteVinte(self):
          return self.__partiteVinte
      def GetpartitePerse(self):
          return self.__partitePerse
      def GetpartitePareggiate(self):
          return self.__partitePareggiate
      def GetGoal(self):
          return self.__goal
      def GetSubiti(self):
          return self.__subiti

      def SetPartiteVinte(self,pv):
          self.__partiteVinte = pv

      def SetPartitePerse(self,pp):
          self.__partitePerse = pp

      def SetPartitePareggiate(self,pari):
          self.__partitePareggiate = pari

      def GoalFatti(self, goal):
          self.__goal = self.__goal + goal

      def GoalSubiti(self,subito):
          self.__subiti = self.__subiti + subito

      def CalcolaPunti(self):
          Punti = self.__partiteVinte * 3 + self.__partitePareggiate
          return Punti
      def inizioAnno(self):
          self.__partiteVinte = 0
          self.__partitePerse = 0
          self.__partitePareggiate = 0
def Inserisci(listasq):
    pv = "int"
    pp = "int"
    pari = "int"
    goal = "int"
    subiti = "int"
    for squadra in listasq:
        squadra.SetPartiteVinte(int(controllo_input(pv,"Inserisci il numero di partite vinte dalla "+squadra.GetNome()+":")))
        squadra.SetPartitePerse(int(controllo_input(pp,"Inserisci il numero di partite perse dalla "+squadra.GetNome()+":")))
        squadra.SetPartitePareggiate(int(controllo_input(pari,"Inserisci il numero di partite pareggiate della "+squadra.GetNome()+":")))
        squadra.GoalFatti(int(controllo_input(goal,"Inserisci il numero di Goal Fatti dalla "+squadra.GetNome()+":")))
        squadra.GoalSubiti(int(controllo_input(subiti,"Inserisci il numero di Goal subiti della "+squadra.GetNome()+":")))
    return listasq
def confronto(listasq,squadraV, squadraG, squadraS):

    for i in range(0,len(listasq)):
        if listasq[i].CalcolaPunti() > listasq[i + 1].CalcolaPunti():
            squadraV = listasq[i].GetNome()
        else:
             squadraV = listasq[i+1].GetNome()

        if listasq[i].GetGoal() > listasq[i + 1].GetGoal():
           squadraG = listasq[i].GetNome()
        else:
             squadraG = listasq[i + 1].GetNome()
        if listasq[i].GetSubiti() > listasq[i + 1].GetSubiti():
           squadraS = listasq[i].GetNome()
        else:
             squadraS = listasq[i + 1].GetNome()
        break
    return squadraV, squadraG, squadraS
def Stampa(listasq):
    for squadra in listasq:
        print(squadra)
def Squadre():
    Juventus = squadra("Juventus")
    Milan = squadra("Milan")
    listasq = []
    squadraV = ""
    squadraG = ""
    squadraS = ""
    listasq.append(Juventus)
    listasq.append(Milan)
    listasq = Inserisci(listasq)
    squadraV, squadraG, squadraS = confronto(listasq,squadraV, squadraG, squadraS)
    print("La squadra che ha fatto più punti nel campionato è: ",squadraV,"\n")
    print("La squadra che ha fatto più Goal è: ",squadraG,"\n")
    print("La squadra che ha subito più Goal è: ",squadraS,"\n")

    Stampa(listasq)
def main():
    Squadre()
main()
