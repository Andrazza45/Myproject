from Funzioni import controllo_input, adatta, compatta
import math
mat = []
listasc = []
def stampa_scontrino(mat, listasc, x, tipo):
    stampa1= ""
    stampa2= ""
    stampa3= ""
    if tipo == False:
       for j in range(len(mat)):
           if mat[j][0] == x:
              for i in range(0,5):
                  if i == 0:
                     stampa2 =" "*6 +str(mat[j][i])+" "*32
                  elif i == 1:
                       stampa2 =stampa2+ str(mat[j][i])+" "*55
                  elif i == 2:
                       stampa2 =stampa2+ str(mat[j][i])+" "*45
                  elif i == 3:
                       stampa2 =stampa2+ str(mat[j][i])+" "*32
                  else:
                       stampa2 =stampa2+ str(mat[j][i])

           space = int(round(len(stampa2)/10,0))

       for i in range(0,5):
           if i == 0:
              stampa1 ="|"+stampa1 +" "*5+ mat[0][i]+" "*space+"|"
           else:
                stampa1 =stampa1 +" "*space+ mat[0][i]+" "*space+"|"

       stampa1,stampa2 = adatta(stampa1, stampa2)
##     stampa1,stampa2 = compatta(stampa1, stampa2)
       print(stampa1,"\n")
       print(stampa2,"\n")
    else:
           partenza = 0
           for j in range(len(mat)-1):
               for i in range(0, 5):
                   if i == 0:
                      stampa2 =" "*6 +str(listasc[partenza])+" "*32
                      for k in range(0,3):
                          partenza = partenza + 1
                   elif i == 1:
                      stampa2 =stampa2+ str(mat[j+1][1])+" "*55
                   elif i == 2:
                        stampa2 =stampa2+ str(mat[j+1][2])+" "*45
                   elif i == 3:
                        stampa2 =stampa2+ str(mat[j+1][3])+" "*32
                   elif i == 4:
                        for k in range(partenza - 2, partenza):
                            if k == 1:
                               stampa2 =stampa2+ str(listasc[k])+" "*25
                            else:
                                 stampa2 =stampa2+ str(listasc[k])
               stampa3 = stampa3 + stampa2+"\n"*2

           space = int(round(len(stampa2)/14,0))

           for i in range(0,6):
               if i == 0:
                  stampa1 =stampa1 +" "*5+ mat[0][i]+" "*space+"|"
               elif i == 4:
                    stampa1 ="|"+stampa1+ "Totale scontato(€)"+" "*space+"|"
               elif i == 5:
                    stampa1 =stampa1+ "Sconto Applicato(€)"+" "*space+"|"
               else:
                    stampa1 =stampa1 +" "*space+ mat[0][i]+" "*space+"|"

           stampa1,stampa3 = adatta(stampa1, stampa3)
##         stampa1,stampa3 = compatta(stampa1, stampa3)
           print(stampa1,"\n")
           print(stampa3,"\n")


def genera_matrice(mat, c, nomeP, descrizione, quantità, prezzo,Totale):
        riga = []
        if len(mat) == 0:
           for i in range(c):
               match i:
                        case 0:riga =riga + ["Nome_Prodotto"]
                        case 1:riga =riga + ["Descrizione"]
                        case 2:riga =riga + ["Quantità"]
                        case 3:riga =riga + ["Prezzo(€)"]
                        case 4:riga =riga + ["Totale(€)"]
           mat.append(riga)
        riga = []
        for i in range(c):
            match i:
                    case 0:riga =riga + [nomeP]
                    case 1:riga =riga + [descrizione]
                    case 2:riga =riga + [quantità]
                    case 3:riga =riga + [prezzo]
                    case 4:riga =riga + [Totale]
        mat.append(riga)
        return mat
def inserimento_dati(mat):
    nomeP = ""
    descrizione = ""
    quantità = "int"
    prezzo = "float"
    nomeP = controllo_input(nomeP,"Inserire il nome del prodotto:")
    descrizione = controllo_input(descrizione,"Di che si tratta?")
    quantità = controllo_input(quantità,"Quanti?")
    prezzo = controllo_input(prezzo,"Inserire il prezzo per un Pz:")
    print("\n")
    Totale = prezzo * int(quantità)
    genera_matrice(mat, 5,nomeP,descrizione,quantità,prezzo,Totale)
    return nomeP, Totale, 0

def applica_sconto():
    tipo = False
    x = ""
    totalesc = 0
    scontotot = 0
    trovato = False
    x = controllo_input(x,"A quale prodotto vuoi applicare lo sconto?")

    for i in range (0, len(mat)):
        if x == mat[i][0]:
           trovato = True
           totale = round(mat[i][4],2)
           if float(mat[i][4]) > 50:
              sconto = round(totale *2/100,2)
              totale = totale - sconto
              scontotot = scontotot + sconto
              print("Applicazione dello sconto:","\n")
              stampa_scontrino(mat,listasc, x, tipo)
              print("Sconto del 2% sul totale = "+ str(sconto)+"€: Nuovo totale = "+str(mat[i][4])+"-"+str(sconto)+" = "+str(totale)+"€"+"\n")
           if float(mat[i][2]) > 5:
              sconto = round(totale *7/100,2)
              totalesc = totale - sconto
              scontotot = scontotot + sconto
              print("Sconto del 7% sul totale scontato = "+str(totale)+" * 7/100 = "+ str(sconto)+"€: Nuovo Totale = "+str(totale)+"-"+str(sconto)+" = "+str(round(totalesc,2))+"€"+"\n")
           break
    if not trovato:
       print("\n","Articolo o articoli non riconosciuti!!","\n")
       return -1, -1, -1
    else:
         if totalesc == 0:
            return x, totale, scontotot
         else:
              return x, totalesc, scontotot
def scontrino():
    stringa = """
    ***************************************
    *         GESTIONE SCONTRINO          *
    ***************************************

    ***************************************
    *       Menù utente principale        *
    ***************************************
    *    1.Inserimento articolo           *
    *    2.Applica sconto                 *
    *    3.Stampa scontrino               *
    *    4.=====>Uscita                   *
    ***************************************
    Inserire scelta(1, 2, 3 oppure 4):
    """
    scelta = -1
    while scelta != 0:
           print("Programma per la stampa dello Scontrino")
           print(stringa)
           scelta = input("Che tipo di operazione desideri effettuare?")
           print("\n")
           match scelta:
                   case "1":
                            x, totalesc, scontotot = inserimento_dati(mat)
                            for i in range(0,3):
                                if i == 0:
                                   listasc.append(x)
                                elif i == 1:
                                     listasc.append(round(totalesc,2))
                                elif i == 2:
                                     listasc.append(round(scontotot,2))
                   case "2":
                            x, totalesc, scontotot= applica_sconto()
                            for j in range(0,len(listasc)):
                                if listasc[j] == 0:
                                   if listasc[j-2] == x:
                                      listasc.remove(listasc[j])
                                      listasc.remove(listasc[j-1])
                                      listasc.remove(listasc[j-2])
                            for i in range(0,3):
                                if i == 0 and x != -1:
                                   listasc.append(x)
                                elif i == 1 and totalesc != -1:
                                     listasc.append(round(totalesc,2))
                                elif i == 2 and scontotot != -1:
                                     listasc.append(round(scontotot,2))

                   case "3":
                            print("**** Stampa dello scontrino ***","\n")
                            if len(mat) != 0:
                               tipo = True;stampa_scontrino(mat, listasc, "",tipo);
                            else:
                                 print("\n","Non hai inserito nessun prodotto!!","\n")


                   case "4":print("FINE!");scelta = 0;


                   case _: print("ERRORE!")
def main():
    scontrino()

main()
#'{:,}'.format(1234567890.001).replace('.', ',')