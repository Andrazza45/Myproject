from Persona import Persona
class Studente(Persona):
    def __init__(self, nome , cognome, residenza):
        super().__init__(nome,cognome)
        self.__residenza = residenza

    def Get_residenza(self):
        return self.__residenza

    def Set_residenza(self, residenza):
        self.__residenza = residenza

    def __str__(self):
        return super().__str__()+"Residenza: "+self.__residenza+"\n"