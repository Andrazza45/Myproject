#categoria per determinare la tariffa_fissa
from Funzioni import controllo_input, genera_matrice, adatta, compatta
import math
mat = []
def stampa_info(mat, ID):
    stampa1= ""
    stampa2= ""
    for j in range(len(mat)):
        if mat[j][0] == int(ID):
           for i in range(0,5):
               if i == 0:
                  stampa2 =" "*6 +str(mat[int(ID)][i])+" "*8
               elif i == 1:
                    stampa2 =stampa2+ str(mat[int(ID)][i])+" "*35
               elif i == 2:
                    stampa2 =stampa2+ str(mat[int(ID)][i])+" "*30
               elif i == 3:
                    stampa2 =stampa2+ str(mat[int(ID)][i])+" "*25
               else:
                    stampa2 =stampa2+ str(mat[int(ID)][i])

        space = int(round(len(stampa2)/10,0))

    for i in range(0,5):
        if i == 0:
           stampa1 ="|"+stampa1 +" "*5+ mat[0][i]+" "*6+"|"
        else:
             stampa1 =stampa1 +" "*space+ mat[0][i]+" "*space+"|"

    stampa1,stampa2 = adatta(stampa1, stampa2)
##  stampa1,stampa2 = compatta(stampa1, stampa2)
    print(stampa1,end ="\n")
    print(stampa2)



def tab_tari(categoria, nfam):
    categoria = int(categoria)
    nfam = int(nfam)
    if nfam == 0:
       euro_mq= 0.34758
       tariffa_fissa = 0.35771
    elif nfam == 1:
         euro_mq= 1.23764
         if categoria == 1:
            tariffa_fissa = 49.92488
         else:
              tariffa_fissa = 39.93990
    elif nfam == 2:
         euro_mq= 1.45422
         if categoria == 1:
            tariffa_fissa = 134.17313
         else:
              tariffa_fissa = 107.33850
    elif nfam >= 3:
         euro_mq= 1.62440
         if categoria == 1:
            tariffa_fissa = 160.38370
         else:
              tariffa_fissa = 128.30696
    return euro_mq, tariffa_fissa

def calcolo_Tari(mat, ID):
    Tari = 0
    euro_mq = 0
    tariffa_fissa = 0
    info= ""
    if int(ID) != 0 and int(ID) <= len(mat):

        for j in range(0, len(mat)):
            if mat[j][0] == int(ID):
               match int(mat[j][2]):
                                case 1:euro_mq, tariffa_fissa = tab_tari(mat[j][2],mat[j][4])
                                case 2:euro_mq, tariffa_fissa = tab_tari(mat[j][2], mat[j][4])
                                case 3:euro_mq, tariffa_fissa = tab_tari(mat[j][2], mat[j][4])
               break
        stampa_info(mat, ID)
        print("\n")
        Tari = round(euro_mq, 2) * round(float(mat[int(ID)][3]),0)
        Tari = Tari + (Tari*5)/100
        info = "La Tari del signor "+ str(mat[j][1]) + " con ID "+ str(ID)+" è: "+ str(round(Tari,2))+"€"+"\n"*2+"Tariffa Fissa = "+str(round(tariffa_fissa,2))+"€"+"\n"
        return info
    else:
         return "ID non valido!"

def inserimento_dati(ID):
    proprietario = ""
    categoria = "range"
    mq = "float"
    numfamigliari = "int"
    proprietario = controllo_input(proprietario,"Inserire il nome del proprietario dell'abitazione/immobile:")
    categoria = controllo_input(categoria,"Inserire il tipo di immobile(abitazione(1), alloggi(2), box privato(3):")
    mq = controllo_input(mq,"Inserire il numero di metri quadrati:")
    numfamigliari = controllo_input(numfamigliari,"Inserire il numero di abitanti:")
    print("\n")
    genera_matrice(mat,5,ID, proprietario,categoria,mq,numfamigliari)
    ID = ID + 1
    return ID
def stampa_info_Tari():
    x = "int"
    print("\n")
    x = controllo_input(x,"Quale ID vuoi vedere?")
    print(calcolo_Tari(mat, x))
def gestione_Tari():
    ID = 1
    stringa = """
***************************************
1.Inserimento dati
2.Stampa informazioni Tari
3.Uscita
***************************************"""
    scelta = -1
    while scelta != 0:
           print("Programma per il calcolo della Tari")
           print(stringa)
           scelta = input("Che tipo di operazione desideri effettuare?")
           match scelta:
                   case "1": ID = inserimento_dati(ID)

                   case "2":stampa_info_Tari()

                   case "3":
                          print("FINE")
                          scelta = 0
                   case _: print("ERRORE!")

def main():
    gestione_Tari()
main()