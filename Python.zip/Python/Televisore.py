from Funzioni import controllo_input
class televisore():
      def __init__(self):
          self.__accesa = False
          self.__volume = 0
          self.__muto = False
          self.__canale = 1

      def GetCanale(self):
          return self.__canale
      def GetVolume(self):
          return self.__volume
      def GetAccesa(self):
          return self.__accesa
      def PulsanteAccensione(self, accesa):
          self.__accesa = accesa
      def ImpostaCanale(self,canale):
          if canale < 0 or canale > 99:
             print("Canale Inesistente")
          else:
               self.__canale = canale
      def CanaleSuccessivo(self, canale):
          self.__canale = canale + 1
      def CanalePrecedente(self, canale):
          self.__canale = canale - 1
          print("Volume minimo")
      def AumentaVolume(self,volume):
          if volume + 1 > 10:
             print("Volume massimo")
          else:
               self.__volume = volume + 1
               self.__muto = False
      def AbbassaVolume(self, volume):
          if volume - 1 < 0:
             print("Volume minimo")
          else:
               self.__volume = volume - 1
      def PulsanteSilenzioso(self):
          self.__volume = 0
          self.__muto = "True"
      def PrintTv(self):
          st = "accesa:" +str(self.__accesa)+ " " + "volume:" + str(self.__volume)+ " " + "muto:" + str(self.__muto) + " "+ "Canale:" + str(self.__canale)
          print(st)

      def __str__(self):
          st = "accesa:" +str(self.__accesa)+ " " + "volume:" + str(self.__volume)+ " " + "muto:" + str(self.__muto) + " "+ "Canale:" + str(self.__canale)
          return st
def televisori():
    print("Programma TV")
    stringa = """
                 ** 1 TV ON/OFF
                 ** 2 Imposta canale
                 ** 3 Canale SU
                 ** 4 Canale GIU'
                 ** 5 Volume SU
                 ** 6 Volume GIU'
                 ** 7 Mute ON/OFF
                 ** 8 Stampa TV
                 ** 0 ----> EXIT"""
    m = "int"
    tv = televisore()
    while m != 0:
            print(stringa,"\n")
            m = int(controllo_input(m, "Inserisci un opzione:"))
            match m:
                    case 1:
                           if tv.GetAccesa() == False:
                              tv.PulsanteAccensione(True)
                           else:
                                tv.PulsanteAccensione(False)
                           m = "int"
                    case 2:
                           canale = "int"
                           canale = int(controllo_input(canale, "Scegli il canale:"))
                           tv.ImpostaCanale(canale);m = "int"
                    case 3:
                           tv.CanaleSuccessivo(tv.GetCanale());m = "int"
                    case 4:
                           tv.CanalePrecedente(tv.GetCanale());m = "int"
                    case 5:
                           tv.AumentaVolume(tv.GetVolume());m = "int"
                    case 6:
                           tv.AbbassaVolume(tv.GetVolume());m = "int"
                    case 7:
                           tv.PulsanteSilenzioso();m = "int"
                    case 8:
                           tv.PrintTv();m = "int"
                    case 0:
                           print("END")
                    case _:print("Errore!");m = "int"


def main():
    televisori()
main()
