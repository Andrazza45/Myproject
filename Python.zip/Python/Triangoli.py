from Funzioni import controllo_input
def input_h(st,n1,n2):
    while True:
           try:
               numero = int(input(st))
               if numero >= n1 and numero <= n2:
                  break
           except:
                   print("input errato!")

           else:
                print("Il numero non è nell'intervallo n1 e n2")
    return numero

def is_triangolo(a,b,c):
    return a + b > c and a + c > b and b + c > a



a = input_h("inserisci altezza:",50,220)
b = input_h("inserisci altezza:",10,50)
print(a,",",b)

a= "float"
b= "float"
c= "float"
a = controllo_input(a,"Inserire a:")
b = controllo_input(b,"Inserire b:")
c = controllo_input(c,"Inserire c:")

print(is_triangolo(a,b,c))

