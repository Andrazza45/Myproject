from math import sqrt
from Funzioni import controllo_input
class Punto():
    def __init__(self, x:float, y:float, nome):
        self.__x = x
        self.__y = y
        self.__nome = nome

    def Getx(self):
        return self.__x
    def Gety(self):
        return self.__y
    def Getnome(self):
        return self.__nome

    def Calcola_d(self,x,y):
        d = sqrt(pow(abs(self.__x - x,2)) + pow(abs(self.__y - y),2))
        return d

    def __str__(self):
        return "Nome "+ self.__nome +" X: "+str(self.__x)+" Y: "+str(self.__y)

class Triangolo():

      __p1 = []
      __p2 = []
      __p3 = []
##      __points = []

      def __init__(self, P1, P2, P3):
          Triangolo.__p1 = [P1.Getx(),P1.Gety(),P1.Getnome()]
          Triangolo.__p2 = [P2.Getx(),P2.Gety(),P2.Getnome()]
          Triangolo.__p3 = [P3.Getx(),P3.Gety(),P3.Getnome()]
          self.__d1 = sqrt(pow(abs(Triangolo.__p1[0] - Triangolo.__p2[0]),2) + pow(abs(Triangolo.__p1[1] - Triangolo.__p2[1]),2))
          self.__d2 = sqrt(pow(abs(Triangolo.__p2[0] - Triangolo.__p3[0]),2) + pow(abs(Triangolo.__p2[1] - Triangolo.__p3[1]),2))
          self.__d3 = sqrt(pow(abs(Triangolo.__p3[0] - Triangolo.__p1[0]),2) + pow(abs(Triangolo.__p3[1] - Triangolo.__p1[1]),2))
          self.__h = abs(Triangolo.__p2[1] - Triangolo.__p3[1])

      def trasla(self, x:float,y:float):
          points = [Triangolo.__p1,Triangolo.__p2,Triangolo.__p3]
          for i in range (0, len(points)):
              for j in range(0,2):
                  if j == 0:
                     points[i][j] = points[i][j] + x
                  else:
                       points[i][j] = points[i][j] + y

      def schiaccia(self, nome ,x):
          points = [Triangolo.__p1,Triangolo.__p2,Triangolo.__p3]
          match nome:
                case 'A':points[0][0] = points[0][0] + x
                case 'B':points[1][0] = points[1][0] + x
                case 'C':points[2][0] = points[2][0] + x
                case _:return -1
          self.__d1 = sqrt(pow(abs(Triangolo.__p1[0] - Triangolo.__p2[0]),2) + pow(abs(Triangolo.__p1[1] - Triangolo.__p2[1]),2))
          self.__d2 = sqrt(pow(abs(Triangolo.__p2[0] - Triangolo.__p3[0]),2) + pow(abs(Triangolo.__p2[1] - Triangolo.__p3[1]),2))
          self.__d3 = sqrt(pow(abs(Triangolo.__p3[0] - Triangolo.__p1[0]),2) + pow(abs(Triangolo.__p3[1] - Triangolo.__p1[1]),2))
          self.__h = abs(Triangolo.__p2[1] - Triangolo.__p3[1])

      def Getd1(self):
          return round(self.__d1,2)
      def Getd2(self):
          return round(self.__d2,2)
      def Getd3(self):
          return round(self.__d3,2)

      def GetPerimetro(self):
          P = self.__d1 + self.__d2 + self.__d3
          return round(P,2)
      def GetArea(self):
          A = (self.__d3 * self.__h )/2
          return round(A,2)

      def __str__(self):
          return "Punto 1: " +str(Triangolo.__p1)+" Punto 2: " + str(Triangolo.__p2)+ " Punto 3: "+ str(Triangolo.__p3)

def isTriangolo(lst, i):
    triangolo = False
    index = i - 3
    d1 = sqrt(pow(lst[index].Getx() - lst[index +1].Getx(),2) + pow(lst[index].Gety() - lst[index + 1].Gety(),2))
    d2 = sqrt(pow(lst[index + 1].Getx() - lst[index + 2].Getx(),2) + pow(lst[index + 1].Gety() - lst[index + 2].Gety(),2))
    d3 = sqrt(pow(lst[index + 2].Getx() - lst[index].Getx(),2) + pow(lst[index + 2].Gety() - lst[index].Gety(),2))

    if d1 + d2 > d3:
       triangolo = True
    else:
          triangolo = False
    if d2 + d3 > d1:
       triangolo = True
    else:
          triangolo = False
    if d1 + d3 > d2:
       triangolo = True
    else:
          triangolo = False
    return triangolo

def Inserisci(lst, i):
    x = "float"
    y = "float"
    P = ['','A','B','C']
    for j in range(1,4):
        ms ="Inserire l'Abscissa x del punto "+str(j) +":"
        x = float(controllo_input(x,ms))
        ms ="Inserire l'ordinata y del punto "+str(j) +":"
        y = float(controllo_input(y,ms))
        p = Punto(x,y,P[j])
        lst.append(p)
        x = "float"
        y = "float"
    i += 3
    return lst, i
def StampaT(lstT):
     print("\n"+"Triangoli:"+"\n")
     for Tr in lstT:
        print("d1:"+str(Tr.Getd1())+"cm","d2:"+str(Tr.Getd2())+"cm","d3:"+str(Tr.Getd3())+"cm")
        print("Perimetro:"+str(Tr.GetPerimetro()),"cm")
        print("Area:"+str(Tr.GetArea()),"cm^2","\n")
def main():
    lst = []
    lstT = []
    i = 0
    q = "int"
    q = int(controllo_input(q,"Quanti oggetti vuoi inserire?"))
    j = 0
    while j < q:
        print("Triangolo",j + 1)
        lst,  i = Inserisci(lst, i)
        if  isTriangolo(lst, i) == False:
            print("Non si tratta di un triangolo!!")
            for k in range(i - 3, i ):
                if k == i - 1:
                   del(lst[k - i])
                else:
                     del(lst[k])
            i -= 3

        else:
             Tr = Triangolo(lst[i - 3],lst[i-2], lst[i-1])
##           Tr.trasla(30, 40)
             if Tr.schiaccia('A',20) == -1:
                print("Errore!!")

             lstT.append(Tr)
             j += 1
    StampaT(lstT)
main()


