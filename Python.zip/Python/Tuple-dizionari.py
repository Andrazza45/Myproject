#tuple - elementi immutabili
#g, m, a = input("gg-mm-aa").split("-")
#operazioni con tuple
#creo una tupla vuota
tupla = ()
tupla = tuple()
#creo una tupla con elementi
tupla = (1,2,3,4)
print(tupla, id(tupla))
tupla = tupla + (5,)
print(tupla,id(tupla))
#invertire una tupla
tupla1 = (10,20,30,40,50)
tupla1 = tupla1[::-1]
print(tupla1)
#creo una tupla in cui elemnti sono liste e tuple
tupla =("orange", [10,20,30], (5,15,25))
print("tupla[0]=", tupla[0])
print("tupla[1]=", tupla[1])
print("tupla[1][1]=", tupla[1][1])
print("tupla[2]=", tupla[2])
#modifico elemnto 20 all'interno della tupla
tupla[1][1] = 40
#tupla[0] = "" errore!!
#creo una tupla di un solo elemento
tupla =(50, )
#spacchettare la tupla
tupla = (10,20,30,40)
a,b,c,d = tupla
print(a,b,c,d)
#scambia due tuple
tupla1 = (11,22)
tupla2 = (99,88)
tupla1, tupla2 = tupla2, tupla1
print(tupla1, tupla2)
tupla1 = (('e',23),('b',37),('c',11),('d',29))
tupla2 = tuple(sorted(tupla1))
print(tupla2)
#ordina sul 2' elemento della tupla interna
tupla3 = tuple(sorted(list(tupla1), key = lambda x: x[1]))
print(tupla3)
#contare le occorrenze di un elemento di una tupla
tupla1 = (50,10,60,70,50)
print(tupla1.count(50))
#elimino gli elementi ripetuti
tupla2 = ()
for i in range(len(tupla1)):
    if  tupla1[i]not in tupla2:
        tupla2 = tupla2 +(tupla1[i], )
print(tupla2)



#Creazione di dizionari
diz = {
    "cat": "chat",
    "dog": "chien",
    "horse":"cheval"
}
telefono = {
"mario":556788900,
"antonio":888476553
}
diz_vuoto ={}
print(telefono)
print(diz["dog"])
if "dog" in diz:
    print(diz["dog"],"\n")

#stampa dizionario per singolo elemento
for key in diz.keys():
    print(key,"-->", diz[key])
print("\n")
for key in sorted(diz.keys()):
    print(key,"-->", diz[key])

parole=["cat","lion","dog"]
dizionario = {"cat":"chat","dog":"chien","horse":"cheval"}
# dizionario = {}
# dizioario["cat"] = "chat"
#d = dict()
# diz.update({"cat":"chat"})
print(dizionario)
##for p in sorted(dizionario.keys):
##    print(p," ",dizionario[p])
##print(dizionario)
for p in parole:
    for key in dizionario.keys():
        if p == key:
           print(key,"-->",dizionario[key])

        else:
             print("non è nel dizionario")




