class Veicolo():
    def __init__(self, marca, targa, costo):
        self._marca = marca;
        self._targa = targa;
        self._costo = costo;
    def Get_marca(self):
        return self._marca

    def Get_targa(self):
        return self._targa

    def Get_costo(self):
        return self._costo

    def Set_marca(self, marca):
        self._marca = marca

    def Set_targa(self, targa):
        self._targa = targa

    def Set_costo(self, costo):
        self._costo = costo

    def __str__(self):
        return "Marca: "+self._marca +" targa: "+self._targa +" costo: "+str(self. _costo)

class Autovettura(Veicolo):
        def __init__(self,marca,targa,costo,posti):
            super(). __init__(marca,targa,costo)
            self.__posti = posti

        def Get_posti(self):
            return self.__posti

        def Set_posti(self, posti):
            self.__posti = posti
        def __str__(self):
            return "Marca: "+self._marca +" targa: "+self._targa +" costo: "+str(self. _costo) +" Posti: "+ str(self.__posti)



class Furgone(Veicolo):
    def __init__(self,marca,targa,costo,capacita):
        super(). __init__(marca,targa,costo)
        self.__capacita = capacita

    def Get_capacita(self):
        return self.__capacita

    def Set_capacita(self, capacita):
        self.__capacita = capacita
    def __str__(self):
        return "Marca: "+self._marca +" targa: "+self._targa +" costo: "+str(self. _costo) +" Capacità: "+ str(self.__capacita)


