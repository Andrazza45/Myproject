from Funzioni import controllo_input
def inserimento_squadra(squadra):
    riga = {}
    nome = ""
    colore = ""
    punteggio = "int"
    nome_allenatore = ""
    cognome_allenatore = ""
    titoli = "int"
    nome = controllo_input(nome,"Inserire il nome della squadra:")
    colore = controllo_input(colore,"Inserire il colore della squadra:")
    punteggio = controllo_input(punteggio,"Inserire il punteggio della squadra:")
    nome_allenatore = controllo_input(nome_allenatore,"Inserire il nome dell'allenatore:")
    cognome_allenatore = controllo_input(cognome_allenatore,"Inserire il cognome dell'allenatore:")
    nominativo = nome_allenatore +" "+ cognome_allenatore
    titoli = controllo_input(titoli,"Inserire il numero di titoli vinti dalla squadra:")
    riga["nome"] = nome
    riga["colore"] = colore
    riga["punteggio"] = punteggio
    riga["nominativo"] = nominativo
    riga["titoli"] = titoli
    squadra.append(riga)
    return squadra
def _copia(squadra):
    copia = []
    for p in squadra:
        riga = {}
        riga['nome'] = p["nome"]
        riga['colore'] = p["colore"]
        riga['punteggio'] = p["punteggio"]
        riga['nominativo'] = p["nominativo"]
        riga["titoli"] = p["titoli"]
        copia.append(riga)
    keys = list(p.keys())##Molto importante!!

    return copia,keys
def stampa_squadra(squadra,Y, tipo):
    copia = []
    keys = []
    copia, keys = _copia(squadra)
    if tipo == "a":
       import operator
       copia.sort(key=operator.itemgetter("punteggio"))
       print("-----Stampa classifica-----","\n")
       for p in copia:
           for key in range(0,len(p) - 2):
               print("{:<15}".format(keys[key]),end="\t")
           print("\n")
           break
       for p in range(0,len(copia)):
           for key in range(0,len(copia[p]) - 2):
               print("{:<15}".format(copia[p].get(keys[key])),end="\t")
           print("\n")

    elif tipo == "b":
         import operator
         copia.sort(key=operator.itemgetter("titoli"))
         print("----classifica Titoli Allenatori-ordinamento per titoli decrescente----","\n")
         for p in copia:
             for key in range(2,len(p)):
                 print("{:<15}".format(keys[key]),end="\t")
             print("\n")
             break
         for p in range(0,len(copia)):
             for key in range(2, len(copia[p])):
                 print("{:<15}".format(copia[p].get(keys[key])),end="\t")
             print("\n")

    elif tipo == "c":
         print("Stampa squadre con più di Y punti in classifica","\n")
         for p in copia:
             for key in range(0,len(p)):
                 if keys[key] == "nome" or keys[key] == "punteggio":
                    print("{:<15}".format(keys[key]),end="\t")
             print("\n")
             break
         for p in range(0,len(copia)):
             for key in range(0,len(copia[p])):
                 if keys[key] == "punteggio":
                    if copia[p].get(keys[key]) >= Y:
                       print("{:<15}".format(copia[p].get("nome")),end="\t")
                       print("{:<15}".format(copia[p].get(keys[key])),end="\t")
             print("\n")
    else:
         print("Stampa squadre con allenatori con più di Y titoli","\n")
         for p in copia:
             for key in range(0,len(p)):
                 if keys[key] == "nome" or keys[key] == "nominativo" or keys[key] == "titoli":
                    print("{:<15}".format(keys[key]),end="\t")
             print("\n")
             break
         for p in range(0,len(copia)):
             for key in range(0,len(copia[p])):
                 if keys[key] == "titoli":
                    if copia[p].get(keys[key]) >= Y:
                       print("{:<15}".format(copia[p].get("nome")),end="\t")
                       print("{:<15}".format(copia[p].get("nominativo")),end="\t")
                       print("{:<15}".format(copia[p].get(keys[key])),end="\t")
             print("\n")
    return squadra
def modifica_punteggio(squadra,x,punti):
    for p in squadra:
        for key in p:
            if key == "nome":
               if p[key] == x:
                  p["punteggio"] = punti
                  break
        if p[key] == x:
           break
    if p[key] == x:
       return squadra, 1
    else:
         return squadra, -1
def titoli_vinti(squadra, x):
    totale = 0
    for p in squadra:
        for key in p:
            if key == "titoli":
               if p[key] == x:
                  totale = totale + 1
    return totale

def FantaCalcio():
    squadra = []
    Y = 0
    tipo = ""
    print("Programma FantaCalcio","\n")

    stringa = """
    1) Inserimento dati delle squadre.
    2) Stampare la classifica delle squadre in ordine decrescente di punteggio.
    3) Modificare i punti di una squadra con input da tastiera.
    4) Stampare classifica titoli degli allenatori in ordine decrescente di titoli.
    5) Numero totale di allenatori che hanno vinto Y titoli , con Y preso in input.
    6) Stampa squadre con più di Y punti in classifica.
    7) Stampare squadre con allenatori che hanno vinto più di Y titoli.
    8) Fine.
    """
    c = "int"
    while c != 0:
          print(stringa)
          c = controllo_input(c,"Quale operazione desideri effettuare?")
          print("\n")
          match int(c):
                  case 1:squadra = inserimento_squadra(squadra); c = "int";
                  case 2:
                         if len(squadra) != 0:
                            tipo = "a"; squadra = stampa_squadra(squadra,Y,tipo)
                         else:
                              print("Non ci sono squadre inserite!")
                         c = "int"
                  case 3:
                        if len(squadra) != 0:
                            x = ""
                            punti = "int"
                            x = controllo_input(x, "Inserisci il nome della squadra a cui vuoi modicare il punteggio:")
                            print("\n")
                            punti = controllo_input(punti, "Inserisci il punteggio della squadra:")
                            print("\n")
                            squadra, punti = modifica_punteggio(squadra,x, punti)
                            if punti != -1:
                               print("Punti modificati!")
                            else:
                                 print("Squadra non trovata!")
                        else:
                             print("Non ci sono squadre inserite!")
                        c = "int"
                  case 4:
                         if len(squadra) != 0:
                             tipo = "b"; squadra = stampa_squadra(squadra,Y,tipo)
                         else:
                              print("Non ci sono squadre inserite!")
                         c = "int"
                  case 5:
                         if len(squadra) != 0:
                             x = "int"
                             x = controllo_input(x, "Inserisci il numero di titoli vinti che vuoi cercare di una determinata squadra:")
                             tot = 0
                             tot = titoli_vinti(squadra, x)
                             print("Il numero di allenatori che ha vinto ",x,"titoli è: ", tot)
                         else:
                              print("Non ci sono squadre inserite!")
                         c = "int"
                  case 6:
                         if len(squadra) != 0:
                             Y = "int"
                             Y = controllo_input(Y,"Inserire un punteggio:")
                             tipo = "c"; squadra = stampa_squadra(squadra,Y,tipo)
                         else:
                              print("Non ci sono squadre inserite!")
                         c = "int"
                  case 7:
                         if len(squadra) != 0:
                             Y = "int"
                             Y = controllo_input(Y,"Inserire il numero di titoli:")
                             tipo = "d"; squadra = stampa_squadra(squadra,Y,tipo)
                         else:
                              print("Non ci sono squadre inserite!")
                         c = "int"
                  case 8:
                         print("Fine!")
                         c = 0
                  case _:print("ERRORE!");c = "int";
def main():
    FantaCalcio()

main()


