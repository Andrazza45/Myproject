str1 = input("Inserisci la frase:")
vocali = "AaEeIiOoUu"
st=""
for ch in str1:
    if ch in vocali:
       continue
    st= st + ch
print(st)
        
#Ricerca
st2 = input("Inserire la stringa:")
start = 0
parola="ciao"
trovata = ""

for i in range(len(st2)):
    pos = parola.find(st2,start)
    if pos < 0:
        trovata = False
        break
    else:
         trovata = True
         break
    start = pos + 1
if trovata == False:
    print("Frase non trovata")
else:
    print("trovata")
        