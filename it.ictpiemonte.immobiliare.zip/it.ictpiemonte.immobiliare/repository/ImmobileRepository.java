package it.ictpiemonte.immobiliare.repository;

import it.ictpiemonte.immobiliare.entity.Immobile;
import it.ictpiemonte.immobiliare.entity.Provincia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ImmobileRepository extends JpaRepository<Immobile, Integer> {
    @Query(value="Select * from Immobili i where i.visible = false")
    List<Provincia> findAllByOrderByProvinciaAsc(); // select * from immobile order by immobile ASC


}
