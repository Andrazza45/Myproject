package it.ictpiemonte.immobiliare.service;

import it.ictpiemonte.immobiliare.entity.Immobile;
import jakarta.validation.constraints.NotNull;
import org.aspectj.bridge.MessageUtil;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@EnableCaching
@EnableScheduling
@SpringBootApplication
public class Scheduling {
      ImmobileService immobileService;

    public void scheduling() throws IOException {
        MessageUtil log = null;
        log.info("-----SCHEDULAZIONE INIZIATA----");
        //Genero un file .txt che riporti tutti gli immobili per quelli a cui non è stato scritto un annuncio
        //Dell' immobile riportare tutti i dati dell'immobile
        String path = "./Files/immobili.txt";
        Path _path = Paths.get(path);
        if(Files.exists(_path))
        {
            File file = new File(path);
        }

        @NotNull
        OutputStreamWriter fw = new OutputStreamWriter((OutputStream) _path);
        List<Immobile> IMMOBILI= (List<Immobile>) immobileService.findAll();
        final String[] str = {""};
        IMMOBILI.forEach(immobile -> str[0] += immobile.ToString());
        fw.write(str[0]);
        fw.close();

    }

}
